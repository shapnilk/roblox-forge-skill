# Modeling and characters (R6, voxel, Blender, Import 3D, Open Cloud)

Worst rejection of the project: four custom hero models with finger meshes, guessed faces, wrong hat
size and wrong outfit - built from scratch instead of reusing the approved face/model pipeline.
Detailed scripts: roblox-forge `references/characters.md` if installed.

## Character rules
1. **Plain R6 only.** Block arms/legs/torso + classic head. **No hand or finger meshes, ever** - hand
   seals and claws are posed with block arms.
2. **Faces = painted 2D anime faces in SETS** (neutral, determined, grin, laugh eyes-shut, shout,
   surprised) so beats can swap decals. Likeness comes from **tracing/measuring** show frames and a pro
   UGC face's proportions, not drawing from memory. Faces from scratch on a plain head, never traced
   over an already-baked face.
3. **Outfit = the exact arc the user names** (research it; never default to the iconic outfit).
4. **Accessory scale measured from the reference** (brim vs head/shoulder width).
5. **Sample one character first**, get the workflow approved, then roll out.
6. **Design-first board:** the exact PNG that ships and real candidates (catalog thumbnails/renders,
   lettered A/B/C next to anime frames). Never approve from concept art that gets re-modelled.
7. **Catalog parts by ID** are often the best route for hair/heads: apply via HumanoidDescription on
   R6. They can't be downloaded or retextured (one fixed expression each). Our clothing must then match
   their look: soft painted gradients, muted colours, thin dark lines - hard cel bands read "too bright".
8. **No ink outline shells on clothing next to catalog parts** ("super unprofessional").
9. **Study tutorials frame by frame** before building (auto-subs + a frame every 5-12 s, write the
   steps down, follow them step for step).
10. **Benchmark = the asset the user names.** "As good as the Toolbox X" means look like that model
    (classic head shape, hair silhouette, palette), measured: captures from ~11 angles on a green
    screen, carved silhouettes, sampled colours. A lookalike, never a mesh copy.

## Hair
- Built from **locks** (thick leaf-profile curve strands rooted on the scalp: hairline first, then
  layers), smooth-shaded with hard edges only at lock rims, painted lock lines + gradient. A carved
  smooth hull or sharp thin blades both lost.
- Hand-designed lock blueprint (JSON) -> numbered blueprint image on the board -> build -> independent
  reviewer. Each variant changes one thing from the approved build.
- "Texture" to this user = visible lock definition + gradient, not fine strand noise.

## Clothing
- Modelled shells slightly bigger than the R6 parts (folds outward only, closed sleeve caps, shoulder
  yoke), **hand-painted in each shell's own unwrap**, painted like the catalog part next to it.
- **Coverage gate on every pose and angle** (every R6 box corner >= 0.03 studs inside the shells).
  Rigid per-limb shells detach at big joint angles: add overlap skirts; split the hip shell at the
  hip line; assign whole shells per limb.
- Body details (scars, abs) on the Shirt template under an open shirt.

## Voxel models (props, pets, bosses, stylised characters)
- Code-built voxels beat AI meshes for likeness and animation. 1 voxel = 0.25 studs; head 10^3,
  torso 8x8x4; front faces -Z; in face art the left column is the character's right.
- Tools that worked: ASCII face painting, round + stepped-square spikes, silhouette carving
  `carve(front, side, top)` for hair, Catmull-Rom tubes for serpents, a PIL preview sheet (front, 3/4,
  back) iterated **before** touching Studio.
- Studio build unions each body part, rigs with Motor6Ds under a HumanoidRootPart, backs up the old
  model, sets `PrimaryPart.PivotOffset` to the feet. Animate by anchoring only the root and setting
  `Motor6D.Transform`.
- Common mistakes: bangs over eyes, spikes poking above a smooth crown, blobby round spikes, opaque
  generated meshes hiding things.
- Voxel meshes ignore Part.Color: tint mutations with a greyscale SurfaceAppearance + Color (or a
  Highlight - but max 31 Highlights render at once). ViewportFrames ignore SurfaceAppearance: tint
  with ImageColor3 there.
- Scale: `m:ScaleTo(m:GetScale() * target / m:GetExtentsSize().Y)`; place by the bounding-box feet.

## Meshes, Blender and getting assets into the game
- Run outward-normal recalculation on every generated mesh (an inside-out head shell looks like "no
  face"). Session EditableMesh preview caps: 60k vertices / 20k triangles per mesh - split bigger ones.
- PIL ImageDraw doesn't alpha-blend: composite translucent shapes explicitly.
- Preview before upload by session-baking meshes onto the rig (vanish on reload, don't exist in Play).
- Finals: **File > Import 3D by the user** (rotates pieces 180 deg yaw - batch all fixes into ONE
  re-import) or **Open Cloud Assets API**: export one FBX per form -> POST as Model -> poll the
  operation -> wait for moderation -> `InsertService:LoadAsset` in Edit -> fix 100x scale and 180 deg
  yaw -> place pieces at measured spots -> apply catalog hair/face via HumanoidDescription -> back up
  old model -> sanitize (strip scripts).
- API keys: stored outside the repo (home dir, restricted permissions), scoped to asset uploads, never
  printed or committed. A broad key gets used for uploads only unless the user says otherwise.
- Blender: Standard view transform (AgX lies about colour), headless where possible.
- Toolbox kitbash outfits often weld every piece into one chain off the head: attach each detail part
  to the body part it physically covers.

# Testing and security

## Toolbox and imported assets
- **Incident:** a free Toolbox VFX pack hid `require(<asset id stored in a NumberPose>)` inside a
  ParticleEmitter subtree; it ran from a trail effect. Toolbox content is untrusted code.
- **AssetGuard pattern:** an allowlist of visual classes only (parts, meshes, decals, emitters, beams,
  trails, lights, attachments...). Effects must be leaf nodes. Every non-allowed instance - all
  LuaSourceContainers - is removed. The server sanitizes asset folders at boot before any player joins,
  and every clone site uses `cloneClean()`. Backup folders are sanitized too.
- Strip scripts from every installed model; accessories get stripped too, so flatten them to welded parts.
- Toolbox character scripts (Animate/Health/Sound) kept only as reference in quarantine, deleted before
  launch. Infected archives go to a quarantine folder the user deletes.
- Many "roblox" GitHub repos are malware: never run unvetted ones.

## Server authority
- One RemoteFunction `Action` with a name allowlist, a global rate limit (~12/s), per-action cooldowns on
  heavy calls, a profile-loaded check, pcall per handler, a Studio-only `[Action]` log.
- Validate type, range, ownership and Config membership on every action. No handler takes currency,
  speed, multipliers or prices from the client. Grants only in ProcessReceipt.
- **Client-owned character movement is exploitable.** A WalkSpeed hack could outrun chasers because only
  a per-0.1 s tick was checked; fixed with a ~2 s window check against 1.2x the highest server walk
  speed in the window. Add a path/line check where it matters.
- Debug hooks and dev commands exist only under `RunService:IsStudio()` or are owner-gated in live.

## Data safety
- ProfileStore session locking; a newer-version save guard so a stale server can't overwrite newer data;
  re-sanitize saved fields on load (NaN, type, clamp); BindToClose + rejoin tested; migration tests.
- Test on mock profiles, never the owner save. A set-style debug hook used as a "read" wiped a field on
  the owner save once (restored from DataStore versions) - read hook source first.
- Studio writes the real DataStore when API access is on: snapshot before risky tests.

## Testing approach
- Real input beats synthetic: real MCP clicks; an abuse run (290 invalid calls confirmed the rate
  limit); save round trip; rejoin. Keep specs in `tests/*.spec.lua`.
- Path checker for NPC routes (0 raycast hits), server action audit, src==Studio hash audit,
  workspace leftovers sweep, "approved but unbuilt" sweep with file:line evidence. Delete nothing
  without the user's OK.
- Never claim a fix from one angle; an independent reviewer checks captures. Mark unverified items.
- Security reviewer pass on every remote, purchase and data change before launch.

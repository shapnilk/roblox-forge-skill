# UI, HUD and onboarding

User complaints that drove these rules: corners sticking out, too much text, UI not scaling to all
devices, PC HUD too small, hand pointers unclear, auto-closing tutorial cards too rushed.

## Build system
- **Design on a canvas board first**, then export board art 1:1 (headless Chromium: hide everything
  but one SVG, transparent background, auto-crop, write a `meta.json` with placement) so in-game
  placement is exact.
- **One shared Style module:** colour tokens, role gradients, block/button/card/toast kit, typography
  (e.g. FredokaOne + thick black UIStroke; italic weight for numbers via `Font.new(..., Italic)`).
  Every panel is built from it.
- **One board-px -> screen-px scale.** Height-only scaling made PC 10% too small. E.g.
  PC `clamp(min(W/1365, H/710), 0.9, 1.6) x userSetting`, phone `clamp(min(W/812, H/340), 0.85, 1.3)`.
- `floorText` pass raises TextSize to a minimum (round up - TextSize renders whole numbers); store
  original sizes in attributes so repeat passes don't compound.
- Device breakpoints (phone / tablet / desktop / console); panels scroll on phones.

## Phone rules
- Touch targets >= 44 px; test at 812x375 via a Studio emulate hook; bottom sheets on phone; hide nav
  and hotbar under sheets; ScreenGui uses CoreUISafeInsets; hide the Backpack CoreGui and bind keys via
  ContextActionService. A real-phone check is still required before launch (emulation is not a device).

## Traps
- `ClipsDescendants` ignores UICorner: give headers/shines their own UICorner (+ a filler), shine as a
  gradient on a rounded overlay.
- Top tabs inside the Roblox top bar: offset by `GuiService.TopbarInset.Height` and re-pin when it
  changes (it's 0 at start). An Fx layer with no inset needs `GetGuiInset()` when flying icons to HUD
  targets.
- ScrollingFrame: CanvasPosition is in screen pixels (re-scroll on scale change); a drag must never
  count as a click; mouse wheel needs manual steps; show the scrollbar only on overflow.
- Z-order: persistent HUD widgets (meters, weather pill) on a low-layer ScreenGui under open panels.
  Dim + BlurEffect behind large panels.
- World labels (BillboardGui) sized in studs, not pixels - pixel labels pile up across a pen of 30.
  Show world labels only on your own plot; HUD slot text only on events.
- Portraits = ViewportFrames; unknown index entries as silhouettes.
- Flat ground text: a SurfaceGui on a part's Top face runs across the short axis. Use a board tipped
  back 90 deg with its Front face up; check from eye height.

## Juice ("dopamine kit")
- Number roll-ups; icon flies into its counter with a punch on every gain (cash, speed, shards).
- Reusable **claim moment**: panel bursts away -> reward slams in on a sunburst -> count-up -> Bezier
  fly to the counter; tap to fast-forward. Reused for daily, welcome-back, unlock, summon.
- CLAIMED stamps, rising chime on back-to-back claims, Claim All, confetti, screen shake, 2-frame
  impact flashes, letterboxing for moments.
- Sound on every interaction - the game felt flat until it had any SFX.
- Confirm popups for anything destructive or rare (auto-selling legendaries, selling an awakened unit).
- Interactions: ProximityPrompts ("E - Object - Action") plus walk-on pads.
- Don't copy reference games' signature UI animations; give them a theme twist (an anime hand-seal +
  smoke poof instead of a generic open-hands hover).
- No emoji icons: glossy outlined stickers rendered from SVG icon sets (game-icons.net CC BY 3.0 -
  credit it - or Phosphor) with an ink outline, drop shadow, gradient fill and gloss.

## Tutorial / onboarding (playtested rules)
- No hand or mouse-pointer cues: a big bobbing gold arrow, even for UI buttons.
- Explain pop-ups stay until the player taps GOT IT, which fades in ~2 s after opening. Never auto-close.
- Big, distinct boost bubbles (~140 px desktop / 120 px phone).
- Keep it simple: one unit during the tutorial, passive systems start after the final "let's go", no
  unlocks mid-tutorial, never a dead wait without saying what the player is waiting for.
- Log every funnel step with a timestamp; preview the flow on mock fresh/returning profiles.
- CTA buttons (PLAY etc.): one strong brand colour body with a darker lip, **white label with a dark
  outline** - never coloured label text.
- Reference panel style that worked: coloured stud header, red X, translucent dark body + blur.

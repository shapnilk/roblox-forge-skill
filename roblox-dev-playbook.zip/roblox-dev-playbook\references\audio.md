# Audio and SFX

## Architecture that worked
- **One data table `Shared.Sfx`:** event -> ids / variants / SoundGroup / volume / pitch jitter /
  cooldown / maxVoices / streak step. Old names alias to events. ~100 events covered the game.
- **A/B/C candidates ship until the user picks.** A Studio-only **SoundTest panel** plays each event's
  candidates in context; picks print (`PICK event=B`) and go into a `SfxPicks` module that overrides.
  A coverage check confirms every candidate loads.
- SoundGroups: Music / SFX / UI / Cutscene. A `SfxMix` loudness pass at the end.
- Risky cue sets stay switchable (`Sfx.OFF` list) until the user approves them.
- Music: BGM starts on the loading screen and is adopted mid-track by the game (no restart); a chase
  theme keyed off a "Carrying" attribute; save/restore BGM around cutscenes. Loading-screen sounds need
  inline ids (Shared modules aren't replicated in ReplicatedFirst yet).

## Design rules
- Respond within 50 ms. Layer rewards (high transient + mid body + low thump); routine cues one layer.
- 5-tier importance ladder; only the top tiers duck music.
- Streak escalation steps up a pentatonic scale, capped, resets after a gap.
- Anticipation -> 0.1 s vacuum -> impact for big moments. +-4% pitch jitter on non-musical cues.
- Per-cue cooldown and voice cap.

## Licensing
- Routine cues from Roblox's licensed library (APM / ProSoundEffects). No copyrighted music.
- If the user wants anime voice/SFX/themes, flag the copyright-audio takedown risk and keep a licensed
  fallback for every ripped cue.
- Uploads via Open Cloud (audio assets) with the scoped key; wire ids after moderation.

## Cutscene audio
- One continuous scene track per cutscene in the Cutscene group, stopped on skip.
- **Sync to the actual cutscene video, not the beat sheet** - the video wins. Show audio as a preview MP4
  with audio muxed in, never bare WAVs.
- Use the exact theme/section the user names (the main melodic hook, not the drum section); confirm the
  track title - a similarly named track was wrong twice. Screams never fade in or get cut off; a
  heartbeat must sound like a heartbeat (a synth lub-dub was approved, drums weren't).

# Animation and cutscenes (R6)

Quality bars the user approved: a Gear 5 floating laugh (60 fps curve bake) and an SSJ transformation
keyed by eye in Blender ("the best you've made"). Rejected: per-key eased poses ("choppy"), fake knee
bends, twitching arms, low-fps preview video.

## Process
1. **Ask what the animation should be** before making any character's animation. Propose concepts with
   YouTube/online reference links; build only after the user picks.
2. Concept board: 2-3 reference frames + 2 lettered poses rendered on the real installed model from the
   viewer camera.
3. 2-3 representative samples first (reference beside ours, same camera, key strip, timing note);
   roll out after approval.
4. Pose by eye in Blender on the R6 rig, hands by **IK to targets** read off the reference frame
   (forehead, belly across the torso, knees in world space).
5. Key on a 24 fps grid, **bake to 60 fps** from Catmull-Rom curves, play with cubic interpolation.
6. Gates: pose plausibility (floor contacts, no sitting on air), clothing coverage on every pose.
7. Per-character effects, then ship.

## Craft rules
- **Never ease to a stop at every key** - per-segment Sine reads choppy. Dense curve bake; shake layers
  as smooth cosine bumps at 2-3 Hz (no |sin| cusps). Check max acceleration per frame.
- Arcs, anticipation before a snap, overshoot then settle, overlap/follow-through, breathing in holds,
  head and limbs lag the torso 2-3 frames. Stepped (on 2s) only for impacts, not idles.
- Line of action + contrapposto on the single torso block; uneven leg splay, never mirrored arms.
  Exaggerate (20-30 deg) but planted legs stay within +-20 deg pitch.
- **R6 has no knees.** Tilting a whole leg to fake a bend looks like sitting on air. Crouch/power
  stance = wider A-frame (legs out 8-15 deg), feet flat, compression sold by torso hunch and arms.
- **Straight-arm R6 is the default (ABA style).** Crossed arms = two straight arms in a tight high X.
  Bent-limb pieces only when a pose truly needs an elbow/knee.
- **Silhouette at the viewer camera:** an arm pointing at the camera disappears; yaw the figure 55-70
  deg so the action arm is in profile. Lean-backs and lying poses read badly on R6 - floating worked.
- Head pitch sign: Head x>0 tilts the face UP (CFrame.Angles).
- Planted feet via smooth plant weights; auto-ground every frame.
- Idle = pose A, B, A cyclic with late head/arms. Showcase viewer: camera ~12 deg above, gentle sway
  (not a spin), floor disc, 60 fps everything (animations, sway, light rays, VFX).

## Pipeline notes
- Animations can't be published over MCP (`CreateAssetAsync` unavailable). Play them through an
  in-game pose player from baked keyframe data, or publish manually / via Open Cloud.
- Export `.rbxanim` from Blender (an exporter add-on); `.rbxanim` carries no camera track, so the
  camera stays in Studio.
- **After changing the shared baker, rebake EVERY character.** Missing bones must hold their last key;
  a stale bake snapped bones to rest and the arm twitch came back.
- Merge clips with a merge tool; never regenerate the clips file wholesale - it overwrote hand work.
- Procedural `Motor6D.Transform` does nothing in Edit (no physics step); the Animator path works in
  Edit via `StepAnimations`.

## Cutscenes
- **Storyboard first** on the design canvas (stage map, shot list, timing). The board is the master
  spec: capture each shot next to its board frame.
- Faces per shot from the storyboard, user-approved faces only.
- Fluid motion: eased camera moves; hard snaps only where the board calls for impact. Twitch keys must
  not bleed into other beats (a heartbeat moves the chest only, never the arms). Rises are smooth; no
  dropping back mid-float.
- **Impact frame:** ~8 frames (0.13 s) of white / silhouette / inverted, then a hard shake back into
  action. No lingering hold; no speed lines unless boarded.
- Hide your own avatar (LocalTransparencyModifier); keep a counter of running cutscenes so overlaps
  don't re-show the HUD early; restore CameraType Custom and Lighting after; pause world systems via a
  flag; hold-to-skip after first view; skip jumps to the title + count-up.
- Cutscene models live in a storage folder with required attributes (Part, Center, Yaw...) - a missing
  attribute crashed one; validate them at load.
- Big moments can play on a themed off-map stage only the triggering player sees; everyone else gets a
  server banner + a light beam at that player's base.
- **Delivery:** give a Studio preview command (Play + a command-bar `playEdit()`). For video, record
  frame-locked: step the clock 1/60 s per frame, stamp a frame tag, keep one grab per tag. A
  free-running 12 fps screen grab duplicated frames ("fps issues").
- Never claim a clothing/pose fix from one angle; a fresh reviewer checks every shot first (the user
  caught false "fixed" claims three times).

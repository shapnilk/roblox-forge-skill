# Map and world building

## Approach
- **Data-driven, idempotent builder.** A shared `MapLayout` module (coordinates used by the builder,
  server and client) + palette table + per-world table, consumed by `ServerStorage.Tools.BuildMap.Build()`.
  Re-running rebuilds cleanly; keep the previous map as a `*_pre_<round>` backup.
- **Board the layout first** (map blueprint on the design canvas) and compare against the reference
  game's screenshots. The approved layout example: 4 plots behind a painted SAFE ZONE line facing one
  open world of terraced biome bands - further = harder. Plot = back half pet pen, front half machines.
- Content is data: worlds/zones are Config rows read by one hook; no `if world == 7` in code.

## Visual rules learned
- **Measure real colours in-engine** against the palette: Atmosphere haze turned grass teal (reduce
  haze, near-neutral colour); tint stud textures so grounds keep their swatch hue; snow needs a darker
  chip than the swatch under sun. A colour-chart calibration stage helps.
- "Black world" reports may be the day/night cycle, not the palette - check time of day first.
- **Z-fighting scan:** a tool that finds coplanar different-colour parts and grows the smaller one
  0.02+ out of the plane. Run it inside the builders **before** colour unions (after unioning faces
  can't be checked).
- Flat painted ground text: a board tipped back 90 deg with the Front face up (Top-face SurfaceGuis run
  across the short axis); verify from eye height and from the side players approach.
- Clean cube voxels / stud style when the reference game uses them; generated props stashed into
  `ReplicatedStorage.Assets.Props` via a stash tool; check generated props in a lineup for facing.

## Gameplay geometry
- **Paths must be walkable:** NPC/clone routes follow funnel mouths and gaps between nests; verify with
  a raycast path checker over every plot x world x route segment - target 0 hits. (A canyon wall once
  silently blocked the funnel.)
- **Pads checked server-side** (part attribute "Pad" + a PadService). Client-side touch wiring broke
  under StreamingEnabled and "upgrades don't work" was the result. If StreamingEnabled is off, every
  instance in workspace downloads to every client - 4.8k leftover test instances cost every player.
  Keep test rigs and study stages in ServerStorage; sweep workspace before publish.
- Pads + ProximityPrompts share one server action.
- Free placement (eggs/furniture): the server validates type, NaN, range, grid snap, integer rotation,
  plot bounds and cooldown, in plot-local coordinates so nobody can target another plot.
- Movement must show progress: walk speed from a log curve of the stat (e.g. `16 + 5*log10(speed)`,
  capped ~110); chasers run at walk(requirement) x 0.93 - caught below the requirement, narrow escape
  at it, easy above. Keep the table in the econ sim.
- Milestone notifiers ("FAST ENOUGH for <zone>!") shown once per world (saved flag).

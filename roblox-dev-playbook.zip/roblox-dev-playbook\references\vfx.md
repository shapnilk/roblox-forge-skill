# VFX that read as anime

Approved: script-drawn Conqueror's Haki and Super Saiyan auras ("honestly better than the toolbox").
Rejected: first procedural flipbooks, one aura recoloured across many trails, floor glows.
Detailed scripts/gotchas: roblox-forge `references/vfx.md` if installed.

## Loop (every effect)
1. **Reference frozen in 15 min:** user's words + stills (pull frames from video, sample hex with code).
2. **3-6 numbered targets with numbers** in `<EFFECT>_TARGETS.md`: shape in studs vs the R6 body,
   colours (hex), timing (s), density, glow, cost.
3. **Pick a 4-7 layer stack before drawing:** hero shape, life-cycle accent, strokes, dark secondary,
   glow, rim light.
4. **Author textures by script** (numpy + PIL; 8x8 or 2x2 flipbooks), preview each frame tinted over
   grey, run a validator (padding, halos, alpha) before upload.
5. **Upload 512 px optimized PNGs** (1024 px ~1.4 MB uploads sometimes never load). `PreloadAsync` can
   report Failure for images that render: apply the id and verify by capture.
6. **Same-camera capture vs the baseline** (Toolbox effect 8 studs away, ours on the right): close,
   gameplay 25 studs, back 3/4, 2-3 live frames each.
7. Judge each frame against each target (independent reviewer), change 1-3 things per round, max 3
   rounds, snapshot each version, then the user's verdict.

## Look rules
- Default Roblox particles read as soft blobs. Anime = hard edges, 2-3 tones, ink rim; **dark cores
  with coloured glow and big silhouettes around the body**.
- Dark cores need `LightEmission 0` (normal blend); at LE > 0 dark colours turn transparent. Pre-colour
  the sheet and set Color white, or author greyscale and tint with Color.
- Additive accents vanish over a bright layer: use LightEmission ~0.3 for accents on top of a glow.
- **Stacked translucency:** Rate x Lifetime overlaps ~4 copies; author centre alpha <= 0.1 with a rim
  band, or it stacks into a solid wall.
- Soft-fade the art box edge and bleed transparent texels, or the glow shows a rectangle / halos.
  Author 16 px cell padding at 1024 if a 512 copy is made.
- Set `LightInfluence = 0` and `FlipbookBlendFrames` explicitly - `Instance.new` defaults differ.
- **Each character/trail gets its own effect.** Recolouring one aura across trails was rejected.
  Recipes can re-hue (`redden(recipe)`) but the shape must fit the character.
- Transform auras: VFX on the player's own avatar (no model swap), reach the feet, **no floor glows or
  rings, no ribbon behind the feet**, never stack (pause body emitters while transformed), keep
  colours distinct from other trails.
- Restore a look the user liked rather than replacing it.

## Emitter mechanics
- Auras: `LockedToPart`, large Size (6-9 studs), `ZOffset -1..-1.5` to sit behind the body. The quad
  renders ~1.8x Size; put the attachment at ~0.76*Size above the feet.
- A Box shape on a small attachment spawns inside the body where it's hidden: put side attachments at
  +-1.8 studs. Box + Surface emits from one face.
- FlipbookMode Random for flicker.
- Many Toolbox auras fire ~1 short sprite at a time (rate 5, life 0.2): they blink and captures miss
  them. Raise rate so lifetimes overlap. Toolbox auras ship disabled - enable every emitter to audition.
- Scale auras by `hero:GetScale() / BodyScale`, never a blanket multiplier (a blanket x2 sank one aura
  3 studs into the ground). Clamp test dummies' feet to the floor.
- Effects with Beams: copy the WHOLE aura folder (Beams included) to clones/cutscenes, not just
  Attachments. Swaying tails/clouds: tag them and sway on the client (never a full spin if the loop is
  open at the front).
- **ViewportFrames draw no particles, Beams, Trails or BillboardGuis.** Use card flipbooks: a thin part
  whose Texture steps through the sheet at ~12 fps.

## Performance architecture
- One pooled client VFX library: templates built once, pooled attachments + `Emit(n)`, no per-hit
  property changes, each template declares its cost.
- Slot pools need `life < minGap x slots` or a slot moves while its particle lives.
- Priority chain: gameplay cue > mine vs theirs > player setting (Everyone / Reduced others / Only
  mine) > distance > budget. Result FULL / CHEAP / SPARK / NONE. Never hide telegraphs.
- Tier caps (live particles ~1500 / 800 / 350 for High / Med / Low); auto-drop a tier after 10 s
  under 45 FPS with an Undo toast. Offer an "only my VFX" setting.
- Deduplicate before building: 49 effects served 68 moves; one greyscale flame sheet tinted 4 ways.
- Keep every effect in one recipe tool (`Tools.VfxBuild`) so rebuilds are consistent.
- EditableMesh is blocked in Play unless the experience setting allows it: use imported meshes for
  anything that runs in Play.

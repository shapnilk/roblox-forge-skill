#!/usr/bin/env bash
# UserPromptSubmit hook: on Roblox prompts, tell Claude to load roblox-dev-playbook
# and name the reference file(s) for the domain the prompt is about. Silent otherwise.
# No jq needed: matches against the raw hook JSON (prompt + cwd), lowercased.

input=$(cat 2>/dev/null | tr '[:upper:]' '[:lower:]')

# Extra project markers can be added via env, e.g. ROBLOX_PLAYBOOK_MARKERS="mygame|otherproj"
markers='roblox|luau|rbxl|rbxm|rbxassetid|execute_luau|humanoid|r6 rig|workspace\.|replicatedstorage|serverscriptservice|game ?pass|dev(eloper)? product'
[ -n "$ROBLOX_PLAYBOOK_MARKERS" ] && markers="$markers|$ROBLOX_PLAYBOOK_MARKERS"

echo "$input" | grep -Eq "$markers" || exit 0

# Domain routing looks at the prompt text only (not cwd/transcript paths).
prompt=$(echo "$input" | grep -oE '"prompt" *: *"([^"\\]|\\.)*"' | head -1)
[ -z "$prompt" ] && prompt="$input"

refs="workflow-lean.md"
add() { case " $refs " in *" $1 "*) ;; *) refs="$refs $1" ;; esac; }
has() { echo "$prompt" | grep -Eq "$1"; }

has 'aura|particle|vfx|flipbook|beam|trail|lightning|flame|glow|emitter|effect' && add vfx.md
has 'character|model|r6|voxel|face|hair|cloth|outfit|mesh|blender|import 3d|open cloud|accessor|pet|boss' && add modeling-characters.md
has 'animat|pose|idle|showcase|cutscene|keyframe|impact frame|camera shot' && add animation-cutscenes.md
has '\bui\b|hud|panel|button|shop|menu|tutorial|onboarding|gui|scal|phone|mobile|icon|thumbnail' && add ui.md
has 'map|world|terrain|plot|base|prop|path|ground|biome|lighting|build ?map' && add map-building.md
has 'sound|sfx|music|bgm|audio' && add audio.md
has 'econom|pacing|price|robux|pass|product|receipt|launch|publish|liveops|update|retention|monetiz' && add economy-launch-liveops.md
has 'exploit|remote|anti.?cheat|datastore|profilestore|toolbox|backdoor|secur|test|audit|migrat' && add testing-security.md
has 'studio|mcp|push|capture|screenshot|debug|admin|command' && add studio-mcp.md

list=""
for r in $refs; do list="$list references/$r,"; done
echo "Roblox task detected: load the roblox-dev-playbook skill (if not already loaded this session) and read only:${list%,}. Follow its non-negotiables."
exit 0

# Roblox Studio MCP: code layout, pushing, testing, gotchas

## Code layout that worked
- `src/` = flat files named by DataModel path: `ServerScriptService.Services.Shop.lua`,
  `StarterPlayer.StarterPlayerScripts.ClientMain.Hud.lua`. Disk is the source of truth.
- **Push:** `python -m http.server <port>` in `src`, then in Edit mode
  `require(ServerStorage.Tools.Push:Clone())({paths})` - the tool toggles HttpEnabled, GETs each file,
  writes Source. Use `ScriptEditorService:UpdateSourceAsync` for scripts over ~200k chars.
- `HttpService:GetAsync` caches: pass `nocache = true` and a `?t=<time>` query.
- **src == Studio audit:** normalise CRLF + trailing whitespace, hash (FNV-1a) in Studio and on disk,
  report match / differs / missing / Studio-only. Back up to `backups/<task>_<date>/` before pushing,
  and refuse to push if Studio differs from your pre-edit baseline (someone else changed it).
- **The command bar caches requires.** After pushing shared modules, re-clone them (push fresh
  ModuleScript instances) before running builder tools.
- Server: services with `Start()`; ProfileStore data service with TEMPLATE + Reconcile (new fields need
  no migration); a State module pushing snapshots to the client; one RemoteFunction `Action` router;
  a Notify RemoteEvent for UI events.
- **Builders as tools** in `ServerStorage.Tools` (BuildMap, VoxelBuild, VfxBuild...). Re-running a
  builder must be idempotent and back up what it replaces.

## execute_luau
- Stateless: a fresh `require` of a service is a separate copy whose data is nil. Reach live state
  through debug hooks, not requires.
- Can't run Edit-mode code while Play is running - stop Play first.
- Camera changes from it get reset by the assistant; bind a RenderStep camera from the Client
  datamodel for Play captures (`Camera.Value + 2` priority), unbind after.

## Debug hooks (essential for MCP testing; Studio-only or owner-gated)
- Server `Main.Debug:Invoke(player)` -> live data; `(player, "__call", Action, ...)` runs an action as
  that player through the real code path.
- `AdminDebug:Invoke(player, "/cmd", arg)` runs chat admin commands (chat can't be typed via MCP input
  - CoreGui has focus).
- Client `PlayerGui.Main.Debug:Invoke("open", "Shop")`, `("emulate", 812, 375)` for phone size.
- **Trap:** a set-style hook `Debug:Invoke(p, field, value)` called with no value to "read" a field
  set it to nil and an autosave wiped the owner's progress (restored from DataStore versions). Read
  the hook source before calling; never use setters for reads.
- **Owner admin commands save hours:** `/everything`, `/cash`, `/speed`, `/world`, `/resetme`,
  `/allclones`, plus **preview commands** for every visual moment (`/cutscene`, `/transform`,
  `/claim`, `/daily`, `/onboarding`). They grant nothing permanent and use the real code path.
- **Mock profiles** (`ServerStorage` attribute, "fresh" / "returning" fixtures) test first sessions
  without touching the owner save. Snapshot the owner save before and after risky tests.

## Captures and input
- Edit-mode `screen_capture` needs camera position + look-at; capture_id is required.
- Edit-mode particles only spawn near the Studio camera: set `workspace.CurrentCamera` at the shot and
  wait ~2.5 s. Particles don't simulate in Edit captures of inserted Toolbox effects - check in Play.
- Particles look tiny or absent at ~40+ studs; check effects up close.
- Captures are scaled (e.g. viewport 1365x768 -> image 1113x626). `user_mouse_input` takes real
  viewport GUI coordinates; find button centres via AbsolutePosition. A recursive
  `GetGuiObjectsAtPosition` shows what is eating a click.
- Reviewer pixel estimates from downscaled captures are off by the scale factor (~x0.77).
- Studio FPS is throttled when unfocused: FPS measured through MCP is meaningless.
- A green-screen part behind the subject + narrow FOV gives clean crops for boards.

## Other gotchas
- `generate_mesh` fails while Play runs; fire 3-5 async, then wait. Moderation rejects some words
  ("toad", "nine tailed", signature details like "scar") - rephrase ("frog", "fox with many tails").
  Generated meshes face random directions: line them up and fix.
- `model.WorldPivot` doesn't stick when the model has a PrimaryPart: set `PrimaryPart.PivotOffset`
  (e.g. feet at origin).
- Recursive `FindFirstChild(name, true)` is dangerous ("Fill" found a GUI frame, "Head" found model
  heads). Use direct paths.
- `Lighting.Technology` can't be set from MCP. CSG `UnionAsync` needs parts parented first.
- `CreateAssetAsync` is unavailable over MCP: meshes go through File > Import 3D (user) or Open Cloud.
- Editing files from bash: heredoc Python replacements break on tabs/quotes/`\n`. Write the edit
  script to a file, use unique anchors (`count == 1`), pass `encoding='utf-8'` on Windows; slicing on
  a non-unique anchor once corrupted a file. Prefer the Edit tool.
- Windows file names are case-insensitive: `Shirt.png` overwrote `shirt.png`. Prefix outputs.
- Team Create drafts: before publish the user commits drafts (View > Drafts), saves, publishes, then
  "Migrate to latest update" - old servers keep running the old version ("old plus new" bug reports).

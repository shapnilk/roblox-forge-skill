# roblox-dev-playbook

A Claude Code skill with the workflow and lessons from building a full Roblox game
("Steal Eggs with Anime Clones", an anime clone-heist simulator) with Claude Code and the Roblox
Studio MCP server. It covers lean multi-agent orchestration, Studio MCP habits, VFX, modeling and
characters, animation and cutscenes, UI, map building, audio, economy, launch, LiveOps, testing and
security.

`SKILL.md` is a short router. Each domain lives in its own `references/*.md` file, so a session only
loads what it needs: a VFX task reads `vfx.md`, a shop panel reads `ui.md`, and so on.

## Install

1. Copy this folder to `~/.claude/skills/roblox-dev-playbook/`.
2. Optional but recommended: turn on auto-routing. Add this to `~/.claude/settings.json` under
   `hooks.UserPromptSubmit[].hooks`:

   ```json
   {
     "type": "command",
     "command": "bash ~/.claude/skills/roblox-dev-playbook/hooks/roblox-router.sh",
     "timeout": 5
   }
   ```

   On every prompt that mentions Roblox (roblox, luau, rbxl, ReplicatedStorage, game pass, ...), the
   hook adds a one-line note telling Claude to load the skill and which reference file(s) to read. On
   any other prompt it prints nothing. To also match your own project names or folders, set
   `"env": { "ROBLOX_PLAYBOOK_MARKERS": "mygame|myproject" }` in settings.json.

Requires bash (on Windows, Git Bash). No other dependencies.

## Companion skill

`roblox-forge` (separate) holds the scripts for own-art VFX flipbooks, R6 faces, hair, clothing and
KeyframeSequence animation. This playbook is the process around those scripts and works without them.

## Contributing lessons

Add one line to the matching reference file: the lesson, then why (what failed).

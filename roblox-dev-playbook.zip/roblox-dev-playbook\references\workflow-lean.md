# Lean multi-agent workflow

The build hit usage limits three times in one day running ~15 parallel Opus agents with 150-480k-token
transcripts that kept waking up to wait for Studio. The rules below fixed it.

## Staffing
- **At most 2-3 background agents at once.** One per independent track (e.g. art boards, code, uploads).
- **One agent owns Studio.** Anything that needs Studio runs sequentially inside that one agent. Never
  queue several agents on a Studio lock - each wake-up reloads its whole history.
- **Model per task:** Sonnet for routine work (installs, uploads, pushes, checks, mechanical fixes);
  Opus only for design / creative / judgement (VFX, animation, art, character likeness).
- **Fresh agent + short self-contained brief** beats resuming a bloated one. Batch many items
  (characters, pets, icons) into one sequential agent instead of one agent each.
- **Reviewer agents only for risky work, one round max** - an independent reviewer (not the builder)
  for visual deliverables; no "verification-only" agents for routine work.
- **No recordings/videos by default.** Stills when needed; give the user in-game preview commands instead.
- Short agent reports; short replies to the user; don't relay every "still waiting" notice.

## Parallel tracks without stalls
- Keep every independent track moving while you discuss one item with the user in chat.
- Feedback on one track = a **new follow-up agent carrying only the delta**.
- **Never SendMessage an agent that is still running inside a Workflow.** It starts a second resumed
  copy with the same id; both write the same files and overwrite each other. Let it finish and run a
  fix pass, or stop it, edit only prompts that haven't run, and resume.
- **Show results as they land.** Poll the run's journal/output files between other work; send each
  finished image/board immediately instead of waiting for the whole run.

## Studio lock (when more than one agent might touch Studio)
- Edit-mode code pushes need no lock, but never push while Play is running.
- Play or >1 min of captures needs a lock line: `HOLDER: <agent> | <what> | since <time> | ~N min`.
  Release with one LOG line. Take over only if the hold is 20+ min stale, and log it.
- Agents overwrote each other's HOLDER lines and usage cut-offs left stale holds for hours: re-read the
  lock right before Play; a main-session QUEUE order resolves contention.
- **Restore after every hold:** Lighting, Camera FOV 70 + CameraType Custom, remove temp workspace
  objects, HttpEnabled back to false, stop the local http.server. Log ends with "place NOT saved".
- Studio's MCP id changes on restart: list studios first.

## Agent briefs (template)
- Goal + done-criteria, exact files/instances to touch, the domain rules to paste **verbatim**
  (character rules, cutscene lessons, tutorial UX rules...), the lock protocol, "never save/publish",
  "never revert another agent's edits - re-read a file right before editing it and touch only your
  lines", and the report format: short, capture paths, list of unverified items / user decisions.
- Build agents that skipped the approved pipeline (wrote characters from scratch instead of reusing the
  approved face/model scripts) produced the worst rejection of the project. Brief them to **reuse the
  approved script for this asset type first**.

## Docs that keep a long project coherent
- `PLAN_<topic>.md` with "round N" sections recording each batch of user decisions.
- `HANDOFF.md` from a read-only sweep: state; done + approved; in progress (agent / scope / latest /
  left); not started; owner tasks and decisions; risks; how to work; checklist status. Mark "unverified".
- `<ASSET>_TARGETS.md` with 3-6 numbered, measurable targets per visual asset.
- A user-decisions list (title, IP stance, launch scope, rejected options) so agents don't re-argue.
- `PREVIEW_COMMANDS.md`: how the user can see every moment in Studio without grinding.

## User's machine
- Low RAM (16 GB, often ~1.5 GB free): prefer headless Blender, close helper apps you opened, never run
  heavy jobs in parallel.

---
name: roblox-dev-playbook
description: Battle-tested playbook for building a Roblox game end to end with Claude Code + Roblox Studio MCP, distilled from shipping an anime simulator ("Steal Eggs with Anime Clones"). Load it at the START of any Roblox, Luau or Roblox Studio task - scripting, VFX/auras/particles, characters/models/R6/voxel, animation/cutscenes, UI/HUD, map/world building, audio/SFX, economy/monetization, launch/publish, security/DataStore, or multi-agent orchestration of a Roblox build - then read only the reference file for the domain at hand. Covers the lean agent workflow, Studio MCP gotchas, and the approval loop that turned rejected art into approved art.
---

# Roblox dev playbook

Lessons from a full Roblox build (anime clone-heist simulator, ~2 weeks, Studio MCP only for 3D,
Blender for animation/clothing). Every rule here cost at least one rejected round. Read this page,
then **only the reference file(s) for the current task** - do not load them all.

## Domain routing (read the matching file before acting)

| Task mentions | Read |
|---|---|
| any Roblox task (always, once per session) | [workflow-lean.md](references/workflow-lean.md) |
| Studio MCP, execute_luau, push code, captures, debug hooks, admin commands | [studio-mcp.md](references/studio-mcp.md) |
| aura, particle, VFX, flipbook, beam, trail, lightning, flame, glow | [vfx.md](references/vfx.md) |
| character, model, R6, voxel, face, hair, clothing, mesh, Blender, Import 3D, Open Cloud upload | [modeling-characters.md](references/modeling-characters.md) |
| animation, pose, idle, showcase, cutscene, camera shot, impact frame | [animation-cutscenes.md](references/animation-cutscenes.md) |
| UI, HUD, panel, button, shop, tutorial, onboarding screen, scaling, phone | [ui.md](references/ui.md) |
| map, world, terrain, plot, base, props, paths, ground text | [map-building.md](references/map-building.md) |
| sound, SFX, music, BGM, audio mix | [audio.md](references/audio.md) |
| economy, pacing, prices, game pass, dev product, receipts, launch, publish, LiveOps, updates | [economy-launch-liveops.md](references/economy-launch-liveops.md) |
| exploit, remote, anti-cheat, DataStore, ProfileStore, Toolbox asset, backdoor, tests, audits | [testing-security.md](references/testing-security.md) |

For own-art scripts (flipbook generators, face painters, hair/clothing pipelines, KeyframeSequence
builder) use the companion skill **roblox-forge** if installed; this playbook is the process around it.

## The non-negotiables

1. **Plan first, gate on samples.** Multi-part work goes through plan mode. New pipelines (models,
   VFX, animation) build 1-3 samples, show them, and wait for approval before rolling out.
2. **Trace -> approve -> build 1:1.** For every visual part: trace from reference frames (proof =
   frame + traced points), mock it on a real Studio capture, put lettered options on a design board,
   get a per-letter OK, then build exactly that. Building from memory or guesses is what got rejected.
3. **Match the reference game when unsure.** Keep reference screenshots in the repo with an INDEX.md
   and compare before claiming "matches".
4. **Proof = same-camera side-by-side.** Reference/baseline left, ours right, same camera, FOV 70,
   close + gameplay distance + back 3/4, live frames. Never claim a fix from one angle or one pose.
5. **Server owns every number.** One validated, rate-limited action router; client never sends
   currency, speed, prices or multipliers.
6. **The user saves and publishes.** Agents never Ctrl+S or publish. MCP-made assets live only in
   the open session, so remind the user to save after every round.
7. **Lean agents.** Max 2-3 background agents, one agent owns Studio, Sonnet for routine, Opus for
   creative judgement, fresh short briefs. See workflow-lean.md.
8. **Toolbox = reference and bar to beat, never trusted code.** Sanitize every inserted asset
   (allowlist, strip scripts) - a Toolbox VFX pack shipped a hidden `require()` backdoor.
9. **Adopt research only when a test wins.** Sort findings into adopt / test-first / skip; keep the
   working method as fallback; skip paid tools, GPL/AGPL code copies, unvetted repos.
10. **Record decisions so they are never re-argued.** Locked title, IP stance, launch scope and
    per-asset verdicts go into the plan/handoff doc; newest user words beat older plans.

## How the user-facing loop ran (worked well)

- The user plays the build, then sends long batches of fixes with reference screenshots.
- Each batch -> plan section ("round N") -> parallel tracks (code, world, UI, art boards) -> results
  shown **as each piece lands**, not when everything finishes.
- Visual work is reviewed on a canvas of boards (one artboard per comparison round, newest first,
  lettered variants). The user pins a pick; unpicked slots default to the reviewer's choice.
- Each variant changes **one thing** from the last approved build; prefer two variants side by side
  over a redesign.
- Ship-readiness is a gate table with evidence; anything unverified is listed as unverified.

## When you learn something new

Add it to the matching reference file as one line: the lesson, then why (what failed). Keep files
terse; delete rules that turn out wrong.

# Economy, monetization, launch and LiveOps

## Picking and scoping the game
- Remix a breakout with a clear differentiator, keep its proven loop nearly identical (the user judged
  the original's loop "much better" than our redesign - copy the loop, change the theme/hook).
- Check the wave first (CCU trend, session length, reskin performance). Reskins of a wave hold
  ~2-3k CCU: that's the realistic target. Waves fade: **ship the MVP in 1-2 weeks.**
- Pre-launch success audit (what actually matters): ship fast; the hook shows in title, thumbnail and
  first minute; phones run it smoothly; the first 60 s are fun. Lead the title with the differentiator
  and avoid names already taken. **Freeze art at the launch set** (e.g. 2 headline characters); the rest
  is updates behind feature flags (`Config.Features.*`).
- New games sit behind a 16+ trial until ~250 engaged players: earn them via friends tests, small ads and
  first-60-second fixes rather than paying to expedite.
- Thumbnails: bright, 0-3 words, gameplay in the world. This user hates "AI-looking" and loud art.
- IP lookalikes (renamed near-pun characters, no exact names/logos/technique names): if the user accepts
  the risk, record it and don't re-argue; ask before adding each character.

## Economy
- **Econ sim script mirrors Config**; rerun after any pacing change. Tune against a "slow free player".
  Example pacing: world 2 ~3 min, first rebirth ~11 min, final world ~12 h.
- Compare against the reference game side by side, cite sources, mark unknowns honestly.
- Gate worlds on stat + a key item so veterans get hours, not minutes.
- New units use existing rarities forever - a higher rarity would bench every veteran's squad in the sim.
  Give new units a job (a passive tied to new content) instead. Plan passives with anti-power-creep.
- Clone-heist loop reference: treadmill tiers raise speed (x7.5 per tier), worlds need ~x1000 speed each,
  portal summons up to a cap then pauses (unless auto-sell is set), units steal eggs -> pets -> cash,
  rebirth resets cash only.
- Meters never decay to push a sale; cancelling gives no follow-up nag.

## Monetization
- ProcessReceipt: idempotent by PurchaseId; grant inside pcall; return PurchaseGranted only after the
  save succeeds, else NotProcessedYet. Refuse purchases that would grant nothing (skip with nothing
  growing, x10 with nothing pending, double prompts for a once-only pack).
- Paid random items: `PolicyService` check (hide where restricted), show odds, pity.
- Products with dual cash/Robux prices where the reference does it.
- The creator owns all their own passes - test the free-player experience on an alt.
- Keep a product-id table with a "0 = not created" lint; reconcile board prices vs Config vs Creator Hub.
- Creator Hub forms reset after image uploads: fill, verify by screenshot, refill, then save. Create
  products only with explicit permission, in the user's browser, never entering credentials. A real test
  purchase must be clicked by the human.

## Launch gates
- Gate table with **evidence per row** (remote audit, debug hooks gated, data round trip + rejoin,
  purchases, server settings, Play tests). PASS only with evidence; user-only items separate (fresh join,
  two-server session, real purchase, real phone FPS).
- Keep an explicit "never verified" list until each item is done.
- Before publish: move test stages out of workspace, delete quarantined Toolbox scripts, keep rollback
  points until after launch. Then the user: commit drafts, Ctrl+S, Publish, migrate servers, check
  version history.

## LiveOps
- Data: bump DataVersion only when shape changes; migrations additive + idempotent; never rename/reuse a
  key; never wipe progress after launch; never lower DataVersion (roll forward with a flag); fixture-test
  v(N-1) profiles running each migration twice; back up and dry-run on a read-only copy of a real save.
- Remote config with a fallback to Config.lua and per-feature kill switches.
- Weekly ritual: Thursday content freeze; Friday publish with content locked behind a server-time
  `opensAt`; Saturday it opens with no restart at peak; 1-2 codes per update.
- Per-update checklist: config lint, sims, data fixtures, Studio play with faked time, mobile perf,
  monetization, note the previous place version. Analytics via AnalyticsService custom, funnel and
  economy events.
- Retention: weekly cadence ready at launch; playtime rewards, welcome-back offline earnings, event pass,
  leaderboards as pass 2.

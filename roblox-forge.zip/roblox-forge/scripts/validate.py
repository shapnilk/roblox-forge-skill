# roblox-forge: Roblox spec gate for flipbooks/textures/meshes/templates. Evidence: bake-off T6, 191 files checked, 6 real failures (halo score may false-alarm at 512 px on white-into-ink edges). Needs template.py beside it.
"""Roblox spec checks for forge outputs. stdlib + PIL + numpy only.

    python lib/validate.py PATH...                 auto-classify files (dirs are walked)
    python lib/validate.py --kind tex|vfx|template|meshes PATH...
    python lib/validate.py                         self-check demo

Kinds and what each must pass:
  meshes    *_meshes.json from forgelib.export_json. Every mesh <= 20k tris and <= 60k verts (Studio
            EditableMesh preview cap). Every mesh except the head shell is an accessory: <= 4k tris.
            All Hair* meshes together form one hair accessory: <= 4k tris, inside the classic hair box.
  tex       mesh texture (named by a sibling *_meshes.json, or a <name>_* variant of one): square power
            of two, <= 2048 (marketplace), transparent texels carry bled RGB.
  vfx       flipbook (NxN in the file name): square power of two, <= 1024, grid divides the size,
            >= 4 px empty padding in every cell, no empty frame, transparent texels carry bled RGB.
  template  585x559 classic Shirt/Pants: gutters outside lib/template.py regions transparent, except
            the 4 px edge bleed that fabric.Fabric writes on purpose (never sampled, avoids seams).
Anything else (renders, sheets, masks, *_preview composites, downloaded study textures) is skipped.
"""
import json
import os
import re
import sys
from functools import lru_cache

import numpy as np
from PIL import Image

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from template import W as TW, H as TH, regions  # noqa: E402

PREVIEW_TRIS, PREVIEW_VERTS = 20_000, 60_000   # Studio EditableMesh caps (forge README)
ACCESSORY_TRIS = 4_000                          # create.roblox.com/docs/art/accessories/specifications
# Classic hair: 3 wide, 5 tall (2 up, 3 down), 3.5 deep (1.5 front, 2 behind) from HairAttachment.
# Mesh JSON is root-relative, Roblox axes, front = -Z. R6 head centre (0, 1.5, 0) (forgelib.HEAD_C)
# plus the R6 HairAttachment offset (0, 0.6, 0).
HAIR_ATTACH = (0.0, 2.1, 0.0)
HAIR_BOX = ((-1.5, 1.5), (-3.0, 2.0), (-1.5, 2.0))
VFX_MAX, MARKET_MAX = 1024, 2048
PAD_MIN = 4             # px of empty border per cell (RESEARCH_TOOLS packer spec; 8 is the authoring target)
CONTENT = 3 / 255       # alpha above this counts as drawn (ignores numeric dust)
EMPTY = 0.001           # a frame whose mean alpha is below this is empty
HALO, HALO_FRAC = 0.2, 0.01   # ring texel halo score above HALO on more than 1% of the ring = black halo
TEMPLATE_BLEED = 4      # fabric.Fabric(bleed=4)
GRID = re.compile(r"(?<!\d)(\d+)x\1(?!\d)")   # "_4x4" in a file name = flipbook grid


def load(path):
    """RGBA float32 0..1, plus whether the alpha channel is used at all."""
    im = Image.open(path)
    a = np.asarray(im.convert("RGBA"), np.float32) / 255
    return a, bool((a[..., 3] < 1).any())


def pow2_square(w, h, limit):
    out = []
    if w != h or w & (w - 1):
        out.append(f"size {w}x{h} is not a square power of two")
    if max(w, h) > limit:
        out.append(f"size {w}x{h} is over {limit}")
    return out


def halo(a):
    """Transparent texels next to drawn ones must carry the edge colour (Roblox filters straight alpha,
    so their RGB leaks into the edge). Score per ring texel = |RGB - alpha-weighted mean of its 8
    neighbours| x strongest neighbour alpha, so black next to a dark ink rim scores ~0 (no visible halo)."""
    A = a[..., 3]
    h, w = A.shape
    p = np.pad(a, ((1, 1), (1, 1), (0, 0)))
    sw = np.zeros((h, w), np.float32)
    s = np.zeros((h, w, 3), np.float32)
    wmax = np.zeros((h, w), np.float32)
    for dy in (-1, 0, 1):
        for dx in (-1, 0, 1):
            if dy or dx:
                n = p[1 + dy:1 + dy + h, 1 + dx:1 + dx + w]
                sw += n[..., 3]
                s += n[..., :3] * n[..., 3:]
                np.maximum(wmax, n[..., 3], out=wmax)
    ring = (A == 0) & (sw > 0)
    if not ring.any():
        return []
    score = np.abs(a[..., :3][ring] - s[ring] / sw[ring][:, None]).max(-1) * wmax[ring]
    bad = float((score > HALO).mean())
    if bad > HALO_FRAC:
        return [f"black halo: {bad:.1%} of {ring.sum()} edge texels carry unbled RGB (score > {HALO})"]
    return []


def check_texture(path, limit=MARKET_MAX):
    a, has_alpha = load(path)
    out = pow2_square(a.shape[1], a.shape[0], limit)
    return out + (halo(a) if has_alpha else [])


def check_flipbook(path, grid):
    a, has_alpha = load(path)
    h, w = a.shape[:2]
    out = pow2_square(w, h, VFX_MAX)
    if w % grid or h % grid:
        return out + [f"grid {grid}x{grid} does not divide {w}x{h}"]
    cov = a[..., 3] if has_alpha else a[..., :3].max(-1)   # no alpha: black-background additive sheet
    cw, ch = w // grid, h // grid
    empty, tight = [], []
    for k in range(grid * grid):
        r, c = divmod(k, grid)
        cell = cov[r * ch:(r + 1) * ch, c * cw:(c + 1) * cw]
        if cell.mean() < EMPTY:
            empty.append(k)
        ys, xs = np.nonzero(cell > CONTENT)
        if len(ys):
            pad = min(ys.min(), xs.min(), ch - 1 - ys.max(), cw - 1 - xs.max())
            if pad < PAD_MIN:
                tight.append(f"{k}:{pad}px")
    if empty:
        out.append(f"empty frames {empty} (of {grid * grid})")
    if tight:
        out.append(f"cell padding under {PAD_MIN} px in frames {', '.join(tight)}")
    return out + (halo(a) if has_alpha else [])


def check_template(path):
    a, _ = load(path)
    if a.shape[:2] != (TH, TW):
        return [f"size {a.shape[1]}x{a.shape[0]}, template must be {TW}x{TH}"]
    allowed = np.zeros((TH, TW), bool)
    b = TEMPLATE_BLEED
    for (x, y, w, h) in regions("shirt").values():          # pants use the same boxes
        allowed[max(0, y - b):y + h + b, max(0, x - b):x + w + b] = True
    ys, xs = np.nonzero((a[..., 3] > CONTENT) & ~allowed)
    if len(ys):
        return [f"{len(ys)} opaque gutter texels more than {b} px from a panel, "
                f"bbox x{xs.min()}-{xs.max()} y{ys.min()}-{ys.max()}"]
    return []


def check_meshes(path):
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if data.get("schema") != "forge-mesh-1":
        return [f"schema {data.get('schema')!r}, expected 'forge-mesh-1'"]
    out, hair_tris, hair_v = [], 0, []
    for m in data["meshes"]:
        name, nt, nv = m["name"], len(m["triangles"]), len(m["vertices"])
        if nt > PREVIEW_TRIS or nv > PREVIEW_VERTS:
            out.append(f"{name}: {nt} tris / {nv} verts over the {PREVIEW_TRIS}/{PREVIEW_VERTS} preview cap")
        if not name.lower().startswith("head") and nt > ACCESSORY_TRIS:
            out.append(f"{name}: {nt} tris over the {ACCESSORY_TRIS} accessory budget")
        if name.lower().startswith("hair"):
            hair_tris += nt
            hair_v.append(np.asarray(m["vertices"], np.float32).reshape(-1, 3))
    if hair_v:
        names = [m["name"] for m in data["meshes"] if m["name"].lower().startswith("hair")]
        if len(names) > 1 and hair_tris > ACCESSORY_TRIS:
            out.append(f"hair accessory {'+'.join(names)}: {hair_tris} tris over {ACCESSORY_TRIS}")
        v = np.concatenate(hair_v) - np.asarray(HAIR_ATTACH, np.float32)
        lo, hi = v.min(0), v.max(0)
        for ax, (mn, mx), l, u in zip("XYZ", HAIR_BOX, lo, hi):
            if l < mn - 1e-4 or u > mx + 1e-4:
                out.append(f"hair bounds {ax} {l:+.3f}..{u:+.3f} outside {mn:+.1f}..{mx:+.1f} studs from HairAttachment")
    return out


@lru_cache(None)
def mesh_textures(folder):
    """Texture names referenced by *_meshes.json in this folder ('texture' fields and *.png meta)."""
    names = set()
    for fn in os.listdir(folder):
        if fn.endswith("_meshes.json"):
            try:
                with open(os.path.join(folder, fn), encoding="utf-8") as f:
                    d = json.load(f)
            except (OSError, ValueError):
                continue
            names |= {m.get("texture") for m in d.get("meshes", [])}
            names |= {v for v in d.values() if isinstance(v, str) and v.endswith(".png")}
    return frozenset(os.path.splitext(n)[0] for n in names if n)


def classify(path):
    """(kind, arg) for a file a rule covers, else (None, reason)."""
    fn = os.path.basename(path)
    stem, ext = os.path.splitext(fn)
    if fn.endswith("_meshes.json"):
        return "meshes", None
    if ext.lower() not in (".png", ".tga", ".jpg", ".jpeg", ".bmp"):
        return None, "not an image or mesh json"
    if "preview" in stem or stem.startswith("_"):
        return None, "preview/compare composite, never uploaded"
    if any(d == "work" or d.startswith("_") for d in os.path.normpath(path).split(os.sep)[:-1]):
        return None, "scratch folder (work/ or _*/)"
    g = GRID.search(stem)
    if g:
        return "vfx", int(g.group(1))
    refs = mesh_textures(os.path.dirname(os.path.abspath(path)))
    if stem in refs or any(stem.startswith(r + "_") for r in refs):
        return "tex", None
    with Image.open(path) as im:
        if im.size == (TW, TH):
            return "template", None
    return None, "no rule (render, sheet, mask or study file)"


def run(path, kind=None):
    if kind is None:
        kind, arg = classify(path)
        if kind is None:
            return None, arg
    else:
        arg = None
    if kind == "vfx":
        if arg is None:
            m = GRID.search(os.path.basename(path))
            arg = int(m.group(1)) if m else 1
        return kind, check_flipbook(path, arg)
    return kind, {"tex": check_texture, "template": check_template, "meshes": check_meshes}[kind](path)


def walk(paths):
    for p in paths:
        if os.path.isdir(p):
            for root, _, files in os.walk(p):
                for fn in sorted(files):
                    yield os.path.join(root, fn)
        else:
            yield p


def main(argv):
    kind, verbose = None, "-v" in argv
    argv = [x for x in argv if x != "-v"]
    if argv[:1] == ["--kind"]:
        kind, argv = argv[1], argv[2:]
    fails = checked = skipped = 0
    for p in walk(argv):
        k, res = run(p, kind)
        if k is None:
            skipped += 1
            if verbose:
                print(f"SKIP {p}: {res}")
            continue
        checked += 1
        fails += bool(res)
        print(f"{'FAIL' if res else 'ok  '} {k:8} {p}" + "".join(f"\n       - {r}" for r in res))
    print(f"{checked} checked, {fails} failed, {skipped} skipped")
    return 1 if fails else 0


def selfcheck():
    import tempfile
    tmp = tempfile.mkdtemp()
    j = lambda n: os.path.join(tmp, n)

    def sheet(n=256, grid=2, r=40, bled=True, color=(1, 1, 1), empty=(), edge=()):
        c = n // grid
        yy, xx = np.mgrid[:c, :c]
        disc = ((yy - c / 2) ** 2 + (xx - c / 2) ** 2 < r * r).astype(np.float32)
        a = np.zeros((n, n, 4), np.float32)
        a[..., :3] = color
        for k in range(grid * grid):
            if k in empty:
                continue
            y, x = divmod(k, grid)
            cell = a[y * c:(y + 1) * c, x * c:(x + 1) * c]
            cell[..., 3] = disc
            if k in edge:
                cell[:3, :3, 3] = 1
        if not bled:
            a[a[..., 3] == 0, :3] = 0          # unbled export: transparent texels are black
        return a

    def save(a, name):
        Image.fromarray(np.uint8(np.clip(a, 0, 1) * 255 + 0.5), "RGBA").save(j(name))
        return j(name)

    assert run(save(sheet(), "good_2x2.png"))[1] == []
    assert any("halo" in r for r in run(save(sheet(bled=False), "black_2x2.png"))[1])
    assert run(save(sheet(bled=False, color=(0.03, 0.03, 0.03)), "ink_2x2.png"))[1] == []  # dark rim hides it
    assert any("empty frames [3]" in r for r in run(save(sheet(empty=(3,)), "gap_2x2.png"))[1])
    assert any("padding" in r for r in run(save(sheet(edge=(1,)), "edge_2x2.png"))[1])
    assert any("over 1024" in r for r in run(save(sheet(2048, 8), "big_8x8.png"))[1])
    assert any("square power" in r for r in run(save(sheet(300, 2, 30), "odd_2x2.png"))[1])

    t = np.zeros((TH, TW, 4), np.float32)
    for (x, y, w, h) in regions("shirt").values():
        t[max(0, y - 4):y + h + 4, max(0, x - 4):x + w + 4] = (0.2, 0.1, 0.3, 1)   # panels + 4 px bleed
    assert run(save(t, "shirt.png"))[1] == []
    t[0:20, 0:20, 3] = 1                                                           # paint in a gutter
    assert any("gutter" in r for r in run(save(t, "shirt.png"))[1])
    assert run(save(np.zeros((560, 585, 4)), "pants.png"), "template")[1][0].startswith("size")

    def meshes(name, parts):
        d = {"schema": "forge-mesh-1", "meshes": [
            {"name": n, "vertices": v, "triangles": [[0, 1, 2]] * nt, "texture": tex} for n, nt, v, tex in parts]}
        with open(j(name), "w") as f:
            json.dump(d, f)
        return j(name)

    tri = [[0, 1.5, 0], [0.5, 2.5, 0], [-0.5, 1.2, 0.4]]
    ok = meshes("ok_meshes.json", [("HeadShell", 5000, tri, "face.png"), ("Hair", 3980, tri, "hair_tex.png")])
    assert run(ok)[1] == []
    res = run(meshes("bad_meshes.json", [("HairFront", 2500, tri, None), ("HairBack", 2500, tri, None),
                                         ("Collar", 4001, tri, None), ("Cape", 20001, tri, None),
                                         ("Hair_Spike", 1, [[0, 4.2, 0], [1.6, 2, 0], [0, 2, -1.6]], None)]))[1]
    assert sum("accessory budget" in r for r in res) == 2, res          # Collar, Cape
    assert any("preview cap" in r for r in res) and any("HairFront+HairBack" in r for r in res)
    assert sum("hair bounds" in r for r in res) == 3, res               # X, Y and Z all out
    mesh_textures.cache_clear()
    assert classify(save(np.ones((64, 64, 4)), "hair_tex_512.png"))[0] == "tex"     # variant of a referenced texture
    assert classify(save(np.ones((960, 720, 4)), "render_front.png"))[0] is None
    assert classify(j("shirt_preview.png"))[0] is None
    os.makedirs(j("_work"))
    assert classify(save(np.ones((700, 700, 4)), os.path.join("_work", "v_hero_2x2_1024.png")))[0] is None
    print("self-check ok")


if __name__ == "__main__":
    if len(sys.argv) > 1:
        sys.exit(main(sys.argv[1:]))
    selfcheck()

# roblox-forge: Tint a white/grey sheet like Roblox (rgb x Color over grey) to inspect every frame before upload. Evidence: caught 2 of 3 Haki texture defects.
"""Tint a white/greyscale texture like Roblox (normal blend: rgb * Color) over grey -> *_preview.png.
python preview.py texture.png R G B [bg]"""
import sys
import numpy as np
from PIL import Image
p, r, g, b = sys.argv[1], *map(int, sys.argv[2:5])
bg = int(sys.argv[5]) if len(sys.argv) > 5 else 120
im = np.asarray(Image.open(p).convert("RGBA"), float) / 255
rgb = im[..., :3] * np.array([r, g, b]) / 255
a = im[..., 3:4]
out = rgb * a + (1 - a) * bg / 255
Image.fromarray((out * 255).astype(np.uint8)).save(p.replace(".png", "_preview.png"))

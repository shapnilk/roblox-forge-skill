# roblox-forge: Conqueror's Haki textures (bolts/pop/wisp/glow/strips). Evidence: user approved the aura ('I like the conquerors haki aura'); source C:/Users/shapn/Documents/AnimeCloneEggs/forge/research/tests/vfx_forge, run log in WORKFLOW.md.
"""Conqueror's Haki textures, our own art (numpy + PIL + scipy). Targets: ../HAKI_TARGETS.md

Every bolt = three copies of one jagged path (Plebarae's ink recipe, RESEARCH_VFX 4.1):
  core  black, ~50% of the rim width  (stays black when tinted; normal blend, LightEmission 0)
  rim   white                         (tinted crimson by ParticleEmitter/Beam.Color)
  glow  white, soft, low alpha        (becomes a thin red haze around the rim)
Paths: midpoint displacement (angular zig-zag, as anime lightning is drawn), thick-thin-thick width,
1-2 forks. Rendered at 2x, box-downsampled premultiplied, transparent texels bled white.

Outputs (textures/):
  haki_crackle_4x4.png   16 still variants (FlipbookStartRandom, framerate 0)
  haki_pop_4x4.png       one bolt's life (OneShot): spark, grow, fork, flicker, break up
  haki_wisp_4x4.png      dark smoke wisp life (OneShot), greyscale, tint near-black
  haki_glow.png          soft round glow, 256
  haki_strip_a/b.png     long single bolts for Beams (Stretch), 512x128
  *_512.png              half-size copies for upload (16 px pad at 1024 -> 8 px)
Run: python make_haki_textures.py   (seeded; ~10 s)
"""
import math
import os

import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import gaussian_filter, zoom

OUT = os.path.join(os.getcwd(), "textures")  # roblox-forge: run from your effect folder
SS = 2                      # supersample
SHEET, GRID, PAD = 1024, 4, 16
CELL = SHEET // GRID        # 256
ART = CELL - 2 * PAD        # 224
CORE_FRAC = 0.5
GLOW_ALPHA = 0.42


# ------------------------------------------------------------------ geometry
def displace(rng, a, b, depth, rough):
    """Midpoint displacement between points a, b -> list of points (angular zig-zag)."""
    pts = [np.array(a, float), np.array(b, float)]
    amp = rough * np.linalg.norm(pts[1] - pts[0])
    for _ in range(depth):
        new = [pts[0]]
        for p, q in zip(pts, pts[1:]):
            d = q - p
            n = np.array([-d[1], d[0]]) / (np.linalg.norm(d) + 1e-9)
            new += [(p + q) / 2 + n * rng.uniform(-amp, amp), q]
        pts, amp = new, amp * 0.55
    return pts


def widths(rng, n, w):
    """Thick-thin-thick profile with tapered ends."""
    t = np.linspace(0, 1, n)
    wob = 0.55 + 0.45 * np.abs(np.sin(t * math.pi * rng.uniform(1.5, 3.0) + rng.uniform(0, 3)))
    taper = np.clip(np.sin(t * math.pi) * 2.2, 0.15, 1)
    return w * wob * taper


def bolt(rng, a, b, w, depth=5, rough=0.22, forks=(1, 2), fang=(0.35, 0.9)):
    """Main path + forks -> list of (points, widths)."""
    main = displace(rng, a, b, depth, rough)
    out = [(main, widths(rng, len(main), w))]
    for _ in range(rng.integers(forks[0], forks[1] + 1)):
        i = rng.integers(len(main) // 4, 3 * len(main) // 4)
        d = np.array(b, float) - np.array(a, float)
        ang = math.atan2(d[1], d[0]) + rng.choice([-1, 1]) * rng.uniform(*fang)
        L = np.linalg.norm(d) * rng.uniform(0.25, 0.45)
        end = main[i] + L * np.array([math.cos(ang), math.sin(ang)])
        fp = displace(rng, main[i], end, depth - 2, rough)
        fw = widths(rng, len(fp), w * 0.6)
        fw[0] = out[0][1][i] * 0.6
        out.append((fp, fw))
    return out


def draw_paths(size, paths, scale=1.0, keep=None):
    """Rasterise paths (width * scale) into a float mask; keep(t) can drop pieces (break-up)."""
    im = Image.new("L", size, 0)
    dr = ImageDraw.Draw(im)
    for pts, ws in paths:
        n = len(pts)
        for k in range(n - 1):
            if keep is not None and not keep(k / (n - 1)):
                continue
            w = max(1.0, (ws[k] + ws[k + 1]) / 2 * scale)
            (x0, y0), (x1, y1) = pts[k], pts[k + 1]
            dr.line([(x0, y0), (x1, y1)], fill=255, width=int(round(w)))
            for (x, y), wk in ((pts[k], ws[k]), (pts[k + 1], ws[k + 1])):
                r = max(0.5, wk * scale / 2)
                dr.ellipse([x - r, y - r, x + r, y + r], fill=255)
    return np.asarray(im, float) / 255


def compose(paths, size, scale=1.0, keep=None, glow_only=False, glow_gain=1.0):
    """-> straight RGBA float (h, w, 4) at supersampled size."""
    rim = draw_paths(size, paths, scale, keep)
    core = draw_paths(size, paths, scale * CORE_FRAC, keep)
    wmax = max(ws.max() for _, ws in paths) * scale
    glow = gaussian_filter(np.maximum(rim, gaussian_filter(rim, wmax * 0.4) > 0.05), wmax * 0.9)
    glow = np.clip(glow / (glow.max() + 1e-9), 0, 1) * GLOW_ALPHA * glow_gain
    if glow_only:
        rim, core = rim * 0, core * 0
    a = np.maximum(rim, glow)
    lum = np.where(core > 0.5, 0.0, 1.0) * np.clip(1 - core, 0, 1)
    rgba = np.zeros(rim.shape + (4,))
    rgba[..., :3] = lum[..., None]
    rgba[..., 3] = a
    return rgba


# ------------------------------------------------------------------ output helpers
def down(rgba, f=SS):
    """Box downsample premultiplied, return straight RGBA."""
    pm = rgba.copy()
    pm[..., :3] *= pm[..., 3:4]
    h, w = pm.shape[0] // f, pm.shape[1] // f
    pm = pm[: h * f, : w * f].reshape(h, f, w, f, 4).mean(axis=(1, 3))
    a = pm[..., 3:4]
    rgb = np.where(a > 1e-4, pm[..., :3] / np.maximum(a, 1e-4), 1.0)  # bleed: transparent -> white
    return np.concatenate([np.clip(rgb, 0, 1), a], axis=-1)


def save(rgba, name, half=True):
    img = Image.fromarray((np.clip(rgba, 0, 1) * 255 + 0.5).astype(np.uint8), "RGBA")
    img.save(os.path.join(OUT, name + ".png"), optimize=True)
    if half:
        h = down(rgba, 2)
        Image.fromarray((h * 255 + 0.5).astype(np.uint8), "RGBA").save(
            os.path.join(OUT, name + "_512.png"), optimize=True)


def sheet(cells):
    """16 cells (ART*SS square straight RGBA) -> 1024 sheet straight RGBA."""
    out = np.zeros((SHEET, SHEET, 4))
    out[..., :3] = 1.0
    for i, c in enumerate(cells):
        c = down(c)
        c[..., 3] *= WIN                               # soft fade at the art-box edge (no cut glow)
        r, k = divmod(i, GRID)
        y, x = r * CELL + PAD, k * CELL + PAD
        out[y : y + ART, x : x + ART] = c
    return out


S = ART * SS  # supersampled art box (448)
_e = np.clip(np.minimum(np.arange(ART), np.arange(ART)[::-1]) / 14.0, 0, 1)
WIN = np.outer(_e, _e) ** 0.7


def crackle_cells(rng):
    cells = []
    for _ in range(16):
        m = S * 0.12
        y0, y1 = rng.uniform(S * 0.3, S * 0.7, 2)
        p = bolt(rng, (m, y0), (S - m, y1), w=rng.uniform(26, 36), depth=5, rough=0.2)
        cells.append(compose(p, (S, S)))
    return cells


def pop_cells(rng):
    """One bolt's life over 16 OneShot frames, on twos with glow-only 'blank' frames."""
    m = S * 0.1
    base = bolt(rng, (m, S * 0.55), (S - m, S * 0.42), w=40, depth=5, rough=0.22, forks=(2, 2))
    main, forks = base[0], base[1:]
    alt = bolt(np.random.default_rng(rng.integers(1 << 30)), (m, S * 0.5), (S - m, S * 0.47),
               w=40, depth=5, rough=0.22, forks=(2, 2))

    def grow(f):
        return lambda t: t <= f

    def broken(seed, frac):
        r = np.random.default_rng(seed)
        mask = r.random(64) < frac
        return lambda t: mask[int(t * 63)]

    spark = [(displace(rng, (S / 2 - 30, S / 2), (S / 2 + 30, S / 2), 2, 0.4), np.full(5, 34.0)),
             (displace(rng, (S / 2, S / 2 - 26), (S / 2, S / 2 + 26), 2, 0.4), np.full(5, 26.0))]
    F = [
        compose(spark, (S, S), 0.8),                         # 0 spark
        compose([main], (S, S), 0.7, keep=grow(0.45)),       # 1 grows
        compose(base[:2], (S, S), 0.9, keep=grow(1.0)),      # 2 full + fork
        compose(base, (S, S), 1.15),                         # 3 peak, both forks
        compose(base, (S, S), 1.0, glow_only=True, glow_gain=1.0),  # 4 glow-only flicker
        compose(alt, (S, S), 1.1),                           # 5 re-drawn (new jag)
        compose(alt, (S, S), 1.0),                           # 6 hold
        compose(alt, (S, S), 1.0, glow_only=True, glow_gain=0.85),   # 7 flicker
        compose(base, (S, S), 0.85),                         # 8 back, thinner
        compose(base, (S, S), 0.75, keep=broken(1, 0.75)),   # 9 breaking
        compose(base, (S, S), 0.65, keep=broken(2, 0.55)),   # 10
        compose(base, (S, S), 0.55, keep=broken(3, 0.42)),   # 11
        compose(base, (S, S), 0.45, keep=broken(4, 0.30)),   # 12
        compose(base, (S, S), 0.38, keep=broken(5, 0.20)),   # 13
        compose(base, (S, S), 0.32, keep=broken(6, 0.12)),   # 14
        compose(base, (S, S), 0.5, glow_only=True, glow_gain=0.5),  # 15 faint afterglow
    ]
    return F


def wisp_cells(rng):
    """Dark smoke wisp: vertically streaked noise inside a rising teardrop; grows 4 frames, then
    the threshold rises so it breaks into strands and shrinks (smoke breaks up, never fades)."""
    from scipy.ndimage import label
    yy, xx = np.mgrid[0:S, 0:S] / S
    big = gaussian_filter(rng.random((S * 2, S)), (30, 10))
    small = gaussian_filter(rng.random((S * 2, S)), (10, 4))
    big, small = [(n - n.mean()) / n.std() for n in (big, small)]
    cells = []
    for f in range(16):
        t = f / 15
        off = int((1 - t) * S * 0.7)                  # noise scrolls up
        n = big[off : off + S] * 0.75 + small[off : off + S] * 0.3
        cx = 0.5 + 0.05 * np.sin(yy * 6 + t * 3)
        grow = 0.35 + 0.65 * min(1, (f + 1) / 4)      # 4 frames of fast growth
        r = np.sqrt(((xx - cx) / (0.2 * grow * (0.6 + 0.6 * yy))) ** 2
                    + ((yy - 0.6 + 0.12 * t) / (0.36 * grow)) ** 2)
        env = 1 - r
        field = env + n * 0.32 * np.clip(env + 0.4, 0, 1) - 1.05 * max(0, t - 0.2)
        lab, k = label(field > 0)
        if k:
            sizes = np.bincount(lab.ravel())
            sizes[0] = 0
            keep = sizes >= max(60, sizes.max() * 0.04)   # drop confetti islands
            solid = keep[lab]
        else:
            solid = field > 0
        outer = gaussian_filter(solid.astype(float), 1.2)
        inner = gaussian_filter((solid & (field > 0.3)).astype(float), 1.2)
        rgba = np.zeros((S, S, 4))
        rgba[..., :3] = (0.6 + 0.4 * inner)[..., None]    # 2 tones: inner brighter
        rgba[..., 3] = np.clip(outer, 0, 1) * 0.92
        if rgba[..., 3].max() < 0.05:                 # never an empty frame
            rgba[..., 3] = np.clip(gaussian_filter(np.clip(env + 0.3, 0, 1), 6) * 0.08, 0, 1)
        cells.append(rgba)
    return cells


def glow_tex():
    n = 256
    yy, xx = (np.mgrid[0:n, 0:n] - (n - 1) / 2) / (n / 2)
    r = np.sqrt(xx ** 2 + yy ** 2)
    a = np.clip(1 - r, 0, 1) ** 2.2
    rgba = np.ones((n, n, 4))
    rgba[..., 3] = a
    return rgba


def strip(rng):
    W, H = 512 * SS, 128 * SS
    p = bolt(rng, (W * 0.03, H * 0.5), (W * 0.97, H * 0.5), w=30, depth=6, rough=0.09, forks=(2, 3),
             fang=(0.1, 0.22))
    out = down(compose(p, (W, H)))
    ey = np.clip(np.minimum(np.arange(128), np.arange(128)[::-1]) / 12.0, 0, 1)
    out[..., 3] *= ey[:, None]
    return out


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    rng = np.random.default_rng(7)
    save(sheet(crackle_cells(rng)), "haki_crackle_4x4")
    save(sheet(pop_cells(rng)), "haki_pop_4x4")
    save(sheet(wisp_cells(rng)), "haki_wisp_4x4")
    save(glow_tex(), "haki_glow", half=False)
    save(strip(rng), "haki_strip_a", half=False)
    save(strip(rng), "haki_strip_b", half=False)
    # self-check: every cell drawn, padding empty
    for name in ("haki_crackle_4x4", "haki_pop_4x4", "haki_wisp_4x4"):
        a = np.asarray(Image.open(os.path.join(OUT, name + ".png")))[..., 3]
        for i in range(16):
            r, k = divmod(i, GRID)
            c = a[r * CELL : (r + 1) * CELL, k * CELL : (k + 1) * CELL]
            assert c[PAD:-PAD, PAD:-PAD].max() > 8, (name, i, "empty frame")
            assert c[:PAD].max() == 0 and c[-PAD:].max() == 0, (name, i, "padding")
    print("ok")

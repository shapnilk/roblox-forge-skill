"""Silhouette match between two forge mesh JSONs (front / side / top orthographic masks).

python sil_iou.py <target_meshes.json> <candidate_meshes.json> [overlay.png]
Prints IoU per view and where the candidate is too big / too small; the overlay shows
target-only in blue, candidate-only in red, both in grey.
"""
import json, sys
import numpy as np
from PIL import Image, ImageDraw

RES = 320
BOUNDS = {"front": ((-1.4, 1.4), (0.8, 3.0)), "side": ((-1.4, 1.4), (0.8, 3.0)), "top": ((-1.4, 1.4), (-1.4, 1.4))}


def tris(path):
    out = []
    for m in json.load(open(path))["meshes"]:
        V = np.array(m["vertices"])
        out.append(V[np.array(m["triangles"])])
    return np.concatenate(out)


def mask(T, view):
    (u0, u1), (v0, v1) = BOUNDS[view]
    if view == "front":
        uv = np.stack([-T[..., 0], T[..., 1]], -1)       # seen from the front: character right on the left
    elif view == "side":
        uv = np.stack([-T[..., 2], T[..., 1]], -1)       # seen from the character's right: front on the right
    else:
        uv = np.stack([-T[..., 0], -T[..., 2]], -1)      # from above: front at the bottom
    px = np.empty_like(uv)
    px[..., 0] = (uv[..., 0] - u0) / (u1 - u0) * RES
    px[..., 1] = (v1 - uv[..., 1]) / (v1 - v0) * RES
    im = Image.new("L", (RES, RES), 0)
    d = ImageDraw.Draw(im)
    for t in px:
        d.polygon([tuple(p) for p in t], fill=255)
    return np.array(im) > 0


def compare(a_path, b_path, overlay=None):
    A, B = tris(a_path), tris(b_path)
    res, tiles = {}, []
    for view in ("front", "side", "top"):
        ma, mb = mask(A, view), mask(B, view)
        inter, uni = (ma & mb).sum(), (ma | mb).sum()
        res[view] = {"iou": round(inter / uni, 3), "extra": round((mb & ~ma).sum() / ma.sum(), 3),
                     "missing": round((ma & ~mb).sum() / ma.sum(), 3)}
        rgb = np.full((RES, RES, 3), 30, np.uint8)
        rgb[ma & mb] = (170, 170, 170); rgb[ma & ~mb] = (60, 110, 255); rgb[mb & ~ma] = (255, 70, 60)
        tiles.append(rgb)
    if overlay:
        Image.fromarray(np.concatenate(tiles, 1)).save(overlay)
    res["mean_iou"] = round(float(np.mean([res[v]["iou"] for v in ("front", "side", "top")])), 3)
    return res


if __name__ == "__main__":
    print(json.dumps(compare(sys.argv[1], sys.argv[2], sys.argv[3] if len(sys.argv) > 3 else None)))

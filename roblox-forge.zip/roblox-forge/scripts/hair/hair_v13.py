"""Hair v13, the UGC creator workflow: individual leaf-shaped locks, not a sculpted mass.

Measured on the benchmark (research/analyze_tbhair*.py): ~60-80 curved leaf locks layered from the crown,
smooth-shaded (vertex normals ~6 deg off the face normal) with hard edges only at the lock rims, ~12 sq studs,
<4k tris. Creators build each lock as a Bezier path swept with a flattened 3-vertex profile, tips scaled to 0,
then convert, join, shade smooth. This builds the same thing directly: a Catmull-Rom spine per lock swept with
a flat triangle profile (crest up, flat side toward the head), leaf width profile, tips on the measured
silhouette (the carved hull = v7's outline), tiers from the crown down, one UV tile per lock, soft bake.

blender -b --factory-startup --python hair_locks.py -- <hull.obj> <outdir>
"""
import json, math, os, sys
import bpy, bmesh
import numpy as np
from mathutils import Vector
from mathutils.bvhtree import BVHTree

here = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, here)
import forgelib as fl
import measured as ms

argv = sys.argv[sys.argv.index("--") + 1:]
hull_path, out = argv[0], os.path.abspath(argv[1])
os.makedirs(out, exist_ok=True)
SEG = int(os.environ.get("FORGE_SEG", "8"))           # spine segments per lock
CREASE = float(os.environ.get("FORGE_CREASE", "45"))      # benchmark crest dihedral ~48 deg -> crest stays hard
FLAT = float(os.environ.get("FORGE_FLAT", "0.28"))
_PN = int(os.environ.get("FORGE_PROFILE_N", "3"))         # 3 = flat triangle (tutorial); 4/5 = rounded top arc
PROFILE = [(math.cos(math.pi * (1 - k / (_PN - 1))), math.sin(math.pi * (1 - k / (_PN - 1)))) for k in range(_PN)]
if os.environ.get("FORGE_CHUNK"):
    # Benchmark lock cross-section (research/render_close.py, slices): a thick chunk, not a blade - side walls with
    # real depth, a broad gently folded top (smooth), flat underside on the head. Walls stay hard (crease), top soft.
    WALL = float(os.environ.get("FORGE_WALL", "0.55"))
    PROFILE = [(-1.0, 0.0), (-0.92, WALL), (0.0, 1.0), (0.92, WALL), (1.0, 0.0)]          # crest height / half-width (tan 24 deg)
ARCH = float(os.environ.get("FORGE_ARCH", "0.05"))
TAPER = float(os.environ.get("FORGE_TAPER", "1.6"))     # tip taper exponent: higher = stays wide longer, short point
BELLY = float(os.environ.get("FORGE_BELLY", "0"))       # 0 = per-lock default; else where the lock is widest (0..1)
TIPK = float(os.environ.get("FORGE_TIPK", "1.0"))
WING_PEEL = float(os.environ.get("FORGE_WING", "0.18"))
N_R1 = int(os.environ.get("FORGE_NR1", "14"))
R1W = float(os.environ.get("FORGE_R1W", "1.0"))
BACK_PEEL = float(os.environ.get("FORGE_BACKPEEL", "0.20"))
FIT = {}            # silhouette fit vs the benchmark (research/fit_locks.py)
DEL = {k: float(os.environ.get("FORGE_D" + k, FIT.get(k, 0))) for k in ("R1", "R2", "R3", "R4", "F", "S")}
HC = np.array([0.0, 1.5, 0.0])
rng = np.random.default_rng(int(os.environ.get("FORGE_SEED", "4")))

# ---------------------------------------------------------------- silhouette target (v7's outline)
fl.clear_scene()
shell = ms.obj_to_object(hull_path, "Shell")
r = shell.modifiers.new("R", "REMESH"); r.mode = "VOXEL"; r.voxel_size = 0.012
bpy.context.view_layer.objects.active = shell; bpy.ops.object.modifier_apply(modifier=r.name)
s = shell.modifiers.new("S", "SMOOTH"); s.factor = 0.6; s.iterations = 8
bpy.ops.object.modifier_apply(modifier=s.name)
bvh = BVHTree.FromObject(shell, bpy.context.evaluated_depsgraph_get())


def ray(az, el):
    a, e = math.radians(az), math.radians(el)
    return np.array([math.sin(a) * math.cos(e), math.sin(e), -math.cos(a) * math.cos(e)])


def surf(az, el):
    d = ray(az, el)
    loc = bvh.ray_cast(fl.rb2bl(HC + d * 3.0), fl.rb2bl(-d))[0]
    return None if loc is None else float(np.dot(np.array(fl.bl2rb(loc)) - HC, d))


def env(az, el):
    """Body radius of the silhouette near (az, el): low percentile of a ray patch (ignores thin spikes)."""
    hs = sorted(h for h in (surf(az + i * 5, el + j * 3) for i in (-1, 0, 1) for j in (-1, 0, 1)) if h)
    return hs[min(2, len(hs) - 1)] if len(hs) >= 3 else None


def reach(az, el):
    """Farthest silhouette point near (az, el): where the measured spikes end."""
    hs = [surf(az + i, el + j) for i in range(-8, 9, 4) for j in range(-6, 7, 3)]
    return max([h for h in hs if h] or [0.0])


def head_r(d, r=0.6, hh=0.6, v=5.0):
    lo, hi = 0.3, 1.0
    for _ in range(25):
        m = (lo + hi) / 2
        q = d * m
        lo, hi = (m, hi) if (math.hypot(q[0], q[2]) / r) ** v + (abs(q[1]) / hh) ** v <= 1 else (lo, m)
    return lo


# ---------------------------------------------------------------- one lock = swept flat triangle
def catmull(pts, n):
    P = [pts[0] * 2 - pts[1]] + list(pts) + [pts[-1] * 2 - pts[-2]]
    out = []
    for i in range(n + 1):
        u = i / n * (len(pts) - 1)
        k = min(int(u), len(pts) - 2); t = u - k
        p0, p1, p2, p3 = P[k], P[k + 1], P[k + 2], P[k + 3]
        out.append(0.5 * ((2 * p1) + (-p0 + p2) * t + (2 * p0 - 5 * p1 + 4 * p2 - p3) * t * t
                          + (-p0 + 3 * p1 - 3 * p2 + p3) * t ** 3))
    return np.array(out)


G, PAD = 10, 0.06
_tiles = iter(range(G * G))


def tile_uv(tile, u, v):
    tx, ty = tile % G, tile // G
    return ((tx + PAD + u * (1 - 2 * PAD)) / G, 1 - (ty + PAD + v * (1 - 2 * PAD)) / G)


def lock(name, pts, width, flat=None, root=0.55, belly=0.32, twist=0.0):
    """Leaf lock: width rises from root*width to full at `belly`, then tapers to a point.
    Cross-section: side, crest, side + flat underside (3 vertices). `twist` rolls the blade (radians)."""
    flat = FLAT if flat is None else flat
    belly = BELLY if BELLY else belly
    sp = catmull([np.array(p, float) for p in pts], SEG)
    n = len(sp)
    verts, faces, uvs, tl = [], [], [], []
    tile = next(_tiles)
    for i, p in enumerate(sp):
        s = i / (n - 1)
        t = sp[min(i + 1, n - 1)] - sp[max(i - 1, 0)]; t /= np.linalg.norm(t)
        out = p - HC; out = out - t * (out @ t); out /= np.linalg.norm(out) + 1e-9   # flat side faces the head
        side = np.cross(t, out)
        a = twist * s
        side, out = side * math.cos(a) + out * math.sin(a), out * math.cos(a) - side * math.sin(a)
        rise = min(1.0, s / belly)
        w = width * (root + (1 - root) * math.sin(rise * math.pi / 2)) * (1 - max(0.0, (s - belly) / (1 - belly)) ** TAPER)
        if i == n - 1:
            verts.append(tuple(p)); tl.append(1.0)
            continue
        h = w * flat
        for cs, co in PROFILE:
            verts.append(tuple(p + side * (w * cs) + out * (h * co))); tl.append(s)
    U = lambda u, v: tile_uv(tile, u, v)
    m = len(PROFILE)
    us = [k / (m - 1) for k in range(m)]
    edges = [(k, k + 1, us[k], us[k + 1]) for k in range(m - 1)] + [(m - 1, 0, 1.0, 0.0)]   # top arc + underside
    for i in range(n - 2):
        a, b = m * i, m * (i + 1)
        v0, v1 = i / (n - 1), (i + 1) / (n - 1)
        for (x, y, u0, u1) in edges:
            faces.append((a + x, a + y, b + y, b + x)); uvs += [U(u0, v0), U(u1, v0), U(u1, v1), U(u0, v1)]
    tip, last = len(verts) - 1, m * (n - 2)
    vl = (n - 2) / (n - 1)
    for (x, y, u0, u1) in edges:
        faces.append((last + x, last + y, tip)); uvs += [U(u0, vl), U(u1, vl), U((u0 + u1) / 2, 1.0)]
    faces.append(tuple(reversed(range(m)))); uvs += [U(1 - k / (m - 1), 0) for k in range(m)]   # root cap (hidden)
    ob = fl.new_object(name, verts, faces, uvs)
    a = ob.data.attributes.new("tlen", "FLOAT", "POINT")
    for i, v in enumerate(tl):
        a.data[i].value = v
    return ob


def azel(d):
    return math.degrees(math.atan2(d[0], -d[2])), math.degrees(math.asin(max(-1.0, min(1.0, d[1] / np.linalg.norm(d)))))


def slerp(a, b, t):
    a, b = a / np.linalg.norm(a), b / np.linalg.norm(b)
    om = math.acos(max(-1.0, min(1.0, float(a @ b))))
    return a if om < 1e-4 else (math.sin((1 - t) * om) * a + math.sin(t * om) * b) / math.sin(om)


def path(d_root, d_tip, tip_k=1.0, arch=0.06, droop=0.0, lift=0.03, peel=0.0, swirl=0.0, n=5):
    """Root on the skull, body on the silhouette body radius, tip on the measured spike reach. The lock runs
    along the great circle root -> tip (so crown locks cross over the top), curling sideways by `swirl`."""
    pts = []
    for k in range(n):
        t = k / (n - 1)
        az, el = azel(slerp(d_root, d_tip, t))
        az += swirl * t ** 1.5
        d = ray(az, el)
        rs = head_r(d) + lift
        rb = env(az, el) or rs + 0.12
        if k == n - 1:
            rb = max(rb, reach(az, el) * tip_k)
        rr = rs + (max(rb, rs) - rs) * t ** 0.6 + arch * math.sin(math.pi * t)
        rr += peel * max(0.0, (t - 0.55) / 0.45) ** 2          # the tip peels off the surface
        pts.append(HC + d * rr)
    pts[-1] = pts[-1] - np.array([0, droop, 0])
    return pts


# ---------------------------------------------------------------- tiers (crown down), our layout
def wrap(a):
    return (a + 180) % 360 - 180


locks = []
SWIRL = float(os.environ.get("FORGE_SWIRL", "18"))
SWEEP_K = float(os.environ.get("FORGE_SWEEP", "0"))     # >0: per-azimuth curve measured on the benchmark (research/flow_map.py)
_SW = json.load(open(os.path.join(here, "..", "research", "tb_sweep.json")))["field"] if SWEEP_K else None


def sweep_of(az, default):
    if not _SW:
        return default
    xs = [c for c, _ in _SW]; ys = [v for _, v in _SW]
    a = (az + 180) % 360 - 180
    # flow_map "east" = up x d points toward -azimuth, so the measured angle is negated for path()'s swirl (+az)
    return -SWEEP_K * float(np.interp(a, xs + [xs[0] + 360], ys + [ys[0]], period=360))
N_C, N_M, N_L = (int(x) for x in os.environ.get("FORGE_TIERS", "18,22,20").split(","))
PEEL = float(os.environ.get("FORGE_PEEL", "0.16"))
K = float(os.environ.get("FORGE_WIDTH", "0.95"))          # half-widths below, studs
W_C, W_M, W_L, W_F, W_S = (0.15 * K, 0.19 * K), (0.13 * K, 0.17 * K), (0.12 * K, 0.15 * K), (0.12 * K, 0.15 * K), 0.11 * K
WHORL_D = ray(175, 74)                                    # crown whorl, back of the top (like the benchmark)
LAYOUT = os.environ.get("FORGE_LAYOUT", "rows")
if LAYOUT == "surface":
    # Strands laid ON the measured shape (v7's outline = mushroom cap + hanging layer):
    #  cap layer  - from the crown pivot straight across the top surface (sampled looking down) to the brim edge;
    #  hang layer - from under the brim down the side surface (sampled horizontally) to the bottom hairline.
    # Creator construction per strand (flat 3-vertex profile, leaf taper, pointed tip, smooth shading).
    def top_y(x, z):
        loc = bvh.ray_cast(Vector((-x, z, 6.0)), Vector((0, 0, -1)))[0]
        return None if loc is None else loc.z

    def side_r(az, y):
        a = math.radians(az)
        o = (math.sin(a) * 3.0, y, -math.cos(a) * 3.0)
        loc = bvh.ray_cast(fl.rb2bl(o), fl.rb2bl((-math.sin(a), 0.0, math.cos(a))))[0]
        if loc is None:
            return None
        q = fl.bl2rb(loc)
        return math.hypot(q[0], q[2])

    def resample(pts, n):
        pts = np.array(pts); seg = np.linalg.norm(np.diff(pts, axis=0), axis=1)
        cum = np.concatenate([[0], np.cumsum(seg)]); out = []
        for t in np.linspace(0, cum[-1], n):
            i = min(np.searchsorted(cum, t, side="right") - 1, len(seg) - 1)
            f = (t - cum[i]) / max(seg[i], 1e-9)
            out.append(pts[i] * (1 - f) + pts[i + 1] * f)
        return out

    PX, PZ = 0.0, float(os.environ.get("FORGE_PIVOT_Z", "0.18"))     # crown pivot (back of the top)
    N_CAP = int(os.environ.get("FORGE_NCAP", "18"))
    N_HANG = int(os.environ.get("FORGE_NHANG", "22"))
    OVER = float(os.environ.get("FORGE_OVERLAP", "1.3"))
    CAP_LIFT = float(os.environ.get("FORGE_CAP_LIFT", "0.03"))
    brim = {}
    for k in range(N_CAP):
        az = (k + 0.5) * 360 / N_CAP
        a = math.radians(az); dx, dz = math.sin(a), -math.cos(a)
        line, prev = [], None
        for i in range(60):
            t = 0.04 * i
            x, z = PX + dx * t, PZ + dz * t
            y = top_y(x, z)
            if y is None or (prev is not None and prev - y > 0.10):
                break                                     # past the brim edge
            line.append((x, y + CAP_LIFT, z)); prev = y
        if len(line) < 4:
            continue
        e = np.array(line[-1]); out_h = np.array([dx, 0, dz])
        tip = e + out_h * 0.06 + np.array([0, -0.05, 0])  # the tip leaves the cap edge, slightly down
        pts = resample(line + [tuple(tip)], 6)
        brim[az] = e
        r_e = math.hypot(e[0], e[2])
        w = 0.5 * 2 * math.pi * r_e / N_CAP * OVER
        locks.append(("C", pts, w, dict(root=0.15, belly=0.55)))
    for k in range(N_HANG):
        az = (k + 0.25) * 360 / N_HANG
        near = min(brim, key=lambda b: abs(wrap(b - az))) if brim else None
        y0 = (brim[near][1] - 0.10) if near is not None else 2.0
        line = []
        y = y0
        while y > 0.6:
            r = side_r(az, y)
            if r is None:
                break
            line.append((r, y)); y -= 0.03
        if len(line) < 4:
            continue
        a = math.radians(az)
        d_h = np.array([math.sin(a), 0, -math.cos(a)])
        pts3 = [np.array([0, yy, 0]) + d_h * (rr - 0.01) for rr, yy in line]
        root = np.array([0, y0 + 0.05, 0]) + d_h * (head_r(ray(az, 45)) * 0.9)   # tucked under the cap
        last = pts3[-1]
        tip = last + d_h * 0.03 + np.array([0, -0.05, 0])
        pts = resample([root] + pts3 + [tip], 6)
        w = 0.5 * 2 * math.pi * float(np.mean([rr for rr, _ in line])) / N_HANG * OVER
        locks.append(("H", pts, w, dict(root=0.35, belly=0.4)))
    print("surface layout: cap", sum(1 for l in locks if l[0] == "C"), "hang", sum(1 for l in locks if l[0] == "H"))
elif LAYOUT == "points":
    # Control-point design (chars/points_design.py): the lock passes exactly through its drawn points.
    PD = json.load(open(os.environ.get("FORGE_DESIGN", os.path.join(here, "..", "chars", "gojo_hair_points.json"))))
    for L in PD["locks"]:
        pts = []
        for az, el, off in L["pts"]:
            d = ray(az, el)
            pts.append(HC + d * (head_r(d) + off))
        locks.append((L["clump"], pts, L["w"]))
elif LAYOUT == "design":
    # Designed layout (chars/<x>_hair_design.json): every lock placed on purpose, grouped in named clumps.
    DES = json.load(open(os.environ.get("FORGE_DESIGN", os.path.join(here, "..", "chars", "gojo_hair_design.json"))))
    for L in DES["locks"]:
        for sgn in ((1, -1) if L.get("mirror") else (1,)):
            taz, tel = L["tip"]
            taz *= sgn
            root = WHORL_D if L["root"] == "whorl" else ray(L["root"][0] * sgn, L["root"][1])
            if L["root"] == "whorl":
                root = slerp(WHORL_D, ray(taz, 74), 0.08)
            bend = L["bend"] * sgn if "bend" in L else sweep_of(taz, 0.0) or 0.0
            pts = path(root, ray(taz, tel), tip_k=L.get("tip_k", TIPK), arch=L.get("arch", ARCH), droop=0.02,
                       lift=L.get("lift", 0.06), peel=L.get("peel", 0.1), swirl=bend)
            locks.append((L["clump"], pts, L["w"] * K / 0.85))
elif LAYOUT == "fan":
    # The creator workflow (Roblox UGC hair tutorial V8_Z7JEpjSc): ONE strand shaped like the skull in front view,
    # its start on the crown pivot; duplicate and ROTATE about that pivot to cover half the head; MIRROR; a second
    # layer of thinner strands slightly raised; a few outer strands pulled out; one taller top strand; bangs in
    # front; roots merged at the crown. Wide base strands fanned evenly = the clean, thick look.
    PIVOT = ray(180, float(os.environ.get("FORGE_PIVOT_EL", "80")))
    TIP_EL = [(0, 36), (45, 24), (80, 0), (120, -18), (180, -36)]       # where base strands end, by |azimuth|

    def tip_el(az):
        a = abs(wrap(az))
        for (a0, e0), (a1, e1) in zip(TIP_EL, TIP_EL[1:]):
            if a <= a1:
                return e0 + (e1 - e0) * (a - a0) / (a1 - a0)
        return TIP_EL[-1][1]

    def sector_halfwidth(az, n, el_belly=20.0):
        d = ray(az, el_belly)
        r = (env(az, el_belly) or 0.8) * math.cos(math.radians(el_belly))   # distance from the vertical axis
        return 0.5 * 2 * math.pi * r / n * OVERLAP

    N_BASE = int(os.environ.get("FORGE_NBASE", "18"))
    N_TOP = int(os.environ.get("FORGE_NTOP", "14"))
    OVERLAP = float(os.environ.get("FORGE_OVERLAP", "1.25"))
    half = []                                            # build the right half (az > 0), mirror the rest
    CURL = float(os.environ.get("FORGE_CURL", "14"))     # sideways curl near the tip (deg), outward from the part
    for k in range(N_BASE // 2):
        az = (k + 0.5) * 180 / (N_BASE // 2)
        long_ = k % 2 == 0                               # rhythm: long hugging strands alternate with short flared ones
        el = tip_el(az) - (4 if long_ else -8)
        pl = PEEL * (0.6 if long_ else 1.6) * (0.5 if abs(az) < 40 else 1.0)
        half.append(("B", az, el, sector_halfwidth(az, N_BASE), dict(root=0.18, belly=0.45),
                     dict(lift=0.04, arch=ARCH, peel=pl, tip_k=TIPK, swirl=CURL * (1.0 if long_ else 0.6))))
    for k in range(N_TOP // 2):                          # second layer: thinner, raised, shorter, between base strands
        az = k * 180 / (N_TOP // 2) + 180 / N_TOP
        half.append(("T", az, tip_el(az) + 14, sector_halfwidth(az, N_BASE) * 0.75, dict(root=0.2, belly=0.4),
                     dict(lift=0.09, arch=ARCH * 1.2, peel=PEEL * 1.4, tip_k=TIPK * 1.02, swirl=CURL * 1.2)))
    for az, de in ((62, 20), (95, 10), (128, 4), (160, -6)):   # outer strands pulled out at staggered heights
        half.append(("A", az, tip_el(az) + de, sector_halfwidth(az, N_BASE) * 0.65, dict(root=0.2, belly=0.4),
                     dict(lift=0.11, arch=ARCH, peel=PEEL * 2.2, tip_k=TIPK * 1.05, swirl=CURL * 1.5)))
    for g, az, el, w, shape, kw in half:
        for sgn in (1, -1):
            a_ = az * sgn
            kw2 = dict(kw, swirl=kw["swirl"] * sgn)
            locks.append((g, path(PIVOT, ray(a_, el), **kw2), w, shape))
    # one taller, thin strand on top
    locks.append(("S", path(PIVOT, ray(200, 66), tip_k=1.1, arch=0.12, lift=0.1), 0.09, dict(root=0.25, belly=0.4)))
    # bangs: a fan from the front hairline down to the measured fringe tips (mirrored pairs by x)
    BANG_PIVOT = ray(0, 74)
    fr = json.load(open(os.path.join(os.path.dirname(hull_path), "gojo_fringe.json")))
    for x, y in fr:
        az = math.degrees(math.asin(max(-0.95, min(0.95, x / 0.75))))
        locks.append(("F", path(slerp(BANG_PIVOT, ray(az, 74), 0.5), ray(az, math.degrees(math.atan2(y, 0.62)) + DEL["F"]),
                                tip_k=1.0, arch=0.05, lift=0.07, swirl=0.0), rng.uniform(*W_F) * 1.5,
                      dict(root=0.3, belly=0.4)))
else:
    # Targets measured on the benchmark (research/lock_stats.py): ~75 leaf locks 0.4-1.3 long, layered like feathers
    # (each row covers the roots of the next), half the tips at eye/ear level standing ~0.36 off the skull pointing
    # down-and-out, ~20% higher pointing out, ~20% low hugging the nape.
    ROWS = [  # name, count, root el, tip el (sides/back), tip el (front), peel, lift, width range, swirl share
        ("R1", N_R1, 80, (32, 48), (40, 50), 0.05, 0.13, (W_C[0] * R1W, W_C[1] * R1W), 1.0),
        ("R2", 20, 64, (8, 24), (34, 44), 0.12, 0.10, W_C, 0.8),
        ("R3", 22, 46, (-16, 2), None, 0.18, 0.07, W_M, 0.6),
        ("R4", 16, 26, (-42, -22), None, 0.03, 0.04, W_L, 0.3),
    ]
    for name, n, el_r, tip_sb, tip_f, peel, lift, wr, sw in ROWS:
        off = rng.uniform(0, 360 / n)
        for j in range(n):
            az = off + j * 360 / n + rng.uniform(-5, 5)
            front = abs(wrap(az)) < 50
            if front and tip_f is None:
                continue                                      # the fringe covers the face side of the lower rows
            side = 50 <= abs(wrap(az)) < 110
            if name == "R4" and abs(wrap(az)) < 100:
                tip = rng.uniform(-16, -6)                    # sides end at the ear line
            else:
                tip = rng.uniform(*(tip_f if front else tip_sb))
            pl = peel
            tip += DEL.get(name, 0.0)
            root = slerp(WHORL_D, ray(az, 74), 0.08) if name == "R1" else ray(az - SWIRL * sw * 0.3, el_r)
            locks.append((name, path(root, ray(az, tip), tip_k=rng.uniform(0.98, 1.05) * TIPK, arch=ARCH, lift=lift,
                                     droop=0.02, peel=pl * (0.5 if front else 1.0), swirl=sweep_of(az, SWIRL * sw)), rng.uniform(*wr)))
    # accent spikes: a few higher tips pointing straight out at the temples and sides
    for az in (78, -78):
        locks.append(("A", path(slerp(WHORL_D, ray(az, 70), 0.3), ray(az + 8, rng.uniform(34, 42)), tip_k=1.03,
                                arch=0.06, lift=0.12, peel=0.12, swirl=SWIRL * 0.5), rng.uniform(*W_C)))
    # 4. fringe: one lock per measured fringe tip, from the front hairline down over the forehead
    fr = json.load(open(os.path.join(os.path.dirname(hull_path), "gojo_fringe.json")))
    for x, y in fr:
        az = math.degrees(math.asin(max(-0.95, min(0.95, x / 0.75))))
        tip_el = math.degrees(math.atan2(y, 0.62)) + DEL["F"]
        locks.append(("F", path(ray(az * 0.5, 70), ray(az, tip_el), tip_k=1.0, arch=0.05, lift=0.07), rng.uniform(*W_F)))
    # 5. crown spikes: a few short locks standing up out of the whorl
    for az, el_t in ((150, 64), (205, 62), (115, 60)):
        locks.append(("S", path(WHORL_D, ray(az, el_t), tip_k=1.1, arch=0.12, lift=0.12), W_S))

os.makedirs(out, exist_ok=True)
json.dump([{"id": f"{it[0]}{i}", "clump": it[0], "w": float(it[2]), "pts": [list(map(float, q)) for q in it[1]]}
           for i, it in enumerate(locks)], open(os.path.join(out, "locks_resolved.json"), "w"))
obs = []
for i, item in enumerate(locks):
    g, pts, w = item[:3]
    shape = item[3] if len(item) > 3 else {}
    obs.append(lock(f"{g}{i}", pts, w, twist=0.0 if LAYOUT == "fan" else rng.uniform(-0.25, 0.25), **shape))


def scalp(front=0.30, side=-0.10, back=-0.55, scale=1.045):
    """Base layer under the locks (creators' first layer): a low-poly shell hugging the classic head, cut at the
    hairline, on its own UV tile so it bakes as shadowed lilac and fills every gap between locks."""
    ob = ms.classic_head(None, "#FFFFFF", r=0.6 * scale, hh=0.6 * scale, seg=24, rings=14, name="Scalp")
    bm = bmesh.new(); bm.from_mesh(ob.data)
    kill = []
    for v in bm.verts:
        x, y, z = -v.co.x, v.co.z - HC[1], v.co.y
        c = -z / max(1e-6, math.hypot(x, z))
        f, b = max(0.0, c) ** 2, max(0.0, -c) ** 2
        if y < side + (front - side) * f + (back - side) * b:
            kill.append(v)
    bmesh.ops.delete(bm, geom=kill, context="VERTS")
    bm.to_mesh(ob.data); bm.free()
    ob.data.materials.clear()
    me = ob.data
    for layer in list(me.uv_layers):
        me.uv_layers.remove(layer)
    uv = me.uv_layers.new(name="UVMap")
    tile = next(_tiles)
    for poly in me.polygons:
        for li in poly.loop_indices:
            co = me.vertices[me.loops[li].vertex_index].co
            uv.data[li].uv = tile_uv(tile, 0.5 + co.x / 1.4, 0.5 + co.y / 1.4)
    a = me.attributes.new("tlen", "FLOAT", "POINT")
    for i in range(len(me.vertices)):
        a.data[i].value = 0.8
    return ob


if os.environ.get("FORGE_SCALP", "1") == "1":
    obs.append(scalp())
bpy.data.objects.remove(shell, do_unlink=True)
hair = fl.join("Hair", obs)
fl.recalc_outside(hair)
for p in hair.data.polygons:
    p.use_smooth = True
bpy.ops.object.select_all(action="DESELECT"); hair.select_set(True); bpy.context.view_layer.objects.active = hair
bpy.ops.object.shade_smooth_by_angle(angle=math.radians(CREASE))

if os.environ.get("FORGE_NOBAKE"):                 # fitting loop: geometry only
    hair.data.calc_loop_triangles()
    fl.export_json([hair], os.path.join(out, "hair_meshes.json"), {"char": "UnboundShiro", "method": "locks"})
    print("HAIR_V13 tris", len(hair.data.loop_triangles), "area", round(sum(p.area for p in hair.data.polygons), 2))
    sys.exit(0)
exec(open(os.path.join(here, "hair_softbake.py")).read())
bake_soft(hair, os.path.join(out, "hair_tex.png"), tip_attr="tlen", tip_mix=float(os.environ.get("FORGE_TIPMIX", "0.75")), under=0.35, unwrap=False, ao_dist=0.06,
          ao_k=float(os.environ.get("FORGE_AOK", "0.3")))
hair.data.calc_loop_triangles()
print("HAIR_V13 locks", len(locks), "tris", len(hair.data.loop_triangles),
      "area", round(sum(p.area for p in hair.data.polygons), 2))
fl.export_json([hair], os.path.join(out, "hair_meshes.json"), {"char": "UnboundShiro", "method": "locks"})
fl.export_fbx([hair], os.path.join(out, "hair.fbx"))

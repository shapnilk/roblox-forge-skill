# Soft hair bake shared by hair_sculpt.py (exec'd): gradient (white crown -> lilac tips) x lilac AO,
# no direct light; Roblox does the lighting. Palette matched to the benchmark texture range.
import math
import bpy
import forgelib as fl

TOP, MID, LOW, SHADOW = "#F3F0F4", "#DDD2E1", "#C6B1CD", "#AE94B3"   # benchmark p98 / p50 / p2 mauve
import os as _os
LOW, SHADOW = _os.environ.get("FORGE_LOW", LOW), _os.environ.get("FORGE_SHADOW", SHADOW)


def bake_soft(ob, png, size=1024, ao_dist=0.08, tip_attr=None, tip_mix=0.45, high=None, ao_fine=0.0,
              under=0.0, unwrap=True, ao_k=1.0):
    """high: detailed copy whose shading is baked onto ob (selected-to-active); ao_fine: second short AO
    for strand lines; under: lilac on down-facing surfaces (0..1)."""
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"; scene.cycles.samples = 64; scene.cycles.device = "CPU"
    bpy.ops.object.select_all(action="DESELECT"); ob.select_set(True); bpy.context.view_layer.objects.active = ob
    if unwrap:
        bpy.ops.object.mode_set(mode="EDIT"); bpy.ops.mesh.select_all(action="SELECT")
        bpy.ops.uv.smart_project(angle_limit=math.radians(70), island_margin=0.004)
        bpy.ops.object.mode_set(mode="OBJECT")
    img = bpy.data.images.new(ob.name + "_soft", size, size, alpha=False)
    src = high or ob
    mat = bpy.data.materials.new("softbake"); nodes, links = fl.nodes_of(mat)
    for x in list(nodes):
        nodes.remove(x)
    outn = nodes.new("ShaderNodeOutputMaterial"); emit = nodes.new("ShaderNodeEmission")
    links.new(emit.outputs[0], outn.inputs[0])
    geo = nodes.new("ShaderNodeNewGeometry")
    sep = nodes.new("ShaderNodeSeparateXYZ"); links.new(geo.outputs["Position"], sep.inputs[0])
    zs = [v.co.z for v in ob.data.vertices]
    mr = nodes.new("ShaderNodeMapRange")
    mr.inputs["From Min"].default_value = min(zs); mr.inputs["From Max"].default_value = max(zs)
    links.new(sep.outputs["Z"], mr.inputs["Value"])
    ramp = nodes.new("ShaderNodeValToRGB"); ramp.color_ramp.interpolation = "EASE"
    e = ramp.color_ramp.elements
    e[0].position = 0.0; e[0].color = fl.lin(fl.hexcol(LOW))
    e[1].position = 1.0; e[1].color = fl.lin(fl.hexcol(TOP))
    m = e.new(0.55); m.color = fl.lin(fl.hexcol(MID))
    fac = mr.outputs["Result"]
    if tip_attr:            # per-lock tint: height factor x (1 - tip_mix * t^1.5), t = 0 root .. 1 tip
        at = nodes.new("ShaderNodeAttribute"); at.attribute_type = "GEOMETRY"; at.attribute_name = tip_attr
        pw = nodes.new("ShaderNodeMath"); pw.operation = "POWER"; pw.inputs[1].default_value = 1.5
        links.new(at.outputs["Fac"], pw.inputs[0])
        ma = nodes.new("ShaderNodeMath"); ma.operation = "MULTIPLY_ADD"
        ma.inputs[1].default_value = -tip_mix; ma.inputs[2].default_value = 1.0
        links.new(pw.outputs[0], ma.inputs[0])
        mu = nodes.new("ShaderNodeMath"); mu.operation = "MULTIPLY"
        links.new(fac, mu.inputs[0]); links.new(ma.outputs[0], mu.inputs[1])
        fac = mu.outputs[0]
    links.new(fac, ramp.inputs["Fac"])
    ao = nodes.new("ShaderNodeAmbientOcclusion"); ao.inputs["Distance"].default_value = ao_dist; ao.samples = 16
    aom = nodes.new("ShaderNodeMapRange")
    aom.inputs["From Min"].default_value = 0.25; aom.inputs["From Max"].default_value = 0.95
    aom.interpolation_type = "SMOOTHSTEP"
    links.new(ao.outputs["AO"], aom.inputs["Value"])
    shade = aom.outputs["Result"]
    if ao_k < 1.0:          # weaken occlusion: 1 - ao_k * (1 - ao)
        ak = nodes.new("ShaderNodeMath"); ak.operation = "MULTIPLY_ADD"
        ak.inputs[1].default_value = ao_k; ak.inputs[2].default_value = 1.0 - ao_k
        links.new(shade, ak.inputs[0]); shade = ak.outputs[0]
    if ao_fine:
        ao2 = nodes.new("ShaderNodeAmbientOcclusion"); ao2.inputs["Distance"].default_value = ao_fine; ao2.samples = 16
        m2 = nodes.new("ShaderNodeMapRange"); m2.interpolation_type = "SMOOTHSTEP"
        m2.inputs["From Min"].default_value = 0.35; m2.inputs["From Max"].default_value = 0.9
        links.new(ao2.outputs["AO"], m2.inputs["Value"])
        mm = nodes.new("ShaderNodeMath"); mm.operation = "MULTIPLY"
        links.new(shade, mm.inputs[0]); links.new(m2.outputs["Result"], mm.inputs[1])
        shade = mm.outputs[0]
    if under:               # 1 for up-facing .. (1 - under) for down-facing
        sn = nodes.new("ShaderNodeSeparateXYZ"); links.new(geo.outputs["Normal"], sn.inputs[0])
        mu2 = nodes.new("ShaderNodeMapRange"); mu2.clamp = True
        mu2.inputs["From Min"].default_value = -1.0; mu2.inputs["From Max"].default_value = 0.6
        mu2.inputs["To Min"].default_value = 1.0 - under
        links.new(sn.outputs["Z"], mu2.inputs["Value"])
        mm2 = nodes.new("ShaderNodeMath"); mm2.operation = "MULTIPLY"
        links.new(shade, mm2.inputs[0]); links.new(mu2.outputs["Result"], mm2.inputs[1])
        shade = mm2.outputs[0]
    mix = nodes.new("ShaderNodeMix"); mix.data_type = "RGBA"
    links.new(shade, mix.inputs["Factor"])
    mix.inputs[6].default_value = fl.lin(fl.hexcol(SHADOW))
    links.new(ramp.outputs["Color"], mix.inputs[7])
    links.new(mix.outputs[2], emit.inputs["Color"])
    src.data.materials.clear(); src.data.materials.append(mat)
    if high:
        tmat = bpy.data.materials.new("bake_target"); tn, _ = fl.nodes_of(tmat)
        ob.data.materials.clear(); ob.data.materials.append(tmat)
        tn_ = tn
    else:
        tn_ = nodes
    tex = tn_.new("ShaderNodeTexImage"); tex.image = img; tn_.active = tex
    scene.cycles.bake_type = "EMIT"; scene.render.bake.margin = 8
    scene.render.bake.use_selected_to_active = bool(high)
    if high:
        scene.render.bake.cage_extrusion = 0.05; scene.render.bake.max_ray_distance = 0.12
        high.select_set(True); ob.select_set(True); bpy.context.view_layer.objects.active = ob
    bpy.ops.object.bake(type="EMIT")
    img.filepath_raw = png; img.file_format = "PNG"; img.save()
    ob.data.materials.clear(); ob.data.materials.append(fl.flat_material(ob.name + "_M", TOP, png))
    return png

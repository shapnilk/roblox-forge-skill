"""Forge Blender helpers: R6 preview body, anime hair locks, head shell, toon bake, outline, export.

Coordinates: specs are written in Roblox character space (studs, root/torso centre at origin,
X = character's right, Y = up, Z = back). Blender space is (-x, z, y) so the character faces
Blender -Y (the Front view) without mirroring. rb2bl / bl2rb convert.
Run headless: blender --background --factory-startup --python build.py -- <char> <outdir>
"""
import bpy, bmesh, json, math, os
from mathutils import Vector

HEAD_C = (0.0, 1.5, 0.0)   # Roblox head centre (root-relative)
TEMPLATE_W, TEMPLATE_H = 585, 559


def rb2bl(p):
    return Vector((-p[0], p[2], p[1]))


def bl2rb(v):
    return (-v.x, v.z, v.y)


def hexcol(h, a=1.0):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) / 255 for i in (0, 2, 4)) + (a,)


def lin(c):
    return tuple((v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4) for v in c[:3]) + (c[3],)


def clear_scene():
    for o in list(bpy.data.objects):
        bpy.data.objects.remove(o, do_unlink=True)
    for coll in (bpy.data.meshes, bpy.data.materials, bpy.data.images):
        for b in list(coll):
            coll.remove(b)


def nodes_of(mat):
    try:
        mat.use_nodes = True
    except Exception:
        pass
    return mat.node_tree.nodes, mat.node_tree.links


def flat_material(name, color_hex=None, image_path=None):
    """Unlit-looking material for previews: emission of a colour or an image."""
    mat = bpy.data.materials.new(name)
    nodes, links = nodes_of(mat)
    for n in list(nodes):
        nodes.remove(n)
    out = nodes.new("ShaderNodeOutputMaterial")
    bsdf = nodes.new("ShaderNodeBsdfPrincipled")
    bsdf.inputs["Roughness"].default_value = 0.85
    links.new(bsdf.outputs[0], out.inputs[0])
    if image_path:
        tex = nodes.new("ShaderNodeTexImage")
        tex.image = bpy.data.images.load(image_path, check_existing=True)
        tex.interpolation = "Closest" if image_path.endswith("_px.png") else "Linear"
        links.new(tex.outputs["Color"], bsdf.inputs["Base Color"])
        links.new(tex.outputs["Alpha"], bsdf.inputs["Alpha"])
    else:
        bsdf.inputs["Base Color"].default_value = lin(hexcol(color_hex))
    mat.diffuse_color = lin(hexcol(color_hex)) if color_hex else (1, 1, 1, 1)
    return mat


def new_object(name, verts, faces, uvs=None, smooth=True):
    """verts in Roblox space; uvs = per-face-corner list matching faces (optional)."""
    me = bpy.data.meshes.new(name)
    me.from_pydata([rb2bl(v) for v in verts], [], faces)
    if uvs is not None:
        layer = me.uv_layers.new(name="UVMap")
        k = 0
        for poly in me.polygons:
            for li in poly.loop_indices:
                layer.data[li].uv = uvs[k]
                k += 1
    me.update()
    for p in me.polygons:
        p.use_smooth = smooth
    ob = bpy.data.objects.new(name, me)
    bpy.context.collection.objects.link(ob)
    return ob


# ---------------------------------------------------------------- R6 body with template UVs
TORSO_R = {"U": (231, 8, 128, 64), "R": (165, 74, 64, 128), "F": (231, 74, 128, 128),
           "L": (361, 74, 64, 128), "B": (427, 74, 128, 128), "D": (231, 204, 128, 64)}
RLIMB_R = {"U": (217, 289, 64, 64), "L": (19, 355, 64, 128), "B": (85, 355, 64, 128),
           "R": (151, 355, 64, 128), "F": (217, 355, 64, 128), "D": (217, 485, 64, 64)}
LLIMB_R = {"U": (308, 289, 64, 64), "F": (308, 355, 64, 128), "L": (374, 355, 64, 128),
           "B": (440, 355, 64, 128), "R": (506, 355, 64, 128), "D": (308, 485, 64, 64)}
R6_PARTS = {"Torso": ((0, 0, 0), (2, 2, 1), TORSO_R), "RightArm": ((1.5, 0, 0), (1, 2, 1), RLIMB_R),
            "LeftArm": ((-1.5, 0, 0), (1, 2, 1), LLIMB_R), "RightLeg": ((0.5, -2, 0), (1, 2, 1), RLIMB_R),
            "LeftLeg": ((-0.5, -2, 0), (1, 2, 1), LLIMB_R)}


def _face_quads(c, s):
    """Each face: 4 corners ordered image top-left, top-right, bottom-right, bottom-left.
    Verified in Studio: viewed from outside, image left = viewer's left, image up = world up."""
    x0, x1 = c[0] - s[0] / 2, c[0] + s[0] / 2
    y0, y1 = c[1] - s[1] / 2, c[1] + s[1] / 2
    z0, z1 = c[2] - s[2] / 2, c[2] + s[2] / 2
    return {
        "F": [(x1, y1, z0), (x0, y1, z0), (x0, y0, z0), (x1, y0, z0)],
        "B": [(x0, y1, z1), (x1, y1, z1), (x1, y0, z1), (x0, y0, z1)],
        "R": [(x1, y1, z1), (x1, y1, z0), (x1, y0, z0), (x1, y0, z1)],
        "L": [(x0, y1, z0), (x0, y1, z1), (x0, y0, z1), (x0, y0, z0)],
        "U": [(x1, y1, z1), (x0, y1, z1), (x0, y1, z0), (x1, y1, z0)],
        "D": [(x1, y0, z0), (x0, y0, z0), (x0, y0, z1), (x1, y0, z1)],
    }


def r6_body(shirt_png, pants_png, skin_hex):
    """Five boxes; torso/arms take the shirt, legs the pants (torso pants region ignored, as in R6
    when a shirt exists). Skin shows where the template is transparent (composited at build time)."""
    obs = []
    for name, (c, s, reg) in R6_PARTS.items():
        quads = _face_quads(c, s)
        verts, faces, uvs = [], [], []
        for f, q in quads.items():
            x, y, w, h = reg[f]
            base = len(verts)
            verts += q
            faces.append((base, base + 1, base + 2, base + 3))
            for px, py in [(x, y), (x + w, y), (x + w, y + h), (x, y + h)]:
                uvs.append((px / TEMPLATE_W, 1 - py / TEMPLATE_H))
        ob = new_object(name, verts, faces, uvs, smooth=False)
        png = pants_png if "Leg" in name else shirt_png
        ob.data.materials.append(flat_material(name + "_M", skin_hex, png))
        obs.append(ob)
    return obs


# ---------------------------------------------------------------- head shell (anime head + face)
def head_shell(face_png, skin_hex, size=(1.34, 1.30, 1.30), power=2.6, seg=40, rings=28, jaw=0.12):
    """Rounded-box head (superellipsoid) centred on the R6 head, slightly tapered chin.
    Planar front UVs: u from character right(+x)..left, v from bottom..top over +-size/2."""
    hx, hy, hz = size[0] / 2, size[1] / 2, size[2] / 2
    e = 2.0 / power
    verts, faces, uvs = [], [], []
    def sgnpow(v, p):
        return math.copysign(abs(v) ** p, v)
    grid = []
    for i in range(rings + 1):
        th = -math.pi / 2 + math.pi * i / rings
        row = []
        for j in range(seg):
            ph = 2 * math.pi * j / seg
            x = hx * sgnpow(math.cos(th), e) * sgnpow(math.sin(ph), e)
            y = hy * sgnpow(math.sin(th), e)
            z = -hz * sgnpow(math.cos(th), e) * sgnpow(math.cos(ph), e)
            t = max(0.0, -y / hy)                     # 0 at middle, 1 at chin
            k = 1 - jaw * t * t
            x *= k
            if z < 0:
                z *= 1 - 0.5 * jaw * t * t
            row.append(len(verts))
            verts.append((HEAD_C[0] + x, HEAD_C[1] + y, HEAD_C[2] + z))
        grid.append(row)
    for i in range(rings):
        for j in range(seg):
            a, b = grid[i][j], grid[i][(j + 1) % seg]
            c, d = grid[i + 1][(j + 1) % seg], grid[i + 1][j]
            faces.append((a, b, c, d))
    for f in faces:
        for vi in f:
            x, y, z = verts[vi]
            if z - HEAD_C[2] > 0.0:      # back half -> skin-only edge column, never the face
                uvs.append((0.01 if x > HEAD_C[0] else 0.99, 0.03))
            else:
                uvs.append((0.5 - (x - HEAD_C[0]) / (2 * hx) * 0.98, 0.5 + (y - HEAD_C[1]) / (2 * hy) * 0.98))
    ob = new_object("HeadShell", verts, faces, uvs)
    recalc_outside(ob)
    ob.data.materials.append(flat_material("HeadShell_M", skin_hex, face_png))
    return ob


# ---------------------------------------------------------------- anime hair locks
def catmull(points, steps):
    ps = [Vector(p) for p in points]
    out = []
    for i in range(len(ps) - 1):
        a, b, c, d = ps[max(0, i - 1)], ps[i], ps[i + 1], ps[min(len(ps) - 1, i + 2)]
        for j in range(steps):
            t = j / steps
            out.append(0.5 * ((2 * b) + (-a + c) * t + (2 * a - 5 * b + 4 * c - d) * t * t
                              + (-a + 3 * b - 3 * c + d) * t ** 3))
    out.append(ps[-1])
    return out


def lock(name, pts, width, thick=0.38, up=(0, 0, 1), steps=5, sides=8, bulge=0.35, tip=1.25, root_scale=0.9, tile=None, grid=10, ridge=False, root_w=None):
    """One anime hair clump: lens cross-section along a Catmull-Rom spine, sharp tip.
    pts are Roblox-space; `up` (Roblox) orients the flat side (usually the scalp normal)."""
    spine = catmull(pts, steps)
    n = len(spine)
    upv = Vector(up).normalized()
    verts, faces = [], []
    for i, p in enumerate(spine):
        s = i / (n - 1)
        t = (spine[min(i + 1, n - 1)] - spine[max(i - 1, 0)]).normalized()
        side = t.cross(upv)
        if side.length < 1e-4:
            side = t.cross(Vector((1, 0, 0)))
        side.normalize()
        nrm = side.cross(t).normalized()
        w = width * (1 - s) ** (0.85 * tip) * (0.8 + bulge * 1.2 * math.sin(math.pi * s))   # leaf: widest ~25%, sharp tip
        if root_w is not None:      # strands from the crown whorl start narrow, widen, then taper
            w *= root_w + (1 - root_w) * min(1.0, s / 0.35) ** 0.8
        h = w * thick
        if i == n - 1:
            verts.append(tuple(p))
            continue
        for k in range(sides):
            a = 2 * math.pi * k / sides
            # lens: sharp at the side edges, rounded over the top
            ca, sa = math.cos(a), math.sin(a)
            if ridge:      # folded blade: peaked top (one half catches light, the other shades), flat underside
                lift = h * (1 - abs(ca)) ** 1.0 if sa >= 0 else h * 0.55 * sa
            else:
                lift = h * sa * (1 - 0.35 * abs(ca))
            verts.append(tuple(p + side * (w * ca) + nrm * lift))
    rings = n - 1
    uvs = [] if tile is not None else None
    def UV(u, v):
        # tile-local u (around: 0..0.5 outer face, 0.5..1 inner face), v (0 root .. 1 tip) -> atlas
        tx, ty = tile % grid, tile // grid
        pad = 0.05
        return ((tx + pad + u * (1 - 2 * pad)) / grid, 1 - (ty + pad + v * (1 - 2 * pad)) / grid)
    for i in range(rings - 1):
        for k in range(sides):
            a, b = i * sides + k, i * sides + (k + 1) % sides
            faces.append((a, b, b + sides, a + sides))
            if uvs is not None:
                u0, u1 = k / sides, (k + 1) / sides
                v0, v1 = i / (n - 1), (i + 1) / (n - 1)
                uvs += [UV(u0, v0), UV(u1, v0), UV(u1, v1), UV(u0, v1)]
    tipi = len(verts) - 1
    last = (rings - 1) * sides
    for k in range(sides):
        faces.append((last + k, last + (k + 1) % sides, tipi))
        if uvs is not None:
            vl = (rings - 1) / (n - 1)
            uvs += [UV(k / sides, vl), UV((k + 1) / sides, vl), UV((k + 0.5) / sides, 1.0)]
    faces.append(tuple(reversed(range(sides))))   # root cap
    if uvs is not None:
        uvs += [UV(0.75, 0.0)] * sides
    return new_object(name, verts, faces, uvs)


def scalp_point(az_deg, el_deg, r=(0.70, 0.705, 0.69), lift=0.0):
    """Point on an ellipsoid around the head centre. az 0 = front (-Z), +90 = character right (+X);
    el 0 = equator, 90 = top. Returns (point, outward normal) in Roblox space."""
    az, el = math.radians(az_deg), math.radians(el_deg)
    d = Vector((math.sin(az) * math.cos(el), math.sin(el), -math.cos(az) * math.cos(el)))
    p = Vector(HEAD_C) + Vector((d.x * (r[0] + lift), d.y * (r[1] + lift), d.z * (r[2] + lift)))
    nrm = Vector((d.x / r[0], d.y / r[1], d.z / r[2])).normalized()
    return p, nrm


def flow_lock(name, az, el0, el1, width, lift=0.10, lift_tip=0.18, drift=0.0, n=6, thick=0.40,
              steps=3, sides=6, tip=0.9, bulge=0.45, sink=0.03, r=None, tile=None, grid=10):
    """Strand combed over the skull from el0 (near the whorl) down to el1, hugging the head with a
    growing lift, ending in a pointed tip that flicks outward. drift bends it sideways (degrees)."""
    pts = []
    mid_n = None
    for k in range(n):
        t = k / (n - 1)
        el = el0 + (el1 - el0) * t
        a = az + drift * t * t
        lf = -sink + (lift + sink) * min(1.0, t / 0.4) + (lift_tip - lift) * max(0.0, (t - 0.6) / 0.4)
        p, nrm = scalp_point(a, el, lift=lf) if r is None else scalp_point(a, el, r=r, lift=lf)
        pts.append(p)
        if k == n // 2:
            mid_n = nrm
    return lock(name, pts, width, thick=thick, up=mid_n, steps=steps, sides=sides, tip=tip, bulge=bulge, tile=tile, grid=grid)


def scalp_cap(name, el_min=8, r=(0.70, 0.71, 0.69), seg=32, rings=12, front_cut=28, tile=None, tgrid=10):
    """Hair base volume over the skull; lower at the back/sides, raised hairline at the front."""
    verts, faces = [], []
    grid = []
    for i in range(rings + 1):
        row = []
        for j in range(seg):
            az = 360 * j / seg
            frontness = max(0.0, math.cos(math.radians(az)))
            lo = el_min + front_cut * frontness ** 2
            el = lo + (90 - lo) * i / rings
            p, _ = scalp_point(az, min(el, 89.9), r)
            row.append(len(verts))
            verts.append(tuple(p))
        grid.append(row)
    for i in range(rings):
        for j in range(seg):
            faces.append((grid[i][j], grid[i][(j + 1) % seg], grid[i + 1][(j + 1) % seg], grid[i + 1][j]))
    top = len(verts)
    verts.append(tuple(Vector(HEAD_C) + Vector((0, r[1], 0))))
    for j in range(seg):
        faces.append((grid[rings][j], grid[rings][(j + 1) % seg], top))
    uvs = None
    if tile is not None:     # whole cap samples one atlas tile: u around, v from crown down
        tx, ty = tile % tgrid, tile // tgrid
        def UV(u, v):
            return ((tx + 0.05 + u * 0.9) / tgrid, 1 - (ty + 0.05 + v * 0.9) / tgrid)
        uvs = []
        for i in range(rings):
            for j in range(seg):
                for (ii, jj) in ((i, j), (i, j + 1), (i + 1, j + 1), (i + 1, j)):
                    uvs.append(UV(jj / seg, 1 - ii / rings))
        for j in range(seg):
            uvs += [UV(j / seg, 0.0), UV((j + 1) / seg, 0.0), UV((j + 0.5) / seg, 0.0)]
    return new_object(name, verts, faces, uvs)


def tube_ring(name, center, rx, rz, y0, y1, thick=0.06, seg=40, flare=0.0, front_gap=0.0):
    """Collar-style band: open cylinder with thickness; optional front gap (degrees)."""
    verts, faces = [], []
    cols = []
    for j in range(seg + (1 if front_gap else 0)):
        a = math.radians(front_gap / 2) + (2 * math.pi - math.radians(front_gap)) * j / seg if front_gap else 2 * math.pi * j / seg
        col = []
        for (y, k) in [(y0, 0), (y1, 1)]:
            for r in (0, 1):
                f = 1 + flare * k
                rr = 1 + (thick if r else 0) / max(rx, rz)
                col.append(len(verts))
                verts.append((center[0] + math.sin(a) * rx * f * rr, y, center[2] - math.cos(a) * rz * f * rr))
        cols.append(col)
    n = len(cols)
    for j in range(n - 1 if front_gap else n):
        a, b = cols[j], cols[(j + 1) % n]
        faces.append((a[1], b[1], b[3], a[3]))   # outer
        faces.append((a[2], b[2], b[0], a[0]))   # inner
        faces.append((a[3], b[3], b[2], a[2]))   # top
        faces.append((a[0], b[0], b[1], a[1]))   # bottom
    return new_object(name, verts, faces)


def join(name, obs):
    bpy.ops.object.select_all(action="DESELECT")
    for o in obs:
        o.select_set(True)
    bpy.context.view_layer.objects.active = obs[0]
    bpy.ops.object.join()
    o = bpy.context.object
    o.name = name
    o.data.name = name
    return o


def recalc_outside(ob):
    bm = bmesh.new()
    bm.from_mesh(ob.data)
    bmesh.ops.recalc_face_normals(bm, faces=list(bm.faces))
    bm.to_mesh(ob.data)
    bm.free()
    ob.data.update()


# ---------------------------------------------------------------- toon bake
def toon_bake(ob, out_png, base_hex, shade_hex, deep_hex, light=(0.35, 1.0, -0.55), size=1024,
              band=0.18, ao_cut=0.62, tip_hex=None, tip_from=0.0, ao_dist=0.12, low_hex=None, low_y=(0.0, 1.0)):
    """Bake a hard-banded toon texture: base where N.L > band, shade below, deep in occlusion.
    Optional tip gradient (e.g. lavender tips) by world height above tip_from (Roblox Y)."""
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.samples = 16
    scene.cycles.device = "CPU"
    bpy.ops.object.select_all(action="DESELECT")
    ob.select_set(True)
    bpy.context.view_layer.objects.active = ob
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="SELECT")
    bpy.ops.uv.smart_project(angle_limit=math.radians(60), island_margin=0.004)
    bpy.ops.object.mode_set(mode="OBJECT")
    img = bpy.data.images.new(ob.name + "_toon", size, size, alpha=False)
    mat = bpy.data.materials.new(ob.name + "_bake")
    nodes, links = nodes_of(mat)
    for n in list(nodes):
        nodes.remove(n)
    out = nodes.new("ShaderNodeOutputMaterial")
    emit = nodes.new("ShaderNodeEmission")
    links.new(emit.outputs[0], out.inputs[0])
    geo = nodes.new("ShaderNodeNewGeometry")
    dot = nodes.new("ShaderNodeVectorMath"); dot.operation = "DOT_PRODUCT"
    dot.inputs[1].default_value = rb2bl(Vector(light).normalized())
    links.new(geo.outputs["Normal"], dot.inputs[0])
    ramp = nodes.new("ShaderNodeValToRGB")
    ramp.color_ramp.interpolation = "CONSTANT"
    els = ramp.color_ramp.elements
    els[0].position = 0.0; els[0].color = lin(hexcol(shade_hex))
    els[1].position = 0.5 + band / 2; els[1].color = lin(hexcol(base_hex))
    mr = nodes.new("ShaderNodeMapRange")          # dot -1..1 -> 0..1
    mr.inputs["From Min"].default_value = -1; mr.inputs["From Max"].default_value = 1
    links.new(dot.outputs["Value"], mr.inputs["Value"])
    links.new(mr.outputs["Result"], ramp.inputs["Fac"])
    ao = nodes.new("ShaderNodeAmbientOcclusion"); ao.inputs["Distance"].default_value = ao_dist
    aor = nodes.new("ShaderNodeValToRGB"); aor.color_ramp.interpolation = "CONSTANT"
    aor.color_ramp.elements[0].position = 0.0; aor.color_ramp.elements[0].color = (1, 1, 1, 1)
    aor.color_ramp.elements[1].position = ao_cut; aor.color_ramp.elements[1].color = (0, 0, 0, 1)
    links.new(ao.outputs["AO"], aor.inputs["Fac"])
    mix = nodes.new("ShaderNodeMix"); mix.data_type = "RGBA"
    links.new(aor.outputs["Color"], mix.inputs["Factor"])
    links.new(ramp.outputs["Color"], mix.inputs[6])
    mix.inputs[7].default_value = lin(hexcol(deep_hex))
    col = mix.outputs[2]
    if tip_hex:
        sep = nodes.new("ShaderNodeSeparateXYZ")
        links.new(geo.outputs["Position"], sep.inputs[0])
        tr = nodes.new("ShaderNodeValToRGB"); tr.color_ramp.interpolation = "LINEAR"
        tr.color_ramp.elements[0].position = 0.0; tr.color_ramp.elements[0].color = (0, 0, 0, 1)
        tr.color_ramp.elements[1].position = 1.0; tr.color_ramp.elements[1].color = (1, 1, 1, 1)
        mr2 = nodes.new("ShaderNodeMapRange")
        mr2.inputs["From Min"].default_value = tip_from; mr2.inputs["From Max"].default_value = tip_from + 0.5
        links.new(sep.outputs["Z"], mr2.inputs["Value"])
        links.new(mr2.outputs["Result"], tr.inputs["Fac"])
        mix2 = nodes.new("ShaderNodeMix"); mix2.data_type = "RGBA"; mix2.blend_type = "MULTIPLY"
        links.new(tr.outputs["Color"], mix2.inputs["Factor"])
        links.new(col, mix2.inputs[6])
        mix2.inputs[7].default_value = lin(hexcol(tip_hex))
        col = mix2.outputs[2]
    if low_hex:      # multiply a tint into the lower part (Roblox Y low_y[0] full .. low_y[1] none)
        sep2 = nodes.new("ShaderNodeSeparateXYZ")
        links.new(geo.outputs["Position"], sep2.inputs[0])
        mr3 = nodes.new("ShaderNodeMapRange")
        mr3.inputs["From Min"].default_value = low_y[0]; mr3.inputs["From Max"].default_value = low_y[1]
        links.new(sep2.outputs["Z"], mr3.inputs["Value"])
        mix3 = nodes.new("ShaderNodeMix"); mix3.data_type = "RGBA"; mix3.blend_type = "MULTIPLY"
        inv = nodes.new("ShaderNodeMath"); inv.operation = "SUBTRACT"; inv.inputs[0].default_value = 1.0
        links.new(mr3.outputs["Result"], inv.inputs[1])
        links.new(inv.outputs[0], mix3.inputs["Factor"])
        links.new(col, mix3.inputs[6])
        mix3.inputs[7].default_value = lin(hexcol(low_hex))
        col = mix3.outputs[2]
    links.new(col, emit.inputs["Color"])
    tex = nodes.new("ShaderNodeTexImage"); tex.image = img
    nodes.active = tex
    ob.data.materials.clear()
    ob.data.materials.append(mat)
    scene.cycles.bake_type = "EMIT"
    scene.render.bake.margin = 6
    bpy.ops.object.bake(type="EMIT")
    img.filepath_raw = out_png
    img.file_format = "PNG"
    img.save()
    # swap to the plain textured preview material
    ob.data.materials.clear()
    ob.data.materials.append(flat_material(ob.name + "_M", base_hex, out_png))
    return out_png


def outline_shell(ob, thickness=0.022, color_hex="#2A2638"):
    """Inverted hull: copy pushed out along normals with flipped faces; renders as a rim in Roblox
    (back-face culling) and in Blender with backface culling on."""
    me = ob.data.copy()
    me.name = ob.name + "_Outline"
    bm = bmesh.new()
    bm.from_mesh(me)
    bm.normal_update()
    for v in bm.verts:
        v.co += v.normal * thickness
    bmesh.ops.reverse_faces(bm, faces=list(bm.faces))
    bm.to_mesh(me)
    bm.free()
    o = bpy.data.objects.new(ob.name + "_Outline", me)
    bpy.context.collection.objects.link(o)
    o.data.materials.clear()
    m = flat_material(o.name + "_M", color_hex)
    m.use_backface_culling = True
    o.data.materials.append(m)
    return o


# ---------------------------------------------------------------- render + export
def setup_render(res=(720, 960)):
    scene = bpy.context.scene
    scene.render.engine = "BLENDER_WORKBENCH"
    sh = scene.display.shading
    sh.light = "STUDIO"
    sh.color_type = "TEXTURE"
    sh.show_backface_culling = True
    sh.show_cavity = False
    scene.render.resolution_x, scene.render.resolution_y = res
    scene.render.film_transparent = False
    world = scene.world or bpy.data.worlds.new("World")
    scene.world = world
    scene.display.shading.background_type = "VIEWPORT" if hasattr(sh, "background_type") else None
    try:
        sh.background_type = "VIEWPORT"
        sh.background_color = (0.16, 0.17, 0.2)
    except Exception:
        pass


def render_views(outdir, prefix, target=(0, 0.2, 0), dist=9.0, views=None, ortho=4.4):
    views = views or {"front": 0, "three_quarter": 35, "side": 90, "back": 180}
    scene = bpy.context.scene
    cam_data = bpy.data.cameras.new("Cam")
    cam_data.type = "ORTHO"
    cam_data.ortho_scale = ortho
    cam = bpy.data.objects.new("Cam", cam_data)
    bpy.context.collection.objects.link(cam)
    scene.camera = cam
    paths = []
    tgt = rb2bl(target)
    for name, az in views.items():
        a = math.radians(az)
        # az 0 = in front of the character (Roblox -Z), positive = toward character's right (+X)
        pos_rb = (target[0] + math.sin(a) * dist, target[1] + 0.6, target[2] - math.cos(a) * dist)
        cam.location = rb2bl(pos_rb)
        d = tgt - cam.location
        cam.rotation_euler = d.to_track_quat("-Z", "Y").to_euler()
        path = os.path.join(outdir, f"{prefix}_{name}.png")
        scene.render.filepath = path
        bpy.ops.render.render(write_still=True)
        paths.append(path)
    return paths


def export_json(obs, path, meta=None):
    """Per object: Roblox-space vertex/normal/uv per triangle corner (unwelded), for the Studio
    session-bake previewer. Texture file names travel in 'texture'."""
    data = {"schema": "forge-mesh-1", "axes": "RobloxYUp", "pivot": "RootRelative", "meshes": [], **(meta or {})}
    dg = bpy.context.evaluated_depsgraph_get()
    for ob in obs:
        ev = ob.evaluated_get(dg)
        me = ev.to_mesh()
        me.calc_loop_triangles()
        uv = me.uv_layers.active.data if me.uv_layers.active else None
        P, N, U, T, seen = [], [], [], [], {}
        for tri in me.loop_triangles:
            idx = []
            for li, vi in zip(tri.loops, tri.vertices):
                co = ob.matrix_world @ me.vertices[vi].co
                no = me.corner_normals[li].vector if hasattr(me, "corner_normals") else me.loops[li].normal
                p = tuple(round(c, 4) for c in bl2rb(co))
                n = tuple(round(c, 3) for c in bl2rb(no))
                u = (round(uv[li].uv[0], 4), round(1 - uv[li].uv[1], 4)) if uv else None
                key = (p, n, u)                      # shared corners -> one vertex (EditableMesh 60k cap)
                if key not in seen:
                    seen[key] = len(P)
                    P.append(list(p)); N.append(list(n))
                    if uv:
                        U.append(list(u))
                idx.append(seen[key])
            if len(set(idx)) == 3:
                T.append(idx)
        mat = ob.data.materials[0] if ob.data.materials else None
        texture = None
        if mat and mat.node_tree:
            for n in mat.node_tree.nodes:
                if n.type == "TEX_IMAGE" and n.image:
                    texture = os.path.basename(n.image.filepath_raw or n.image.filepath)
        color = list(mat.diffuse_color[:3]) if mat else [1, 1, 1]
        data["meshes"].append({"name": ob.name, "vertices": P, "normals": N, "uvs": U or None,
                               "triangles": T, "texture": texture,
                               "color": [round(c ** (1 / 2.2), 4) for c in color],
                               "outline": ob.name.endswith("_Outline")})
        ev.to_mesh_clear()
    with open(path, "w") as f:
        json.dump(data, f, separators=(",", ":"))
    return path


def export_fbx(obs, path):
    bpy.ops.object.select_all(action="DESELECT")
    for o in obs:
        o.select_set(True)
    bpy.ops.export_scene.fbx(filepath=path, use_selection=True, apply_unit_scale=True,
                             axis_forward="-Z", axis_up="Y", mesh_smooth_type="FACE",
                             path_mode="COPY", embed_textures=True)
    return path


def tri_count(obs):
    n = 0
    for o in obs:
        o.data.calc_loop_triangles()
        n += len(o.data.loop_triangles)
    return n

"""Lock layout statistics from smooth patches (lock sides): root/tip elevation, tip stand-off from the skull,
tip direction (outward vs down), length, width. Works on the benchmark (study only) and on our meshes, so the
generator can be fitted to numbers instead of eyeballing.
python lock_stats.py [ours_meshes.json ...]"""
import json, math, sys
from collections import defaultdict
import numpy as np

HC = np.array([0.0, 1.5, 0.0])


def head_r(d, r=0.6, hh=0.6, v=5.0):
    lo, hi = 0.3, 1.0
    for _ in range(25):
        m = (lo + hi) / 2
        q = d * m
        lo, hi = (m, hi) if (math.hypot(q[0], q[2]) / r) ** v + (abs(q[1]) / hh) ** v <= 1 else (lo, m)
    return lo


def patches(P, F, N):
    Nn = N / np.linalg.norm(N, axis=1, keepdims=True)
    key = {}
    W = np.array([key.setdefault(tuple(k), len(key)) for k in np.round(P, 4)])
    par = list(range(len(F)))
    def find(a):
        while par[a] != a:
            par[a] = par[par[a]]; a = par[a]
        return a
    et = defaultdict(list)
    for t, f in enumerate(F):
        for a, b in ((0, 1), (1, 2), (2, 0)):
            et[(min(W[f[a]], W[f[b]]), max(W[f[a]], W[f[b]]))].append((t, f[a], f[b]))
    for lst in et.values():
        if len(lst) == 2:
            (t1, a1, b1), (t2, a2, b2) = lst
            mm = {W[a2]: a2, W[b2]: b2}
            if all(Nn[v] @ Nn[mm[W[v]]] > 0.999 for v in (a1, b1)):
                par[find(t2)] = find(t1)
    return np.array([find(t) for t in range(len(F))])


def stats(P, F, N, min_area=0.02):
    pa = patches(P, F, N)
    rows = []
    for p in np.unique(pa):
        tris = F[pa == p]
        area = 0.5 * np.linalg.norm(np.cross(P[tris[:, 1]] - P[tris[:, 0]], P[tris[:, 2]] - P[tris[:, 0]]), axis=1).sum()
        if area < min_area:
            continue
        Q = P[np.unique(tris.ravel())]
        c = Q.mean(0)
        _, _, vt = np.linalg.svd(Q - c, full_matrices=False)
        ax = vt[0]; pr = (Q - c) @ ax
        lo, hi = Q[pr.argmin()], Q[pr.argmax()]
        # width near each end: spread across the axis within 15% of the length from that end
        L = pr.max() - pr.min()
        def width_at(mask):
            R = Q[mask] - c; R = R - np.outer(R @ ax, ax)
            return np.linalg.norm(R, axis=1).max() if mask.sum() else 0
        w_lo = width_at(pr < pr.min() + 0.15 * L); w_hi = width_at(pr > pr.max() - 0.15 * L)
        wd = np.array([math.sin(math.radians(175)) * math.cos(math.radians(74)), math.sin(math.radians(74)),
                       -math.cos(math.radians(175)) * math.cos(math.radians(74))])
        ang = lambda q: math.acos(max(-1, min(1, float((q - HC) @ wd / np.linalg.norm(q - HC)))))
        tip, root = (lo, hi) if ang(lo) > ang(hi) else (hi, lo)     # the end farther from the crown whorl
        rel_t, rel_r = tip - HC, root - HC
        dt, dr = rel_t / np.linalg.norm(rel_t), rel_r / np.linalg.norm(rel_r)
        standoff = np.linalg.norm(rel_t) - head_r(dt)
        tdir = (tip - root) / (np.linalg.norm(tip - root) + 1e-9)
        horiz = np.array([rel_t[0], 0, rel_t[2]]); horiz /= np.linalg.norm(horiz) + 1e-9
        rows.append({"area": area, "len": L, "width": 2 * max(w_lo, w_hi), "el_tip": math.degrees(math.asin(dt[1])),
                     "el_root": math.degrees(math.asin(dr[1])), "standoff": standoff,
                     "tip_down": -tdir[1], "tip_out": float(tdir @ horiz)})
    return rows


def summary(name, rows):
    A = np.array([r["area"] for r in rows]); wsum = A.sum()
    def pct(k):
        v = np.array([r[k] for r in rows]); return np.percentile(v, [10, 50, 90]).round(2).tolist()
    print(f"{name}: lock sides {len(rows)} (area {wsum:.2f})")
    for k in ("len", "width", "el_root", "el_tip", "standoff", "tip_down", "tip_out"):
        print(f"   {k:9s} p10/50/90 {pct(k)}")
    # where tips are by elevation band and how far they stand off
    bands = [(-90, -20), (-20, 10), (10, 35), (35, 60), (60, 90)]
    print("   tips per elevation band (share, median standoff, median outwardness):")
    for lo, hi in bands:
        sel = [r for r in rows if lo <= r["el_tip"] < hi]
        if sel:
            print(f"     {lo:4d}..{hi:3d}: {len(sel) / len(rows):.2f}  standoff {np.median([r['standoff'] for r in sel]):.2f}"
                  f"  out {np.median([r['tip_out'] for r in sel]):.2f}  down {np.median([r['tip_down'] for r in sel]):.2f}")


if __name__ == "__main__":
    import os
    here = os.path.dirname(os.path.abspath(__file__))
    P = np.load(os.path.join(here, "tb_P4.npy")) + np.array([0.023, 1.817, 0.189])
    summary("benchmark", stats(P, np.load(os.path.join(here, "tb_F0.npy")), np.load(os.path.join(here, "tb_N.npy"))))
    for path in sys.argv[1:]:
        m = json.load(open(path))["meshes"][0]
        summary(path, stats(np.array(m["vertices"]), np.array(m["triangles"]), np.array(m["normals"])))

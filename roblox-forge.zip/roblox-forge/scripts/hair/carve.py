"""Multi-view silhouette carving (visual hull) from Studio green-screen captures.

Each capture: hair (any non-green, non-blue colour), face/head rendered flat blue, background green.
Camera: Roblox CFrame.lookAt(pos, target), vertical FOV in degrees, image size from the file.
Voxels are kept only if every view sees hair along their ray; voxels in front of the head that a view
sees as face are carved; voxels inside the head volume are removed (the hair is a shell around it).

python carve.py <views.json> <out_prefix>
views.json: {"fov": 6, "target": [x,y,z], "root": [x,y,z], "head": {"center": [...], "half": [...], "power": 3},
             "bounds": [[x0,y0,z0],[x1,y1,z1]], "voxel": 0.02, "views": [{"img": path, "cam": [x,y,z]}, ...]}
Writes <out>_occ.npy, <out>_hull.obj (root-relative Roblox coords), <out>_iou.txt, <out>_overlay_*.png
"""
import json, math, sys
import numpy as np
import cv2


def classify(img):
    b, g, r = [img[..., i].astype(int) for i in range(3)]
    green = (g > r + 45) & (g > b + 45)
    blue = (b > r + 60) & (b > g + 30)
    hair = ~green & ~blue
    k = np.ones((3, 3), np.uint8)
    hair = cv2.morphologyEx(hair.astype(np.uint8), cv2.MORPH_OPEN, k).astype(bool)
    return hair, blue


def look_at(pos, target):
    pos, target = np.asarray(pos, float), np.asarray(target, float)
    z = -(target - pos); z /= np.linalg.norm(z)           # camera looks along -z
    up = np.array([0.0, 1.0, 0.0])
    x = np.cross(up, z); x /= np.linalg.norm(x)
    y = np.cross(z, x)
    return x, y, z


def project(P, cam, target, fov, W, H):
    x, y, z = look_at(cam, target)
    d = P - np.asarray(cam, float)
    xc, yc, zc = d @ x, d @ y, d @ (-z)
    t = math.tan(math.radians(fov) / 2)
    ndc_x = xc / (zc * t * (W / H))
    ndc_y = yc / (zc * t)
    px = (ndc_x + 1) / 2 * W
    py = (1 - ndc_y) / 2 * H
    return px, py, zc


def inside_head(P, head):
    c, h, p = np.asarray(head["center"]), np.asarray(head["half"]), head.get("power", 3)
    q = np.abs((P - c) / h)
    return (q[:, 0] ** p + q[:, 1] ** p + q[:, 2] ** p) <= 1.0


def boundary_obj(occ, origin, vox, path, root):
    """Quads between occupied and empty voxels (closed, watertight) -> OBJ, root-relative coords."""
    pad = np.pad(occ, 1)
    index, vlist, faces = {}, [], []
    def vid(c):
        if c not in index:
            index[c] = len(vlist) + 1
            vlist.append(origin + (np.array(c) - 1) * vox - root)
        return index[c]
    for axis in range(3):
        n = pad.shape[axis]
        a = pad.take(range(0, n - 1), axis=axis)
        b = pad.take(range(1, n), axis=axis)
        u, v = [ax for ax in range(3) if ax != axis]
        cross = 1 if (axis, u, v) in ((0, 1, 2), (2, 0, 1)) else -1     # sign of u x v along axis
        for arr, outward in ((np.argwhere(a & ~b), 1), (np.argwhere(~a & b), -1)):
            for idx in arr:
                base = list(idx)
                base[axis] = idx[axis] + 1
                quad = []
                for du, dv in ((0, 0), (1, 0), (1, 1), (0, 1)):
                    q = list(base); q[u] += du; q[v] += dv
                    quad.append(vid(tuple(q)))
                faces.append(quad if cross * outward > 0 else quad[::-1])
    with open(path, "w") as fh:
        for p in vlist:
            fh.write(f"v {p[0]:.4f} {p[1]:.4f} {p[2]:.4f}\n")
        for f in faces:
            fh.write("f " + " ".join(map(str, f)) + "\n")
    return len(vlist), len(faces)


def main(cfg_path, out):
    cfg = json.load(open(cfg_path))
    fov, target, root = cfg["fov"], np.array(cfg["target"]), np.array(cfg["root"])
    (x0, y0, z0), (x1, y1, z1) = cfg["bounds"]
    vox = cfg["voxel"]
    xs, ys, zs = np.arange(x0, x1, vox), np.arange(y0, y1, vox), np.arange(z0, z1, vox)
    G = np.stack(np.meshgrid(xs, ys, zs, indexing="ij"), -1).reshape(-1, 3) + vox / 2
    keep = ~inside_head(G, cfg["head"])
    hc = np.asarray(cfg["head"]["center"])
    views = []
    for v in cfg["views"]:
        img = cv2.imread(v["img"])
        H, W = img.shape[:2]
        hair, blue = classify(img)
        px, py, zc = project(G, v["cam"], target, fov, W, H)
        ix, iy = np.round(px).astype(int), np.round(py).astype(int)
        ok = (ix >= 0) & (ix < W) & (iy >= 0) & (iy < H)
        h = np.zeros(len(G), bool); b = np.zeros(len(G), bool)
        h[ok] = hair[iy[ok], ix[ok]]
        b[ok] = blue[iy[ok], ix[ok]]
        _, _, zh = project(hc[None, :], v["cam"], target, fov, W, H)
        in_front = zc < zh[0]
        keep &= h | (b & ~in_front)          # face pixel: only voxels behind the head survive
        views.append((v, img, hair, W, H))
    occ = keep.reshape(len(xs), len(ys), len(zs))
    # keep the largest connected component (drop floating specks)
    from scipy import ndimage
    lab, n = ndimage.label(occ)
    if n > 1:
        sizes = ndimage.sum(occ, lab, range(1, n + 1))
        occ = lab == (1 + int(np.argmax(sizes)))
    np.save(out + "_occ.npy", occ)
    origin = np.array([x0, y0, z0])
    nv, nf = boundary_obj(occ, origin, vox, out + "_hull.obj", root)
    # verification: reproject the hull into each view, IoU against the captured hair mask
    P = G[occ.reshape(-1)]
    lines = []
    for v, img, hair, W, H in views:
        px, py, _ = project(P, v["cam"], target, fov, W, H)
        m = np.zeros((H, W), np.uint8)
        ix, iy = np.clip(np.round(px).astype(int), 0, W - 1), np.clip(np.round(py).astype(int), 0, H - 1)
        m[iy, ix] = 1
        m = cv2.dilate(m, np.ones((3, 3), np.uint8))
        inter = (m.astype(bool) & hair).sum(); uni = (m.astype(bool) | hair).sum()
        name = v["img"].split("-")[-1]
        lines.append(f"{v.get('name', name)} IoU={inter / max(1, uni):.3f}")
        ov = img.copy()
        ov[m.astype(bool) & ~hair] = (0, 0, 255)
        ov[~m.astype(bool) & hair] = (255, 0, 255)
        cv2.imwrite(out + f"_overlay_{v.get('name', 'v')}.png", ov)
    open(out + "_iou.txt", "w").write("\n".join(lines))
    print(f"voxels kept {occ.sum()} of {occ.size}; hull verts {nv} faces {nf}")
    print("\n".join(lines))


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2])

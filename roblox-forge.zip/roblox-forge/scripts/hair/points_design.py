"""Control-point hair design: each lock is 4-5 control points (az, el, off) where off = height above the classic
head surface (studs). The build uses exactly these points (Catmull-Rom through them), so the blueprint IS the shape.

python chars/points_design.py from-resolved <locks_resolved.json> <out_design.json>   # seed from an existing build
"""
import json, math, sys
import numpy as np

HC = np.array([0.0, 1.5, 0.0])


def head_r(d, r=0.6, hh=0.6, v=5.0):
    lo, hi = 0.3, 1.0
    for _ in range(25):
        m = (lo + hi) / 2; q = d * m
        lo, hi = (m, hi) if (math.hypot(q[0], q[2]) / r) ** v + (abs(q[1]) / hh) ** v <= 1 else (lo, m)
    return lo


def to_aeo(p):
    r = np.array(p) - HC; n = np.linalg.norm(r); d = r / n
    return [round(math.degrees(math.atan2(d[0], -d[2])), 1), round(math.degrees(math.asin(max(-1, min(1, d[1])))), 1),
            round(float(n - head_r(d)), 3)]


if __name__ == "__main__" and sys.argv[1] == "from-resolved":
    R = json.load(open(sys.argv[2]))
    old = json.load(open("chars/gojo_hair_design_d3.json"))
    design = {"schema": "forge-hair-points-1", "clumps": old["clumps"],
              "notes": "Each lock: pts = control points [az, el, off]; az 0 = front, + = character right; el 0 = head centre "
                       "(eyes ~-5, brow ~+5, top 90); off = studs above the head surface. w = half width.",
              "locks": [{"id": i + 1, "clump": L["clump"], "w": round(L["w"], 3), "pts": [to_aeo(p) for p in L["pts"]]}
                        for i, L in enumerate(R)]}
    json.dump(design, open(sys.argv[3], "w"), indent=1)
    print("locks", len(design["locks"]))

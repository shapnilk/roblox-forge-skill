"""Helpers for models measured from captures: classic Roblox head, carved-hull import, hull smoothing,
hair gradient bake (height ramp x toon band x AO x strand streaks)."""
import math
import bpy
from mathutils import Vector
from forgelib import HEAD_C, rb2bl, hexcol, lin, new_object, recalc_outside, flat_material, nodes_of


def classic_head(face_png, skin_hex, r=0.6, hh=0.6, vpow=5.0, seg=48, rings=32, center=HEAD_C, name="HeadShell"):
    """Roblox classic head: round in plan, straight sides with rounded top/bottom (superellipse
    profile, vpow). Planar front UVs over +-r for the face; the back half samples the edge column."""
    verts, faces, uvs, grid = [], [], [], []
    e = 2.0 / vpow
    for i in range(rings + 1):
        th = -math.pi / 2 + math.pi * i / rings
        s, c = math.sin(th), math.cos(th)
        y = hh * math.copysign(abs(s) ** e, s)
        rf = abs(c) ** e
        row = []
        for j in range(seg):
            ph = 2 * math.pi * j / seg
            row.append(len(verts))
            verts.append((center[0] + r * rf * math.sin(ph), center[1] + y, center[2] - r * rf * math.cos(ph)))
        grid.append(row)
    for i in range(rings):
        for j in range(seg):
            faces.append((grid[i][j], grid[i][(j + 1) % seg], grid[i + 1][(j + 1) % seg], grid[i + 1][j]))
    for f in faces:
        for vi in f:
            x, y, z = verts[vi]
            if z - center[2] > 0.0:
                uvs.append((0.01 if x > center[0] else 0.99, 0.03))
            else:
                uvs.append((0.5 - (x - center[0]) / (2 * r) * 0.98, 0.5 + (y - center[1]) / (2 * hh) * 0.98))
    ob = new_object(name, verts, faces, uvs)
    recalc_outside(ob)
    ob.data.materials.append(flat_material(name + "_M", skin_hex, face_png))
    return ob


def obj_to_object(path, name):
    """OBJ written in Roblox root-relative coords (lib/carve.py) -> Blender object (rb2bl)."""
    vs, fs = [], []
    with open(path) as fh:
        for line in fh:
            if line.startswith("v "):
                vs.append(tuple(float(t) for t in line.split()[1:4]))
            elif line.startswith("f "):
                fs.append(tuple(int(t.split("/")[0]) - 1 for t in line.split()[1:]))
    return new_object(name, vs, fs, smooth=True)


def smooth_hull(ob, voxel=0.012, smooth_iter=6, smooth_factor=0.6, tris=9000):
    """Voxel-carved staircase -> clean organic surface: remesh, smooth, decimate."""
    bpy.ops.object.select_all(action="DESELECT")
    ob.select_set(True)
    bpy.context.view_layer.objects.active = ob
    m = ob.modifiers.new("Remesh", "REMESH")
    m.mode = "VOXEL"
    m.voxel_size = voxel
    bpy.ops.object.modifier_apply(modifier=m.name)
    m = ob.modifiers.new("Smooth", "SMOOTH")
    m.factor, m.iterations = smooth_factor, smooth_iter
    bpy.ops.object.modifier_apply(modifier=m.name)
    ob.data.calc_loop_triangles()
    n = len(ob.data.loop_triangles)
    if n > tris:
        m = ob.modifiers.new("Decimate", "DECIMATE")
        m.ratio = tris / n
        bpy.ops.object.modifier_apply(modifier=m.name)
    for p in ob.data.polygons:
        p.use_smooth = True
    recalc_outside(ob)
    return ob


def bake_hair(ob, out_png, stops, light=(0.35, 1.0, -0.55), band=0.10, shade_mult=0.80, ao_mult=0.70, ao_cut=0.55,
              ao_dist=0.08, lines=None, size=1024, head_center=HEAD_C):
    """Bake: height colour ramp (stops = [(robloxY, hex), ...]) x toon band x AO x strand lines.
    lines = (count, width 0..1, multiplier): meridian streaks around the head centre (strands that
    fall from the crown), wobbled with noise."""
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.samples = 16
    scene.cycles.device = "CPU"
    bpy.ops.object.select_all(action="DESELECT")
    ob.select_set(True)
    bpy.context.view_layer.objects.active = ob
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="SELECT")
    bpy.ops.uv.smart_project(angle_limit=math.radians(66), island_margin=0.003)
    bpy.ops.object.mode_set(mode="OBJECT")
    img = bpy.data.images.new(ob.name + "_bake", size, size, alpha=False)
    mat = bpy.data.materials.new(ob.name + "_bakeM")
    nodes, links = nodes_of(mat)
    for n in list(nodes):
        nodes.remove(n)
    out = nodes.new("ShaderNodeOutputMaterial")
    emit = nodes.new("ShaderNodeEmission")
    links.new(emit.outputs[0], out.inputs[0])
    geo = nodes.new("ShaderNodeNewGeometry")
    sep = nodes.new("ShaderNodeSeparateXYZ")
    links.new(geo.outputs["Position"], sep.inputs[0])
    ys = [s[0] for s in stops]
    lo, hi = min(ys), max(ys)
    mr = nodes.new("ShaderNodeMapRange")
    mr.inputs["From Min"].default_value, mr.inputs["From Max"].default_value = lo, hi
    links.new(sep.outputs["Z"], mr.inputs["Value"])          # Blender Z = Roblox Y
    ramp = nodes.new("ShaderNodeValToRGB")
    ramp.color_ramp.interpolation = "LINEAR"
    els = ramp.color_ramp.elements
    while len(els) < len(stops):
        els.new(0.5)
    for el, (y, h) in zip(els, sorted(stops)):
        el.position = (y - lo) / (hi - lo)
        el.color = lin(hexcol(h))
    links.new(mr.outputs["Result"], ramp.inputs["Fac"])
    dot = nodes.new("ShaderNodeVectorMath")
    dot.operation = "DOT_PRODUCT"
    dot.inputs[1].default_value = rb2bl(Vector(light).normalized())
    links.new(geo.outputs["Normal"], dot.inputs[0])
    gt = nodes.new("ShaderNodeMath")
    gt.operation = "GREATER_THAN"
    gt.inputs[1].default_value = band
    links.new(dot.outputs["Value"], gt.inputs[0])
    tb = nodes.new("ShaderNodeMapRange")
    tb.inputs["To Min"].default_value, tb.inputs["To Max"].default_value = shade_mult, 1.0
    links.new(gt.outputs[0], tb.inputs["Value"])
    ao = nodes.new("ShaderNodeAmbientOcclusion")
    ao.inputs["Distance"].default_value = ao_dist
    ag = nodes.new("ShaderNodeMath")
    ag.operation = "GREATER_THAN"
    ag.inputs[1].default_value = ao_cut
    links.new(ao.outputs["AO"], ag.inputs[0])
    am = nodes.new("ShaderNodeMapRange")
    am.inputs["To Min"].default_value, am.inputs["To Max"].default_value = ao_mult, 1.0
    links.new(ag.outputs[0], am.inputs["Value"])
    mul = nodes.new("ShaderNodeMath")
    mul.operation = "MULTIPLY"
    links.new(tb.outputs["Result"], mul.inputs[0])
    links.new(am.outputs["Result"], mul.inputs[1])
    factor = mul.outputs[0]
    if lines:
        count, width, lmul = lines
        sub = nodes.new("ShaderNodeVectorMath")
        sub.operation = "SUBTRACT"
        sub.inputs[1].default_value = rb2bl(head_center)
        links.new(geo.outputs["Position"], sub.inputs[0])
        sp = nodes.new("ShaderNodeSeparateXYZ")
        links.new(sub.outputs[0], sp.inputs[0])
        at = nodes.new("ShaderNodeMath")
        at.operation = "ARCTAN2"
        links.new(sp.outputs["X"], at.inputs[0])
        links.new(sp.outputs["Y"], at.inputs[1])
        noise = nodes.new("ShaderNodeTexNoise")
        noise.inputs["Scale"].default_value = 3.0
        links.new(geo.outputs["Position"], noise.inputs["Vector"])
        wob = nodes.new("ShaderNodeMath")
        wob.operation = "MULTIPLY_ADD"
        wob.inputs[1].default_value = 0.35
        links.new(noise.outputs["Fac"], wob.inputs[0])
        links.new(at.outputs[0], wob.inputs[2])
        sc = nodes.new("ShaderNodeMath")
        sc.operation = "MULTIPLY"
        sc.inputs[1].default_value = count
        links.new(wob.outputs[0], sc.inputs[0])
        sn = nodes.new("ShaderNodeMath")
        sn.operation = "SINE"
        links.new(sc.outputs[0], sn.inputs[0])
        lg = nodes.new("ShaderNodeMath")
        lg.operation = "GREATER_THAN"
        lg.inputs[1].default_value = 1 - width
        links.new(sn.outputs[0], lg.inputs[0])
        lm = nodes.new("ShaderNodeMapRange")
        lm.inputs["To Min"].default_value, lm.inputs["To Max"].default_value = 1.0, lmul
        links.new(lg.outputs[0], lm.inputs["Value"])
        mul2 = nodes.new("ShaderNodeMath")
        mul2.operation = "MULTIPLY"
        links.new(factor, mul2.inputs[0])
        links.new(lm.outputs["Result"], mul2.inputs[1])
        factor = mul2.outputs[0]
    cm = nodes.new("ShaderNodeVectorMath")
    cm.operation = "SCALE"
    links.new(ramp.outputs["Color"], cm.inputs[0])
    links.new(factor, cm.inputs["Scale"])
    links.new(cm.outputs[0], emit.inputs["Color"])
    tex = nodes.new("ShaderNodeTexImage")
    tex.image = img
    nodes.active = tex
    ob.data.materials.clear()
    ob.data.materials.append(mat)
    scene.cycles.bake_type = "EMIT"
    scene.render.bake.margin = 6
    bpy.ops.object.bake(type="EMIT")
    img.filepath_raw = out_png
    img.file_format = "PNG"
    img.save()
    ob.data.materials.clear()
    ob.data.materials.append(flat_material(ob.name + "_M", stops[-1][1], out_png))
    return out_png


def head_cap(name="Cap", scale=1.025, front=0.22, side=-0.05, back=-0.32, r=0.6, hh=0.6, vpow=5.0, center=HEAD_C):
    """Hair base that hugs the classic head (slightly larger), cut at a hairline that is high at the
    front, at the ears on the sides and low at the nape."""
    import bmesh
    ob = classic_head(None, "#FFFFFF", r=r * scale, hh=hh * scale, vpow=vpow, center=center, name=name)
    bm = bmesh.new()
    bm.from_mesh(ob.data)
    kill = []
    for v in bm.verts:
        x, y, z = -v.co.x - (-center[0]), v.co.z - center[1], v.co.y - center[2]    # Blender -> Roblox local
        c = -z / max(1e-6, math.hypot(x, z))          # cos(azimuth), front = +1
        f, b = max(0.0, c) ** 2, max(0.0, -c) ** 2
        if y < side + (front - side) * f + (back - side) * b:
            kill.append(v)
    bmesh.ops.delete(bm, geom=kill, context="VERTS")
    bm.to_mesh(ob.data)
    bm.free()
    ob.data.materials.clear()
    return ob


def bake_hair_soft(ob, out_png, stops, tip_hex, tip_strength=0.75, grid=10, light=(0.35, 1.0, -0.55),
                   diffuse=(0.70, 1.0), ao=(0.55, 1.0), ao_dist=0.10, size=1024, hi_strength=0.10):
    """Smooth-shaded strand bake (Toolbox look): height ramp, each strand tinted toward its own tip
    (tile UV 'UVMap' gives root->tip), soft diffuse, soft AO in the crevices, faint highlight near
    the root. Writes into a new 'BakeUV' layout, which becomes the only UV map."""
    scene = bpy.context.scene
    scene.render.engine = "CYCLES"
    scene.cycles.samples = 24
    scene.cycles.device = "CPU"
    me = ob.data
    tile_uv = me.uv_layers.get("UVMap")
    bake_uv = me.uv_layers.new(name="BakeUV")
    me.uv_layers.active = bake_uv
    bpy.ops.object.select_all(action="DESELECT")
    ob.select_set(True)
    bpy.context.view_layer.objects.active = ob
    bpy.ops.object.mode_set(mode="EDIT")
    bpy.ops.mesh.select_all(action="SELECT")
    bpy.ops.uv.smart_project(angle_limit=math.radians(66), island_margin=0.003)
    bpy.ops.object.mode_set(mode="OBJECT")
    img = bpy.data.images.new(ob.name + "_soft", size, size, alpha=False)
    mat = bpy.data.materials.new(ob.name + "_softM")
    nodes, links = nodes_of(mat)
    for n in list(nodes):
        nodes.remove(n)
    out = nodes.new("ShaderNodeOutputMaterial")
    emit = nodes.new("ShaderNodeEmission")
    links.new(emit.outputs[0], out.inputs[0])
    geo = nodes.new("ShaderNodeNewGeometry")
    # height ramp
    sep = nodes.new("ShaderNodeSeparateXYZ"); links.new(geo.outputs["Position"], sep.inputs[0])
    ys = [s[0] for s in stops]; lo, hi = min(ys), max(ys)
    mr = nodes.new("ShaderNodeMapRange")
    mr.inputs["From Min"].default_value, mr.inputs["From Max"].default_value = lo, hi
    links.new(sep.outputs["Z"], mr.inputs["Value"])
    ramp = nodes.new("ShaderNodeValToRGB"); ramp.color_ramp.interpolation = "LINEAR"
    els = ramp.color_ramp.elements
    while len(els) < len(stops):
        els.new(0.5)
    for el, (y, h) in zip(els, sorted(stops)):
        el.position = (y - lo) / (hi - lo); el.color = lin(hexcol(h))
    links.new(mr.outputs["Result"], ramp.inputs["Fac"])
    col = ramp.outputs["Color"]
    # per-strand root->tip parameter from the tile UVs
    if tile_uv is not None:
        uvn = nodes.new("ShaderNodeUVMap"); uvn.uv_map = "UVMap"
        su = nodes.new("ShaderNodeSeparateXYZ"); links.new(uvn.outputs["UV"], su.inputs[0])
        inv = nodes.new("ShaderNodeMath"); inv.operation = "SUBTRACT"; inv.inputs[0].default_value = 1.0
        links.new(su.outputs["Y"], inv.inputs[1])
        mul = nodes.new("ShaderNodeMath"); mul.operation = "MULTIPLY"; mul.inputs[1].default_value = grid
        links.new(inv.outputs[0], mul.inputs[0])
        fr = nodes.new("ShaderNodeMath"); fr.operation = "FRACT"; links.new(mul.outputs[0], fr.inputs[0])
        vp = nodes.new("ShaderNodeMapRange")
        vp.inputs["From Min"].default_value, vp.inputs["From Max"].default_value = 0.05, 0.95
        links.new(fr.outputs[0], vp.inputs["Value"])
        tipm = nodes.new("ShaderNodeMapRange")          # tint ramps in over the outer 60% of each strand
        tipm.inputs["From Min"].default_value, tipm.inputs["From Max"].default_value = 0.40, 1.0
        tipm.inputs["To Max"].default_value = tip_strength
        tipm.interpolation_type = "SMOOTHSTEP"
        links.new(vp.outputs["Result"], tipm.inputs["Value"])
        mix = nodes.new("ShaderNodeMix"); mix.data_type = "RGBA"
        links.new(tipm.outputs["Result"], mix.inputs["Factor"])
        links.new(col, mix.inputs[6]); mix.inputs[7].default_value = lin(hexcol(tip_hex))
        col = mix.outputs[2]
        # faint highlight band near the root (anime sheen)
        hb = nodes.new("ShaderNodeMapRange"); hb.interpolation_type = "SMOOTHSTEP"
        hb.inputs["From Min"].default_value, hb.inputs["From Max"].default_value = 0.10, 0.28
        links.new(vp.outputs["Result"], hb.inputs["Value"])
        hb2 = nodes.new("ShaderNodeMapRange"); hb2.interpolation_type = "SMOOTHSTEP"
        hb2.inputs["From Min"].default_value, hb2.inputs["From Max"].default_value = 0.42, 0.28
        links.new(vp.outputs["Result"], hb2.inputs["Value"])
        hbm = nodes.new("ShaderNodeMath"); hbm.operation = "MINIMUM"
        links.new(hb.outputs["Result"], hbm.inputs[0]); links.new(hb2.outputs["Result"], hbm.inputs[1])
        hbs = nodes.new("ShaderNodeMath"); hbs.operation = "MULTIPLY"; hbs.inputs[1].default_value = hi_strength
        links.new(hbm.outputs[0], hbs.inputs[0])
        add = nodes.new("ShaderNodeMix"); add.data_type = "RGBA"; add.blend_type = "ADD"
        links.new(hbs.outputs[0], add.inputs["Factor"]); links.new(col, add.inputs[6])
        add.inputs[7].default_value = (1, 1, 1, 1)
        col = add.outputs[2]
    # soft diffuse
    dot = nodes.new("ShaderNodeVectorMath"); dot.operation = "DOT_PRODUCT"
    dot.inputs[1].default_value = rb2bl(Vector(light).normalized())
    links.new(geo.outputs["Normal"], dot.inputs[0])
    dm = nodes.new("ShaderNodeMapRange")
    dm.inputs["From Min"].default_value, dm.inputs["From Max"].default_value = -0.6, 1.0
    dm.inputs["To Min"].default_value, dm.inputs["To Max"].default_value = diffuse
    dm.interpolation_type = "SMOOTHSTEP"
    links.new(dot.outputs["Value"], dm.inputs["Value"])
    aon = nodes.new("ShaderNodeAmbientOcclusion"); aon.inputs["Distance"].default_value = ao_dist
    am = nodes.new("ShaderNodeMapRange")
    am.inputs["To Min"].default_value, am.inputs["To Max"].default_value = ao
    links.new(aon.outputs["AO"], am.inputs["Value"])
    f = nodes.new("ShaderNodeMath"); f.operation = "MULTIPLY"
    links.new(dm.outputs["Result"], f.inputs[0]); links.new(am.outputs["Result"], f.inputs[1])
    sc = nodes.new("ShaderNodeVectorMath"); sc.operation = "SCALE"
    links.new(col, sc.inputs[0]); links.new(f.outputs[0], sc.inputs["Scale"])
    links.new(sc.outputs[0], emit.inputs["Color"])
    tex = nodes.new("ShaderNodeTexImage"); tex.image = img
    nodes.active = tex
    me.materials.clear(); me.materials.append(mat)
    scene.cycles.bake_type = "EMIT"
    scene.render.bake.margin = 6
    bpy.ops.object.bake(type="EMIT")
    img.filepath_raw = out_png; img.file_format = "PNG"; img.save()
    if tile_uv is not None:
        me.uv_layers.remove(me.uv_layers["UVMap"])
    me.uv_layers.active = me.uv_layers["BakeUV"]
    me.uv_layers["BakeUV"].active_render = True
    me.materials.clear(); me.materials.append(flat_material(ob.name + "_M", stops[-1][1], out_png))
    return out_png


def split_by_depth(ob, names=("HairFront", "HairBack"), max_tris=19500):
    """Split a mesh into front/back halves (Roblox z < 0 = front) when it exceeds the 20k-triangle
    MeshPart cap. Both halves keep the material and UVs, so they share one texture."""
    import bmesh
    ob.data.calc_loop_triangles()
    if len(ob.data.loop_triangles) <= max_tris:
        return [ob]
    bpy.ops.object.select_all(action="DESELECT")
    ob.select_set(True)
    bpy.context.view_layer.objects.active = ob
    bpy.ops.object.mode_set(mode="EDIT")
    bm = bmesh.from_edit_mesh(ob.data)
    for f in bm.faces:
        f.select = f.calc_center_median().y < 0.0      # Blender -Y = Roblox front
    bmesh.update_edit_mesh(ob.data)
    bpy.ops.mesh.separate(type="SELECTED")
    bpy.ops.object.mode_set(mode="OBJECT")
    parts = [o for o in bpy.context.selected_objects]
    front = [o for o in parts if o != ob][0]
    front.name, ob.name = names
    front.data.name, ob.data.name = names
    return [front, ob]

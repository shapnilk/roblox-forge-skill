"""Hair design blueprint: front / right-side / back / top orthographic views of the designed locks
(locks_resolved.json from hair_v13.py FORGE_LAYOUT=design) over the measured silhouette (v7 outline) and the
classic head, coloured by clump and numbered. For review/markup on the Claude Design board.

python lib/hair_blueprint_png.py <locks_resolved.json> <design.json> <outline_meshes.json> <out.png>
"""
import json, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont

S = 520                      # px per view
SPAN = 2.6                   # studs across a view
CY = 1.65                    # view centre height


def proj(view, p):
    x, y, z = p
    if view == "front":
        u, v = -x, y         # seen from the front: character's right on the viewer's left
    elif view == "side":
        u, v = -z, y         # seen from the character's right: front on the right
    elif view == "back":
        u, v = x, y
    else:
        u, v = -x, -z        # from above: front at the bottom
        v = v + CY
    return S / 2 + u / SPAN * S, S / 2 - (v - CY) / SPAN * S


def outline_mask(path, view):
    m = json.load(open(path))["meshes"][0]
    V = np.array(m["vertices"]); T = V[np.array(m["triangles"])]
    im = Image.new("L", (S, S), 0); d = ImageDraw.Draw(im)
    for t in T:
        d.polygon([proj(view, q) for q in t], fill=255)
    return im


def head(d, view):
    if view == "top":
        c = proj("top", (0, 0, 0)); r = 0.6 / SPAN * S
        d.ellipse([c[0] - r, c[1] - r, c[0] + r, c[1] + r], outline=(150, 120, 95), width=2, fill=(233, 201, 166))
        return
    a = proj(view, (0.6, 2.1, 0.6)); b = proj(view, (-0.6, 0.9, -0.6))
    box = [min(a[0], b[0]), min(a[1], b[1]), max(a[0], b[0]), max(a[1], b[1])]
    d.rounded_rectangle(box, radius=30, outline=(150, 120, 95), width=2, fill=(233, 201, 166))
    if view == "front":
        cx = (box[0] + box[2]) / 2; ey = proj("front", (0, 1.45, 0))[1]
        for dx in (-0.2, 0.2):
            ex = cx + dx / SPAN * S
            d.ellipse([ex - 7, ey - 4, ex + 7, ey + 4], fill=(70, 120, 160))


def hexrgb(h):
    h = h.lstrip("#"); return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4))


def render(locks, design, outline, out):
    views = ["front", "side", "back", "top"]
    titles = {"front": "FRONT", "side": "RIGHT SIDE (front on the right)", "back": "BACK", "top": "TOP (front at the bottom)"}
    colors = {k: hexrgb(v["color"]) for k, v in design["clumps"].items()}
    font = ImageFont.load_default()
    sheet = Image.new("RGB", (S * 4, S + 150), (244, 242, 238))
    for i, view in enumerate(views):
        tile = Image.new("RGB", (S, S), (244, 242, 238))
        m = outline_mask(outline, view)
        tile.paste(Image.new("RGB", (S, S), (221, 214, 236)), (0, 0), m.point(lambda a: int(a * 0.75)))
        d = ImageDraw.Draw(tile)
        # draw back-to-front by depth so near locks sit on top; the head goes between far and near locks
        def depth(L):
            p = np.mean(L["pts"], axis=0)
            return {"front": p[2], "side": p[0], "back": -p[2], "top": -p[1]}[view]
        head_drawn = False
        for L in sorted(locks, key=depth, reverse=True):
            if not head_drawn and depth(L) < 0.15:
                head(d, view); head_drawn = True
            col = colors.get(L["clump"], (60, 60, 60))
            pts = [proj(view, q) for q in L["pts"]]
            w = max(2, int(L["w"] / SPAN * S * 0.9))
            d.line(pts, fill=col, width=w, joint="curve")
            d.line(pts, fill=(30, 30, 30), width=1)
            tx, ty = pts[-1]
            d.ellipse([tx - 3, ty - 3, tx + 3, ty + 3], fill=(20, 20, 20))
            for (cx, cy) in pts[:-1]:
                d.ellipse([cx - 2, cy - 2, cx + 2, cy + 2], outline=(20, 20, 20))
        if not head_drawn:
            head(d, view)
        for k, L in enumerate(locks):
            tx, ty = proj(view, L["pts"][-1])
            d.text((tx + 4, ty - 4), str(k + 1), fill=(10, 10, 10), font=font)
        d.text((8, 8), titles[view], fill=(20, 20, 20), font=font)
        sheet.paste(tile, (i * S, 0))
    d = ImageDraw.Draw(sheet)
    x, y = 12, S + 12
    for k, v in design["clumps"].items():
        n = [i + 1 for i, L in enumerate(locks) if L["clump"] == k]
        d.rectangle([x, y, x + 16, y + 16], fill=colors[k])
        d.text((x + 22, y + 2), f"{k}: {v['desc']}  (locks {n[0]}-{n[-1]})" if n else k, fill=(20, 20, 20), font=font)
        y += 22
        if y > S + 130:
            y, x = S + 12, x + S * 2
    d.text((S * 2 + 12, S + 120), "Lilac = measured outline target. Dot = lock tip. Numbers = lock ids for comments.", fill=(60, 60, 60), font=font)
    sheet.save(out)


if __name__ == "__main__":
    render(json.load(open(sys.argv[1])), json.load(open(sys.argv[2])), sys.argv[3], sys.argv[4])

# roblox-forge: Classic 585x559 Shirt/Pants template regions; imported by validate.py (orientation verified in Studio).
"""Classic Roblox Shirt/Pants template layout (585x559) and a labelled debug template.

Region names: (part, face). part in Torso/RightArm/LeftArm (shirt) or Torso/RightLeg/LeftLeg (pants,
legs share the arm slots). face in F,B,L,R,U,D. Boxes are (x, y, w, h) in template pixels.
Orientation per face is verified by the debug render in Studio (see verify notes in README).
"""
from PIL import Image, ImageDraw, ImageFont

W, H = 585, 559

TORSO = {"U": (231, 8, 128, 64), "R": (165, 74, 64, 128), "F": (231, 74, 128, 128),
         "L": (361, 74, 64, 128), "B": (427, 74, 128, 128), "D": (231, 204, 128, 64)}
RIGHT_LIMB = {"U": (217, 289, 64, 64), "L": (19, 355, 64, 128), "B": (85, 355, 64, 128),
              "R": (151, 355, 64, 128), "F": (217, 355, 64, 128), "D": (217, 485, 64, 64)}
LEFT_LIMB = {"U": (308, 289, 64, 64), "F": (308, 355, 64, 128), "L": (374, 355, 64, 128),
             "B": (440, 355, 64, 128), "R": (506, 355, 64, 128), "D": (308, 485, 64, 64)}


def regions(kind="shirt"):
    a, b = ("RightArm", "LeftArm") if kind == "shirt" else ("RightLeg", "LeftLeg")
    out = {("Torso", f): r for f, r in TORSO.items()}
    out.update({(a, f): r for f, r in RIGHT_LIMB.items()})
    out.update({(b, f): r for f, r in LEFT_LIMB.items()})
    return out


def debug(kind, path):
    im = Image.new("RGBA", (W, H), (0, 0, 0, 0))
    d = ImageDraw.Draw(im)
    try:
        font = ImageFont.truetype("arialbd.ttf", 14)
    except OSError:
        font = ImageFont.load_default()
    hues = {"F": (220, 60, 60), "B": (60, 90, 220), "L": (60, 180, 80), "R": (230, 180, 40),
            "U": (200, 80, 200), "D": (60, 200, 200)}
    for (part, face), (x, y, w, h) in regions(kind).items():
        d.rectangle([x, y, x + w - 1, y + h - 1], fill=hues[face] + (255,), outline=(0, 0, 0, 255), width=2)
        # arrow at the top edge marks image-up
        d.polygon([(x + w // 2, y + 3), (x + w // 2 - 6, y + 13), (x + w // 2 + 6, y + 13)], fill=(255, 255, 255, 255))
        # left-edge stripe marks image-left
        d.rectangle([x + 2, y + 16, x + 6, y + h - 4], fill=(0, 0, 0, 255))
        label = ("T" if part == "Torso" else part[0] + part[-3]) + face
        d.text((x + 10, y + h // 2 - 8), label, fill=(255, 255, 255, 255), font=font, stroke_width=2, stroke_fill=(0, 0, 0, 255))
    im.save(path)


if __name__ == "__main__":
    import sys
    out = sys.argv[1] if len(sys.argv) > 1 else "."
    debug("shirt", f"{out}/debug_shirt.png")
    debug("pants", f"{out}/debug_pants.png")
    print("ok")

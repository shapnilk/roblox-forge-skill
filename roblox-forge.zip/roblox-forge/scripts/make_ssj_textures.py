# roblox-forge: SSJ secondaries: streak/spark/disc used by the approved SSJ aura. The egg and V-fan heroes here LOST the bake-off (bubble / rain) - kept only as counter-examples. Source C:/Users/shapn/Documents/AnimeCloneEggs/forge/research/tests/ssj.
"""SSJ bake-off textures (our own art, numpy + PIL, no third-party pixels).

Writes ./textures/:
  hero_spline_egg_2x2_{1024,512}.png        spline-drawn spiky egg, Toolbox-analogue structure
  hero_anime_frame_fan_2x2_{1024,512}.png   V-fan of vertical dry-brush streaks (anime ref 4.6)
  disc_1x1_{1024,512}.png                   soft white disc (inner glow)
  streak_1x1_{1024,512}.png                 thin tapered rising streak
  spark_1x1_{1024,512}.png                  hard 4-point spark
  ring_1x1_{1024,512}.png                   spiky ground ring
All white/greyscale on transparent, straight (not premultiplied) alpha, alpha-bled (transparent
texels carry the nearest visible RGB), 8 px clear padding per cell edge at 1024 (4 px at 512, same
UVs). Hero sheets: 2x2 at 1024 = 512 px cells, frame order TL, TR, BL, BR (Roblox OneShot order).

Cell coordinates below are fractions of one cell, x right, y DOWN, (0.5, 0.5) = the emitter.
Run: python make_ssj_textures.py
"""
import os
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage as ndi

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(os.getcwd(), "textures")  # roblox-forge: run from your effect folder
SHEET, PAD, SS = 1024, 8, 4          # sheet px, clear padding per cell edge at 1024, supersample


# ------------------------------------------------------------------ common helpers
def bleed(rgba):
    """Straight-alpha bleed: every alpha-0 texel takes the RGB of the nearest visible texel."""
    clear = rgba[..., 3] <= 0
    if not clear.any() or clear.all():
        return rgba
    iy, ix = ndi.distance_transform_edt(clear, return_distances=False, return_indices=True)
    out = rgba.copy()
    out[..., :3] = rgba[iy, ix, :3]
    return out


def down(rgba, s):
    """Box downsample with premultiplied alpha, returns straight alpha."""
    h, w = rgba.shape[0] // s, rgba.shape[1] // s
    a = rgba[..., 3:4]
    pm = np.concatenate([rgba[..., :3] * a, a], -1).reshape(h, s, w, s, 4).mean((1, 3))
    a = pm[..., 3:4]
    return np.concatenate([np.where(a > 0, pm[..., :3] / np.maximum(a, 1e-6), 0.0), a], -1)


def save(rgba, name):
    """Save the 1024 sheet and a 512 copy (premultiplied box downsample), both bled."""
    os.makedirs(OUT, exist_ok=True)
    for img, size in ((rgba, 1024), (down(rgba, 2), 512)):
        img = img.copy()
        img[..., 3] = np.round(np.clip(img[..., 3], 0, 1) * 255) / 255   # quantise first, then bleed
        img = bleed(img)
        u8 = np.round(np.clip(img, 0, 1) * 255).astype(np.uint8)
        Image.fromarray(u8, "RGBA").save(os.path.join(OUT, f"{name}_{size}.png"), optimize=True)


def pack2x2(cells):
    """cells: 4 arrays (512, 512, 4) whose padding band is already clear."""
    C = SHEET // 2
    sheet = np.zeros((SHEET, SHEET, 4), np.float64)
    for i, c in enumerate(cells):
        r, k = divmod(i, 2)
        sheet[r * C:(r + 1) * C, k * C:(k + 1) * C] = c
    return sheet


def clear_pad(cell, pad=PAD):
    """Assert-free safety: report art that reached the padding band (callers assert on it)."""
    a = cell[..., 3]
    return max(a[:pad].max(), a[-pad:].max(), a[:, :pad].max(), a[:, -pad:].max())


def poly_mask(polys, size, ss=SS):
    """Rasterise polygons given in cell fractions at ss x supersampling -> coverage (size, size)."""
    big = Image.new("L", (size * ss, size * ss), 0)
    d = ImageDraw.Draw(big)
    for p in polys:
        d.polygon([(float(x) * size * ss, float(y) * size * ss) for x, y in p], fill=255)
    a = np.asarray(big, np.float64) / 255.0
    return a.reshape(size, ss, size, ss).mean((1, 3))


def bez(p0, p1, p2, n=14):
    """Quadratic Bezier points p0 -> p2 with control p1 (arrays of shape (2,))."""
    t = np.linspace(0, 1, n)[:, None]
    return (1 - t) ** 2 * p0 + 2 * (1 - t) * t * p1 + t ** 2 * p2


def rgba_from(alpha, tone=None):
    tone = np.ones_like(alpha) if tone is None else tone
    return np.stack([tone, tone, tone, alpha], -1)


# ------------------------------------------------------------------ hero 1: spline egg
def egg_outline(scale, k_wobble, phase, n=720):
    """Closed egg outline in cell fractions (y down): widest below centre, tapering to a peak."""
    th = np.linspace(0, 2 * np.pi, n, endpoint=False)
    s, c = np.sin(th), np.cos(th)
    a = 0.298 * (1 - 0.55 * np.clip(s, 0, 1) ** 1.6)             # half width, tapers at the top
    b = np.where(s > 0, 0.385, 0.322)                            # half height top / bottom
    w = scale * (1 + k_wobble * np.sin(3 * th + phase))          # tiny per-frame breathing
    x = 0.5 + a * c * w
    y = 0.588 - b * s * w
    return np.stack([x, y], 1), th


def spike_poly(P, i, hw_n, L, lean, hook, n_pts):
    """One spline spike on outline P at index i: concave Bezier sides, hooked tip."""
    i0, i1 = (i - hw_n) % n_pts, (i + hw_n) % n_pts
    B1, B2 = P[i0], P[i1]
    Bc = (B1 + B2) / 2
    t = B2 - B1
    nrm = np.array([-t[1], t[0]])                              # outward (outline runs CCW on screen, y down)
    nrm /= np.linalg.norm(nrm) + 1e-9
    d = nrm + np.array([0.0, -1.0]) * lean                     # lean the spike upward (y down)
    d /= np.linalg.norm(d)
    perp = np.array([-d[1], d[0]])
    T = Bc + d * L + perp * hook * L
    C1 = Bc + (T - Bc) * 0.40 + (B1 - Bc) * 0.30               # controls inside the triangle
    C2 = Bc + (T - Bc) * 0.40 + (B2 - Bc) * 0.30               # -> concave, sharp sides
    return np.concatenate([bez(B1, C1, T), bez(T, C2, B2)[1:]])


EGG_ROWS = (  # (row, outline scale, spike count, base half-width idx, length range, alpha)
    ("outer", 1.00, 62, (8, 16), (0.030, 0.075), 1.0),
    ("inner", 0.80, 34, (6, 12), (0.030, 0.070), 0.62),
)
EGG_REROLL, EGG_LEN_JITTER = 0.40, 0.20      # boil: share of spikes redrawn / length noise per frame


def make_spline_egg(seed=7):
    rng = np.random.default_rng(seed)
    C = SHEET // 2
    n_pts = 720
    yy, xx = np.mgrid[0:C, 0:C]
    rows = []
    for name, scale, count, hw_rng, len_rng, alpha in EGG_ROWS:
        # stratified positions (even coverage, no bald patches), one master set per row
        sp = [dict(u=(k + rng.uniform(-0.35, 0.35)) / count, r1=rng.random(), r2=rng.random(),
                   r3=rng.normal()) for k in range(count)]
        rows.append((name, scale, sp, hw_rng, len_rng, alpha))
    cells = []
    for f in range(4):
        layers = []
        for name, scale, spikes, hw_rng, len_rng, alpha in rows:
            P, th = egg_outline(scale, 0.012, f * 1.7)
            if name == "inner":                               # inner row sits low, like the accepted sheet
                P = P + np.array([0.0, 0.035])
            polys = [P]
            for sp in spikes:
                if rng.random() < EGG_REROLL:                 # redraw some spikes each frame
                    sp = dict(sp, r1=rng.random(), r3=rng.normal(), u=sp["u"] + rng.normal(0, 0.004))
                i = int((sp["u"] % 1) * n_pts)
                s = np.sin(th[i])                             # +1 top, -1 bottom
                top, bot = np.clip(s, 0, 1), np.clip(-s, 0, 1)
                L = len_rng[0] + (len_rng[1] - len_rng[0]) * sp["r1"]
                L *= (1 + 1.1 * top ** 2) * (1 - 0.7 * bot) * (1 + EGG_LEN_JITTER * rng.normal())
                hw = int(hw_rng[0] + (hw_rng[1] - hw_rng[0]) * sp["r2"])
                lean = 1.1 * np.clip((s + 0.7) / 1.0, 0, 1)   # sides lean up like flames
                hook = 0.14 * sp["r3"] + 0.05 * rng.normal()
                polys.append(spike_poly(P, i, hw, L, lean, hook, n_pts))
            if name == "outer":                               # tall crown spike at the peak
                itop = int(0.25 * n_pts) + int(rng.integers(-5, 6))
                polys.append(spike_poly(P, itop, 14, 0.085 * (1 + 0.1 * rng.normal()), 0.0,
                                        0.1 * rng.normal(), n_pts))
            layers.append((poly_mask(polys, C), alpha))
        cov = layers[0][0]
        # fill: opaque rim, soft interior (distance to the outside), so the body shows through
        dist = ndi.distance_transform_edt(cov > 0.5)
        fill = 0.52 + 0.70 * np.exp(-dist / 7.0)
        # inner row: a second, softer serrated band (layered flame tongues)
        inner_cov = layers[1][0]
        idist = ndi.distance_transform_edt(inner_cov > 0.5)
        fill = np.maximum(fill, inner_cov * layers[1][1] * (0.55 + 0.45 * np.exp(-idist / 5.0)))
        cy, cx = 0.66 * C, 0.5 * C                            # slightly darker low centre
        fill *= 1 - 0.20 * np.exp(-(((yy - cy) / (0.15 * C)) ** 2 + ((xx - cx) / (0.12 * C)) ** 2))
        cells.append(rgba_from(np.clip(cov * fill, 0, 1)))
    return cells


# ------------------------------------------------------------------ hero 2: anime V-fan
# Cell layout assumed by the recipe: Size 7.5 studs, emitter at HRP + 0.2, body width 2.2 studs
# (the width the 1.9x Toolbox ratio was measured against), body height 5.2 studs.
FAN_SIZE = 7.5
FEET_Y = 0.5 + (3.2 / FAN_SIZE)          # 0.927: feet are 3.2 studs below the emitter
HEAD_Y = 0.5 - (2.0 / FAN_SIZE)          # 0.233: head top 2.0 studs above it
BODY_HALF = 1.1 / FAN_SIZE               # 0.147
# measured anime width profile (refs_measurements2.json 57_width_profile), as half-width in cells
H_KNOTS = np.array([0.0, 0.1, 0.25, 0.5, 0.75, 0.9, 1.0, 1.29])
HW_KNOTS = np.array([0.19, 0.223, 0.283, 0.333, 0.425, 0.36, 0.35, 0.30])


def fan_half_width(y):
    h = (FEET_Y - y) / (FEET_Y - HEAD_Y)
    return np.interp(h, H_KNOTS, HW_KNOTS)


def make_anime_fan(seed=11):
    rng = np.random.default_rng(seed)
    C = SHEET // 2
    ys = np.linspace(0, 1, C)
    yy, xx = np.mgrid[0:C, 0:C] / C
    env = (np.abs(xx - 0.5) <= fan_half_width(yy)) & (yy <= FEET_Y + 0.01) & (yy >= 0.03)
    body = (np.abs(xx - 0.5) <= BODY_HALF) & (yy >= HEAD_Y) & (yy <= FEET_Y)

    def sample_x():
        while True:                                          # body column gets ~1/8 the density
            x = rng.uniform(0.06, 0.94)
            if abs(x - 0.5) <= BODY_HALF and rng.random() > 0.12:
                continue
            return x

    def bottom_y(x):                                         # lowest envelope point at this x
        ok = np.abs(x - 0.5) <= fan_half_width(ys)
        ok &= ys <= FEET_Y
        return ys[ok].max() if ok.any() else None

    def top_y(x):                                            # V: side horns reach higher
        return 0.035 + 0.075 * np.exp(-((x - 0.5) / 0.16) ** 2)

    strokes = []
    while len(strokes) < 120:
        x = sample_x()
        yb = bottom_y(x)
        if yb is None:
            continue
        yb = yb - rng.uniform(0, 0.35) * (yb - top_y(x))
        strokes.append(dict(x=x, yb=yb, frac=rng.uniform(0.45, 1.0), w=rng.uniform(0.006, 0.019),
                            bend=rng.normal(0, 0.012), tone=rng.choice([1.0, 1.0, 1.0, 0.88, 0.78])))
    strokes.sort(key=lambda s: s["tone"])                   # darker strokes underneath

    cells = []
    for f in range(4):
        big_a = Image.new("L", (C * SS, C * SS), 0)
        big_t = Image.new("L", (C * SS, C * SS), 0)
        da, dt = ImageDraw.Draw(big_a), ImageDraw.Draw(big_t)
        for s in strokes:
            if rng.random() < 0.22:                          # re-roll ~1 in 5 strokes per frame
                s = dict(s, frac=rng.uniform(0.45, 1.0), bend=rng.normal(0, 0.012))
            x0 = s["x"] + rng.normal(0, 0.003)
            yb = s["yb"] + rng.normal(0, 0.006)
            yt = yb - (yb - top_y(x0)) * s["frac"] * (1 + 0.08 * rng.normal())
            lean = 0.42 * (x0 - 0.5)                         # V-fan: outer strokes lean outward
            n = 24
            t = np.linspace(0, 1, n)
            yc = yb + (yt - yb) * t
            xc = x0 + lean * (yb - yc) + s["bend"] * np.sin(np.pi * t)
            w = s["w"] * (1 - t) ** 0.85 * (0.55 + 0.45 * np.sin(np.pi / 2 * np.minimum(t * 4, 1)))
            left = np.stack([xc - w / 2, yc], 1)
            right = np.stack([xc + w / 2, yc], 1)[::-1]
            pts = [(float(px) * C * SS, float(py) * C * SS) for px, py in np.concatenate([left, right])]
            da.polygon(pts, fill=255)
            dt.polygon(pts, fill=int(s["tone"] * 255))
        cov = np.asarray(big_a, np.float64).reshape(C, SS, C, SS).mean((1, 3)) / 255
        tone_pm = np.asarray(big_t, np.float64).reshape(C, SS, C, SS).mean((1, 3)) / 255
        tone = np.where(cov > 0, tone_pm / np.maximum(cov, 1e-6), 1.0)
        # dry brush: vertical bristle gaps (1D noise across x, stretched along y), shifted per frame
        nx = rng.random(C // 3 + 2)
        bristle_x = np.interp(np.arange(C) / 3.0, np.arange(len(nx)), nx)
        slow = ndi.zoom(rng.random((6, C // 3 + 2)), (C / 6, 3.0), order=1)[:C, :C]
        bristle = (0.6 * bristle_x[None, :] + 0.4 * slow) > 0.30
        bristle = ndi.uniform_filter(bristle.astype(np.float64), (3, 1))
        streak_a = cov * (0.25 + 0.75 * bristle)
        # airbrushed haze inside the envelope, outside the body column, feathered
        haze = ndi.gaussian_filter((env & ~body).astype(np.float64), 6) * 0.13
        alpha = np.clip(streak_a + haze * (1 - streak_a), 0, 1)
        tone_all = np.where(streak_a > 0.02, tone, 0.80)     # haze tone matches the #BBAD33 median
        cell = rgba_from(alpha, tone_all)
        for band in (slice(0, PAD), slice(C - PAD, C)):     # hard clear of the padding band
            cell[band, :, 3] = 0
            cell[:, band, 3] = 0
        cells.append(cell)
    return cells


# ------------------------------------------------------------------ shared secondaries (1 frame)
def single(fn):
    """fn(xx, yy) on a 1024 grid in [-1, 1] -> alpha; padding forced clear."""
    yy, xx = (np.mgrid[0:SHEET, 0:SHEET] + 0.5) / SHEET * 2 - 1
    a = np.clip(fn(xx, -yy), 0, 1)                         # y up
    p = PAD
    a[:p] = a[-p:] = 0
    a[:, :p] = a[:, -p:] = 0
    return rgba_from(a)


def soft_disc(xx, yy):
    r = np.hypot(xx, yy) / 0.96
    return np.clip(1 - r * r, 0, 1) ** 2.2                 # smooth falloff to 0 at r = 0.96


def streak_tex(xx, yy):
    t = (yy + 0.94) / 1.88                                 # 0 bottom .. 1 top
    inside = (t >= 0) & (t <= 1)
    half_w = 0.075 * np.sin(np.pi * np.clip(t, 0, 1)) ** 0.7 * (1 - 0.55 * np.clip(t, 0, 1))
    core = np.clip(1 - np.abs(xx) / np.maximum(half_w, 1e-4), 0, 1)
    glow = np.exp(-(xx / np.maximum(half_w * 2.6, 1e-4)) ** 2) * 0.35
    return np.where(inside, np.maximum(core ** 0.6, glow), 0) * np.clip(t * 6, 0, 1) * np.clip((1 - t) * 3, 0, 1)


def spark_tex(xx, yy):
    ax, ay = np.abs(xx), np.abs(yy)
    star = (np.sqrt(ax) + np.sqrt(ay)) <= np.sqrt(0.92)     # astroid: concave sides, sharp points
    core = np.exp(-(xx ** 2 + yy ** 2) / 0.02)
    return np.maximum(star.astype(np.float64), core)


def make_spark():
    """Crisp alpha, anti-aliased by 2x supersampling the hard star."""
    yy, xx = (np.mgrid[0:SHEET * 2, 0:SHEET * 2] + 0.5) / (SHEET * 2) * 2 - 1
    a = spark_tex(xx, -yy).reshape(SHEET, 2, SHEET, 2).mean((1, 3))
    a[:PAD] = a[-PAD:] = 0
    a[:, :PAD] = a[:, -PAD:] = 0
    return rgba_from(np.clip(a, 0, 1))


def make_ring(seed=5):
    rng = np.random.default_rng(seed)
    n = 30
    ang = np.sort(rng.uniform(0, 2 * np.pi, n))
    length = rng.uniform(0.08, 0.24, n)
    width = rng.uniform(0.05, 0.11, n)                     # angular half-width (rad)
    yy, xx = (np.mgrid[0:SHEET * 2, 0:SHEET * 2] + 0.5) / (SHEET * 2) * 2 - 1
    r = np.hypot(xx, yy)
    th = np.arctan2(yy, xx)
    outer = np.full_like(r, 0.68)
    for a0, L, w in zip(ang, length, width):
        dth = np.angle(np.exp(1j * (th - a0)))
        outer = np.maximum(outer, 0.68 + L * np.clip(1 - np.abs(dth) / w, 0, 1) ** 1.6)
    band = (r <= outer).astype(np.float64)                 # crisp spiky outer edge
    inner = np.clip((r - 0.40) / 0.22, 0, 1) ** 1.5        # soft dusty inner edge
    a = (band * inner).reshape(SHEET, 2, SHEET, 2).mean((1, 3))
    a[:PAD] = a[-PAD:] = 0
    a[:, :PAD] = a[:, -PAD:] = 0
    return rgba_from(np.clip(a, 0, 1))


def main():
    egg = make_spline_egg()
    fan = make_anime_fan()
    for name, cells in (("hero_spline_egg_2x2", egg), ("hero_anime_frame_fan_2x2", fan)):
        worst = max(clear_pad(c) for c in cells)
        assert worst == 0, f"{name}: art in the padding band ({worst})"
        save(pack2x2(cells), name)
    save(single(soft_disc), "disc_1x1")
    save(single(streak_tex), "streak_1x1")
    save(make_spark(), "spark_1x1")
    save(make_ring(), "ring_1x1")
    print("wrote", sorted(os.listdir(OUT)))


if __name__ == "__main__":
    main()

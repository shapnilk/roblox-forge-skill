# roblox-forge: SSJ2 blue-white arc variants 4x4 (reuses the Haki bolt drawer). Evidence: part of the approved SSJ aura v4 (arcs visible in ~half the live frames).
"""SSJ2 electric arcs, our own art: 16 thin forked bolt variants (4x4, random still frame), white
core + white rim + soft glow (no black core: SSJ electricity is light, used additively and tinted
blue-white). Reuses the Haki bolt drawer. Output: textures/ssj_arc_4x4.png + _512.
Run: python make_ssj_extras.py
"""
import numpy as np
import make_haki_textures as H


def arc_cells(rng):
    cells = []
    for _ in range(16):
        m = H.S * 0.1
        y0, y1 = rng.uniform(H.S * 0.3, H.S * 0.7, 2)
        p = H.bolt(rng, (m, y0), (H.S - m, y1), w=rng.uniform(12, 18), depth=6, rough=0.24, forks=(1, 3))
        c = H.compose(p, (H.S, H.S), glow_gain=1.3)
        c[..., :3] = 1.0          # all white: no dark core
        cells.append(c)
    return cells


if __name__ == "__main__":
    H.save(H.sheet(arc_cells(np.random.default_rng(21))), "ssj_arc_4x4")
    print("ok")

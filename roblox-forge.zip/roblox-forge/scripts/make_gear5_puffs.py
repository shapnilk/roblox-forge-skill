# roblox-forge: Gear 5 cel puff 4x4 OneShot + lobe atlas. Evidence: won bake-off T2 over Blender toon puff and Toolbox sticker (C:/Users/shapn/Documents/AnimeCloneEggs/forge/research/tests/TEST_RESULTS.md). Risk: busy curls at 25 studs.
"""Gear 5 candidate "numpy_puffs": cel cloud flipbooks drawn in 2D with numpy + PIL (our own art).

  numpy_puffs/puff_4x4.png   4x4 OneShot: puff -> hole opens -> curls grow -> ring breaks into curl wisps
  numpy_puffs/lobes_4x4.png  4x4 static-random atlas (FlipbookStartRandom, Framerate 0): 16 connected
                             scalloped masses, each with a shade side, ink outline, scallop ticks and
                             one interior spiral line (RESEARCH_VFX 5.3 layer 2)

Palette from the user's Gear 5 reference (RESEARCH_VFX 4.6): white #FEFEFE, neutral grey shade
#D5D5D5 on the side away from an upper-left light, near-black line #1A1716. Use with Color white,
LightEmission 0. Shapes: unions of circles (scalloped masses) + spline curls (tapered spiral tubes
that stay open), never strings of equal spheres. Every edge is the ink band, so the alpha bleed is exact.

Run: python numpy_puffs.py   (about 20 s; asserts its own size/padding/empty-frame checks)
"""
import math
import os
import numpy as np
from PIL import Image, ImageDraw
from scipy import ndimage

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(os.getcwd(), "numpy_puffs")  # roblox-forge: run from your effect folder
GRID, SHEET, PAD = 4, 1024, 8
CELL = SHEET // GRID                 # 256
SS = 4                               # supersample
N = CELL * SS                        # 1024 working px per frame
ART = (CELL - 2 * PAD) * SS / 2      # half the usable art box in working px
WHITE, SHADE, INK = (254, 254, 254), (213, 213, 213), (26, 23, 22)
INK_W = 2.6 * SS                     # outline width in working px (~2.6 px in the sheet)
LIGHT = np.array([-0.62, -0.78])     # from upper-left (screen y down)

yy, xx = np.mgrid[0:N, 0:N].astype(np.float32)
X = (xx - N / 2) / ART               # -1..1 over the usable art box
Y = (yy - N / 2) / ART               # y down


def to_px(x, y):
    return N / 2 + x * ART, N / 2 + y * ART


# ---------------------------------------------------------------- primitives
def circles_sdf(cs, ox=0.0, oy=0.0):
    d = np.full(X.shape, 9.0, np.float32)
    for cx, cy, r in cs:
        if r > 0.004:
            d = np.minimum(d, np.hypot(X - ox - cx, Y - oy - cy) - r)
    return d


def stamp(mask_img, pts, widths):
    """Tapered stroke: overlapping discs along a dense polyline (PIL, working res)."""
    dr = ImageDraw.Draw(mask_img)
    for (x, y), w in zip(pts, widths):
        if w <= 0:
            continue
        px, py = to_px(x, y)
        r = w * ART / 2
        dr.ellipse((px - r, py - r, px + r, py + r), fill=255)


def as_mask(img):
    return np.asarray(img) > 127


def spiral(cx, cy, r0, r1, a0, turns, n=220, cw=1):
    """Points on a spiral from radius r0 at angle a0 to r1 after `turns` turns."""
    s = np.linspace(0, 1, n)
    a = a0 + cw * s * turns * 2 * math.pi
    r = r0 + (r1 - r0) * s
    return np.stack([cx + r * np.cos(a), cy + r * np.sin(a)], 1), s


def curl_tube(img, ex, ey, heading, size, cw, width, grow=1.0):
    """An open curl that grows out of a mass: a short straight-ish neck, then a tightening spiral.
    `grow` 0..1 reveals the tube from the root, so curls extend over frames."""
    # spiral centre sits to the side of the heading so the tube leaves the mass, then rolls up
    side = heading + cw * math.pi / 2
    cx, cy = ex + math.cos(heading) * size * 0.55 + math.cos(side) * size * 0.55, \
        ey + math.sin(heading) * size * 0.55 + math.sin(side) * size * 0.55
    a0 = math.atan2(ey - cy, ex - cx)
    pts, s = spiral(cx, cy, math.hypot(ex - cx, ey - cy), size * 0.18, a0, 1.15, cw=-cw)
    keep = s <= grow
    w = width * (1.0 - 0.72 * s) * np.clip(s * 12, 0.55, 1)     # thick root, thin rolled-up tip
    stamp(img, pts[keep], w[keep])


def swirl_line(img, cx, cy, r, a0, cw, width):
    """Interior scroll-curl line: about 1.4 turns opening outward, thin -> thick -> thin."""
    pts, s = spiral(cx, cy, r * 0.12, r, a0, 1.4, cw=cw)
    w = width * np.sin(np.pi * np.clip(s * 0.9 + 0.1, 0, 1)) ** 0.6
    stamp(img, pts, w)


def ring(mask, width):
    if not mask.any():
        return mask
    return (~mask) & (ndimage.distance_transform_edt(~mask) <= width)


def scallop_ticks(lobes, mass, length):
    """Scallop junction lines: a lobe's rim is drawn only where it overlaps a lobe *behind* it
    (lower on screen = in front) and only within `length` of the outer silhouette (not the hole),
    so each junction gets one short hook that grows out of the outline."""
    lab, _ = ndimage.label(~mass)
    border = np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]]))
    od = ndimage.distance_transform_edt(~np.isin(lab, border[border > 0])) / ART
    w = INK_W / ART * 0.42
    near = mass & (od > w) & (od < length)
    m = np.zeros(X.shape, bool)
    sd = [np.hypot(X - cx, Y - cy) - r for cx, cy, r in lobes]
    for i, (cx, cy, r) in enumerate(lobes):
        behind = [sd[j] for j, l in enumerate(lobes) if l[1] < cy - 1e-3 and l[2] > 0.02]
        if r > 0.03 and behind:
            m |= (np.abs(sd[i]) < w) & near & (np.minimum.reduce(behind) < 0)
    return m


def fill_pinholes(mass, max_frac=0.0015):
    """Fill tiny enclosed gaps between overlapping lobes (they would get an outline), but keep
    big openings such as the gaps inside open curls."""
    lab, n = ndimage.label(~mass)
    if n < 2:
        return mass
    area = ndimage.sum(~mass, lab, range(1, n + 1))
    border = set(np.unique(np.concatenate([lab[0], lab[-1], lab[:, 0], lab[:, -1]])))
    small = [i + 1 for i in range(n) if area[i] < max_frac * mass.size and (i + 1) not in border]
    return mass | np.isin(lab, small)


def render(mass, shade, ink_extra):
    """mass/shade/ink_extra: bool masks at working res -> RGBA float, 3 flat tones + outline."""
    img = np.zeros((N, N, 4), np.float32)
    ink = ring(mass, INK_W) | (ink_extra & mass)
    for m, rgb in ((mass, WHITE), (mass & shade, SHADE), (ink, INK)):
        img[m, :3] = np.array(rgb, np.float32) / 255
        img[m, 3] = 1
    return img


def shade_mask(cs, tube, mass, k=0.075):
    """Shade = the part of the mass not covered by the same mass shifted toward the light,
    i.e. a crescent on the lower-right of every lobe and curl (light from the upper-left)."""
    vx, vy = LIGHT * k
    lit = (circles_sdf(cs, vx, vy) < 0) | np.roll(tube, (int(round(vy * ART)), int(round(vx * ART))), (0, 1))
    return mass & ~lit


# ---------------------------------------------------------------- a connected scalloped mass
def mass_lobes(rng, cx, cy, size, n=7, flat=0.55):
    """Lobes round an ellipse: big on top, small and flatter along the bottom (cartoon cloud)."""
    out = [(cx, cy + size * 0.08, size * 0.52)]                    # core keeps the mass connected
    base = rng.uniform(0, 2 * math.pi)
    for i in range(n):
        a = base + 2 * math.pi * i / n + rng.uniform(-0.22, 0.22)
        top = 0.5 - 0.5 * math.sin(a)                                # 1 at the top (y down)
        r = size * (0.24 + 0.16 * top) * rng.uniform(0.85, 1.15)
        dist = size * (0.62 + 0.05 * rng.uniform(-1, 1))
        out.append((cx + math.cos(a) * dist * 1.08, cy + math.sin(a) * dist * (flat + 0.35 * top), r))
    return out


# ---------------------------------------------------------------- OneShot puff
GROW = [0.38, 0.66, 0.82, 0.89, 0.93, 0.96, 0.98, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0]
G = 0.74          # overall scale so curls and drift stay inside the art box (checked in pack)
BREAK = 7.5       # frame where the ring splits into chunks


def puff_frame(t, seed=11):
    """flashfx smoke burst: 3 fast frames, slow growth, a hole opens (t4) and meets the rim; the ring
    splits into 3 chunks that drift apart and shrink, each leaving the curl it grew as a spiral wisp."""
    rng = np.random.default_rng(seed)
    s = GROW[t]
    cl = []
    for k in range(3):
        a = -math.pi / 2 + k * 2 * math.pi / 3 + rng.uniform(-0.2, 0.2)
        cl.append(dict(a=a, cw=1 if k % 2 == 0 else -1, pop=11.0 + k * 1.4 + rng.uniform(-0.3, 0.3),
                       lobes=[(a + j * 0.62 + rng.uniform(-0.1, 0.1), rng.uniform(0.85, 1.12) * (1.18 if j == 0 else 1.0))
                              for j in (-1, 0, 1)]))
    lobes, curls, swirls = [], [], []
    br = max(0.0, t - BREAK)
    for c in cl:
        a = c["a"]
        life = float(np.clip((c["pop"] - t) / (c["pop"] - BREAK), 0, 1)) if t > BREAK else 1.0
        pull = 1 - 0.85 * (1 - life)                                 # chunk lobes huddle into one blob
        ccx, ccy = math.cos(a) * 0.5 * s, math.sin(a) * 0.45 * s
        dx = math.cos(a) * min(br * 0.03, 0.12)
        dy = math.sin(a) * min(br * 0.03, 0.12) - min(br * 0.015, 0.06)
        pos = lambda la, rad: (ccx + (math.cos(la) * rad - ccx) * pull + dx, ccy + (math.sin(la) * rad * 0.9 - ccy) * pull + dy)
        for n_, (la, j) in enumerate(c["lobes"]):
            x, y = pos(la, 0.5 * s)
            fade = life ** (0.6 if n_ == 1 else 1.3)                   # the lead (curl) lobe goes last
            lobes.append((x * G, y * G, 0.27 * s * j * fade * (0.9 + 0.2 * (0.5 - 0.5 * math.sin(la))) * G))
        grow = float(np.clip((t - 3.5) / 4.0, 0, 1))                 # the curl grows out of the lead lobe
        if grow > 0:
            la = c["lobes"][1][0] + c["cw"] * 0.5
            x, y = pos(la, 0.66 * s)
            late = float(np.clip((t - 8) / 7.5, 0, 1))               # thins and rolls up as it fades
            curls.append((x * G, y * G, la, 0.28 * (1 - 0.35 * late) * G, c["cw"], 0.13 * (1 - 0.6 * late) * G, grow))
        if 2 <= t <= 9 and life > 0.45:
            x, y = pos(c["lobes"][0][0], 0.5 * s)
            swirls.append((x * G, y * G, 0.11 * s * life * G, a, c["cw"]))
    body = 0.40 * s if t < 4 else 0.40 * float(np.clip((6.5 - t) / 2.5, 0, 1))
    cs = lobes + ([(0.02 * G, 0.04 * G, body * G)] if body > 0.01 else [])
    d = circles_sdf(cs)
    tube = Image.new("L", (N, N), 0)
    for ex, ey, la, size, cw, width, grow in curls:
        curl_tube(tube, ex, ey, la, size, cw, width, grow)
    tube = as_mask(tube)
    mass = fill_pinholes((d < 0) | tube)
    if 4 <= t <= BREAK:                                              # off-centre wobbly hole
        hr = (t - 3) / 12.0 * 0.78 * G
        hx, hy = X - 0.05 * G, Y + 0.03 * G
        th = np.arctan2(hy, hx)
        hole = np.hypot(hx, hy) < hr * (1 + 0.14 * np.sin(3 * th + 1) + 0.08 * np.sin(5 * th + 2))
        mass &= ~(hole & ~tube)
    sw = Image.new("L", (N, N), 0)
    for lx, ly, r, a0, cw in swirls:
        swirl_line(sw, lx, ly, r, a0, cw, INK_W / ART * 0.9)
    ink_extra = as_mask(sw) | (scallop_ticks(lobes, mass, 0.09 * s * G) if t >= 1 else False)
    return render(mass, shade_mask(cs, tube, mass), ink_extra)


# ---------------------------------------------------------------- static lobe atlas
def lobe_frame(i):
    rng = np.random.default_rng(100 + i)
    size = rng.uniform(0.50, 0.60)
    cx, cy = rng.uniform(-0.06, 0.06), rng.uniform(0.0, 0.12)
    cs = mass_lobes(rng, cx, cy, size, n=int(rng.integers(6, 9)))
    d = circles_sdf(cs)
    tube = Image.new("L", (N, N), 0)
    if i % 2 == 0:                                       # every other lobe trails one open curl tip
        a = rng.uniform(-math.pi * 0.95, -math.pi * 0.05)  # leaves from the upper half
        ex, ey = cx + math.cos(a) * size * 0.95, cy + math.sin(a) * size * 0.75
        curl_tube(tube, ex, ey, a, 0.26, 1 if rng.random() < 0.5 else -1, 0.13)
    tube = as_mask(tube)
    mass = fill_pinholes((d < 0) | tube)
    sw = Image.new("L", (N, N), 0)
    big = max(cs[1:], key=lambda c: c[2] - 0.6 * c[1])  # a big upper lobe carries the swirl
    swirl_line(sw, big[0] * 0.6 + cx * 0.4, big[1] * 0.6 + cy * 0.4, size * 0.24, rng.uniform(0, 6.28),
               1 if rng.random() < 0.5 else -1, INK_W / ART * 0.9)
    shade = shade_mask(cs, tube, mass)
    return render(mass, shade, as_mask(sw) | scallop_ticks(cs[1:], mass, 0.07))


# ---------------------------------------------------------------- pack
def downsample(img):
    a = img[..., 3:4]
    pm = np.concatenate([img[..., :3] * a, a], -1).reshape(N // SS, SS, N // SS, SS, 4).mean((1, 3))
    a = pm[..., 3:4]
    return np.concatenate([np.where(a > 0, pm[..., :3] / np.maximum(a, 1e-6), 0), a], -1)


def pack(frames, path):
    sheet = np.zeros((SHEET, SHEET, 4), np.float32)
    for i, f in enumerate(frames):
        r, c = divmod(i, GRID)
        f = downsample(f)                                 # 256x256 incl. its own padding
        edge = max(f[:PAD, :, 3].max(), f[-PAD:, :, 3].max(), f[:, :PAD, 3].max(), f[:, -PAD:, 3].max())
        assert edge == 0, ("art clipped by the cell padding", path, i)
        f[:PAD], f[-PAD:], f[:, :PAD], f[:, -PAD:] = 0, 0, 0, 0
        sheet[r * CELL:(r + 1) * CELL, c * CELL:(c + 1) * CELL] = f
    clear = sheet[..., 3] <= 0
    sheet[clear, :3] = np.array(INK, np.float32) / 255     # exact bleed: every edge is the ink band
    Image.fromarray((np.clip(sheet, 0, 1) * 255 + 0.5).astype(np.uint8), "RGBA").save(path, optimize=True)
    return sheet


def check(sheet):
    a = sheet[..., 3]
    cover = []
    for r in range(GRID):
        for c in range(GRID):
            cell = a[r * CELL:(r + 1) * CELL, c * CELL:(c + 1) * CELL]
            assert cell[:PAD].max() == 0 and cell[-PAD:].max() == 0 and cell[:, :PAD].max() == 0 \
                and cell[:, -PAD:].max() == 0, ("art in padding", r, c)
            cover.append(round(float((cell > 0.5).mean()), 3))
    assert min(cover) > 0.004, ("empty frame", cover)
    return cover


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    puff = pack([puff_frame(t) for t in range(16)], os.path.join(OUT, "puff_4x4.png"))
    lobes = pack([lobe_frame(i) for i in range(16)], os.path.join(OUT, "lobes_4x4.png"))
    print("puff coverage ", check(puff))
    print("lobes coverage", check(lobes))

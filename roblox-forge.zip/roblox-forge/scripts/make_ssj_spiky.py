# roblox-forge: Super Saiyan hero silhouette 2x2 (spline envelope + hooked tongues). Evidence: SSJ aura judged 'honestly better than the toolbox' by the user; v2 rim-alpha fix in C:/Users/shapn/Documents/AnimeCloneEggs/forge/research/tests/vfx_forge/WORKFLOW.md.
"""Super Saiyan hero silhouette, our own art: a tall flame-shaped outline hugging the body with
upward-licking hooked tongues, white core -> gold edge (pre-coloured; use Color white in Roblox).

Why: the previous flame flipbooks read as a campfire (separate tongues, no silhouette) and the spline
egg as a bubble (spikes too small). RESEARCH_VFX 5.1: the outline IS the effect; thick bases, hooked
tips, varied lengths, flared sides; boil small (consecutive IoU ~0.85-0.92), fill ~1 at the rim
falling to ~0.3 in the centre so the body shows.

Shape: envelope half-width w(v) (narrow at the feet, widest at the shoulders, closing above the head),
walked as a closed outline; N tongues replace short stretches of it with a C/S curve to a hooked tip
pointing up-and-out. 4 boil frames keep tongue positions and vary length/hook/phase slightly.
Output: textures/ssj_spiky_2x2.png (1024, 512 cells, 16 px pad) + _512 copy + _preview.png
Run: python make_ssj_spiky.py
"""
import math
import os

import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import distance_transform_edt, gaussian_filter

OUT = os.path.join(os.getcwd(), "textures")  # roblox-forge: run from your effect folder
SHEET, GRID, PAD, SS = 1024, 2, 16, 4
CELL = SHEET // GRID
ART = CELL - 2 * PAD           # 480
S = ART * SS                   # supersampled cell art (1920)
WHITE = np.array([1.0, 1.0, 1.0])
PALE = np.array([1.0, 0.95, 0.62])
GOLD = np.array([1.0, 0.80, 0.16])
INK = np.array([0.95, 0.55, 0.05])


def halfwidth(v):
    """Envelope half-width (cell units) at height v (0 = feet, 1 = top of the envelope)."""
    if v < 0.6:   # rounded point at the feet, widening to the shoulders
        return 0.29 * math.sin(v / 0.6 * math.pi / 2) ** 0.55
    return 0.29 * math.cos((v - 0.6) / 0.4 * math.pi / 2) ** 0.6   # dome over the head


def envelope(n=400):
    """Closed outline: left side bottom->top, right side top->bottom, cell coords (x right, y up)."""
    vs = np.linspace(0.0, 1.0, n)
    H, Y0 = 0.74, 0.03                       # envelope uses 3-77% of the height; tongues reach ~97%
    left = [(0.5 - halfwidth(v), Y0 + H * v) for v in vs]
    right = [(0.5 + halfwidth(v), Y0 + H * v) for v in vs[::-1]]
    return np.array(left + right)


def bez(p0, p1, p2, p3, n=24):
    t = np.linspace(0, 1, n)[:, None]
    return (1 - t) ** 3 * p0 + 3 * (1 - t) ** 2 * t * p1 + 3 * (1 - t) * t ** 2 * p2 + t ** 3 * p3


def tongues(rng):
    """Tongue layout shared by all frames: (arc position 0..1, base half-width, length, hook)."""
    out = []
    # left side bottom->top ~ [0, 0.5], right side top->bottom ~ [0.5, 1]
    pos = np.concatenate([np.linspace(0.14, 0.45, 5), np.linspace(0.55, 0.86, 5)])
    pos += rng.uniform(-0.015, 0.015, pos.size)
    for p in pos:
        top = 1 - abs(p - 0.5) / 0.5          # 1 near the top of the outline, 0 at the feet
        out.append((p, rng.uniform(0.04, 0.055), (0.08 + 0.17 * top ** 1.2) * rng.uniform(0.8, 1.2),
                    rng.uniform(0.15, 0.45)))
    out.append((0.5, 0.045, 0.19 * rng.uniform(0.9, 1.1), rng.uniform(-0.3, 0.3)))  # crown tongue
    return out


def outline(env, tg, rng, jitter):
    """Insert tongues into the envelope -> polygon (cell coords)."""
    seg = np.r_[0, np.cumsum(np.linalg.norm(np.diff(env, axis=0), axis=1))]
    s = seg / seg[-1]
    pts, k, polys = [], 0, []
    for p, hw, L, hook in sorted(tg):
        a, b = p - hw, p + hw
        while k < len(env) and s[k] < b:   # keep the envelope under the tongue (union fills it)
            pts.append(env[k])
            k += 1
        i0, i1 = np.searchsorted(s, a), np.searchsorted(s, b)
        P0, P3 = env[min(i0, len(env) - 1)], env[min(i1, len(env) - 1)]
        mid = env[min((i0 + i1) // 2, len(env) - 1)]
        d = P3 - P0
        normal = np.array([d[1], -d[0]]) / (np.linalg.norm(d) + 1e-9)   # outward (clockwise walk)
        if normal @ (mid - np.array([0.5, 0.5])) < 0:
            normal = -normal
        side = np.sign(mid[0] - 0.5) or 1.0
        up = np.array([0.0, 1.0])
        L = L * (1 + jitter * rng.uniform(-0.22, 0.22))
        dirv = normal * 0.45 + up * 1.0
        dirv /= np.linalg.norm(dirv)
        tip = mid + dirv * L + np.array([side * hook * 0.35 * L * (1 + jitter * rng.uniform(-0.6, 0.6)), 0])
        # rising edge: thick base swelling out (S), falling edge: concave C back to the base
        c1 = P0 + dirv * L * 0.45 - normal * 0.01
        c2 = tip - dirv * L * 0.35 + np.array([-side * 0.012, 0])
        c3 = tip - dirv * L * 0.55 + normal * 0.004
        c4 = P3 + dirv * L * 0.18
        tongue = list(bez(P0, c1, c2, tip)) + list(bez(tip, c3, c4, P3)) + [mid - normal * 0.03]
        polys.append(np.array(tongue))
        k = i1
    pts += list(env[k:])
    return [np.array(pts)] + polys     # drawn as a union (no even-odd holes where curves cross)


def render(polys):
    im = Image.new("L", (S, S), 0)
    dr = ImageDraw.Draw(im)
    for poly in polys:
        dr.polygon([(x * S, (1 - y) * S) for x, y in poly], fill=255)
    m = np.asarray(im) > 127
    d = distance_transform_edt(m) / SS          # px at final res, inside distance
    depth = np.clip(d / 45.0, 0, 1)             # 0 at rim -> 1 deep inside
    # v2: a strong rim band fading to a near-clear centre (v1's 0.3+ fill stacked into solid white)
    alpha = np.where(m, 0.07 + 0.93 * (1 - depth) ** 2.2, 0.0)
    t = depth[..., None]
    rgb = np.where(t < 0.3, GOLD + (PALE - GOLD) * (t / 0.3),
                   PALE + (WHITE - PALE) * np.clip((t - 0.3) / 0.4, 0, 1))
    rgb = np.where((d < 2.2)[..., None] & m[..., None], INK, rgb)   # thin warm ink line at the rim
    rgba = np.concatenate([rgb, alpha[..., None]], axis=-1)
    rgba[..., :3] *= rgba[..., 3:4]                                    # premultiply, box down
    f = SS
    rgba = rgba.reshape(ART, f, ART, f, 4).mean(axis=(1, 3))
    a = rgba[..., 3:4]
    rgba[..., :3] = np.where(a > 1e-4, rgba[..., :3] / np.maximum(a, 1e-4), GOLD)  # bleed gold
    return rgba


def main():
    rng = np.random.default_rng(11)
    env = envelope()
    tg = tongues(rng)
    sheet = np.zeros((SHEET, SHEET, 4))
    sheet[..., :3] = GOLD
    cells = []
    for f in range(4):
        r = np.random.default_rng(100 + f)
        wob = [(p, hw, L * (1 + 0.15 * math.sin(f * 1.7 + i)), hook) for i, (p, hw, L, hook) in enumerate(tg)]
        c = render(outline(env, wob, r, jitter=1.0))
        cells.append(c)
        rr, cc = divmod(f, GRID)
        sheet[rr * CELL + PAD: rr * CELL + PAD + ART, cc * CELL + PAD: cc * CELL + PAD + ART] = c
    def bleed(rgba):
        """Transparent texels take the RGB of the nearest drawn texel (no halo when Roblox filters)."""
        _, idx = distance_transform_edt(rgba[..., 3] < 0.02, return_indices=True)
        out = rgba.copy()
        out[..., :3] = rgba[idx[0], idx[1], :3]
        out[..., :3] = np.where(rgba[..., 3:4] >= 0.02, rgba[..., :3], out[..., :3])
        return out

    def save(rgba, name):
        img = (np.clip(bleed(rgba), 0, 1) * 255 + 0.5).astype(np.uint8)
        Image.fromarray(img, "RGBA").save(os.path.join(OUT, name), optimize=True)

    save(sheet, "ssj_spiky_2x2.png")
    pm = sheet.copy()
    pm[..., :3] *= pm[..., 3:4]
    pm = pm.reshape(512, 2, 512, 2, 4).mean(axis=(1, 3))
    pm[..., :3] /= np.maximum(pm[..., 3:4], 1e-4)
    save(pm, "ssj_spiky_2x2_512.png")
    a = sheet[..., 3:4]
    prev = sheet[..., :3] * a + (1 - a) * np.array([0.2, 0.22, 0.28])
    Image.fromarray((prev * 255).astype(np.uint8)).save(os.path.join(OUT, "ssj_spiky_2x2_preview.png"))
    # self-check: boil small, coverage in band
    ms = [c[..., 3] > 0.1 for c in cells]
    ious = [float((ms[i] & ms[i + 1]).sum() / (ms[i] | ms[i + 1]).sum()) for i in range(3)]
    cov = [float(m.mean() * (ART / CELL) ** 2) for m in ms]
    print("IoU", [round(x, 3) for x in ious], "coverage", [round(x, 3) for x in cov])
    assert all(0.75 < x < 0.97 for x in ious), "boil out of band"
    print("mean alpha visible", round(float(np.mean([c[..., 3][c[..., 3] > 0.1].mean() for c in cells])), 3))


if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True)
    main()

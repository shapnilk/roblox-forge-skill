---
name: roblox-forge
description: Build our OWN Roblox art (no Toolbox assets shipped) for anime-style games like Anime Clone Eggs - custom auras/particle VFX authored as code-drawn flipbooks, code-built R6 KeyframeSequence animations, UI art and juice, and generated R6 characters/hair - using a reference -> numbered targets -> script-authored textures -> pooled Studio effect -> same-camera capture vs baseline -> critique loop. Use when the user asks for a custom aura, particle effect, flipbook, lightning/flame/cloud effect, anime animation (run, pose, transformation), UI art, or character/hair "without the Toolbox", "our own art", "better than the toolbox", or to remake a Toolbox effect as original work. Not for plain gameplay scripting.
---

# Roblox forge: own-art VFX, animation, UI and characters

Proven on Anime Clone Eggs (2026-10-04). Toolbox assets are only the **bar to beat** and study
material: never ship their textures/meshes, never copy reference images into the game.
For generic art direction use `roblox-visual-production`; this skill is the pipeline that actually
produced user-approved own-art results.

## Acceptance evidence (what this skill is built on)
| Result | Verdict | Source |
|---|---|---|
| Conqueror's Haki aura, own textures + `HakiAura.luau` v4 | User: "I like the conquerors haki aura" | `forge/research/tests/vfx_forge/WORKFLOW.md` |
| Super Saiyan aura, own textures + `SSJAura.luau` v4 | User: "honestly better than the toolbox" | same, SSJ run log |
| Code-built KeyframeSequence ninja run | Won bake-off T5 vs procedural Motor6D | `forge/research/tests/TEST_RESULTS.md` |
| numpy-drawn Gear 5 puff | Won bake-off T2 (not yet user-approved) | same |
| `validate.py` gate | 191 files, 6 real failures caught | same, T6 |
| Gojo hair p1 (control-point blueprint) | User: "P1 looks better than p3, that's it for the hair" | `forge/README.md` hair log |

Paths are under `C:/Users/shapn/Documents/AnimeCloneEggs/`. First own-art attempts lost
(campfire flames, bubble egg); the loop below is what turned losses into wins.

## The core loop (every asset)
1. **Reference, frozen in 15 min.** User's words + measured stills (sample hex with code) + 2-3 web
   descriptions. Newest user words beat older plans; keep the old figure as a config knob.
2. **Write 3-6 numbered targets with numbers** in `<EFFECT>_TARGETS.md`: shape (studs vs R6 body),
   colour/value (hex), timing (s), density, glow, cost. Examples: `vfx_forge/HAKI_TARGETS.md`, `SSJ_TARGETS.md`.
3. **Pick a 4-7 layer stack** before drawing (hero, life-cycle accent, strokes, dark secondary, glow,
   light/rim). See [vfx.md](references/vfx.md).
4. **Author textures by script** (numpy + PIL + scipy, ~10-25 s per sheet; Blender headless only for
   noise layers). Tint-preview every frame (`scripts/preview_tint.py`), then gate with
   `python scripts/validate.py --kind vfx <sheets>`.
5. **Upload 512 px copies** (`upload_image` from a local `http.server`), assemble a **pooled,
   Emit-driven** client module: `attach(character, cfg) -> handle`, all instances created once.
6. **Capture same-camera vs the baseline** (Toolbox clone 8 studs away, ours on the right): close
   8-10 studs + gameplay 25 studs + back 3/4, FOV 70, **2-3 live frames per shot**. See [pipeline.md](references/pipeline.md).
7. **Judge every frame against each numbered target** - ideally an independent reviewer agent, not
   the builder. Change 1-3 things per round, snapshot module + captures to `captures/vN/`.
8. **At most 3 correction rounds** (Haki and SSJ each took 4 versions incl. v1), keep the best, then
   the **user's verdict on a same-camera side-by-side**. Only the user marks it approved.

## Routing
- Auras, particles, flipbooks, beams, lightning, flames, clouds -> [references/vfx.md](references/vfx.md)
- R6 animations (KeyframeSequence from JSON poses) -> [references/animation.md](references/animation.md)
- UI art, layout, scaling, juice -> [references/ui.md](references/ui.md)
- Studio MCP preview/upload/validation/capture loop, RAM habits -> [references/pipeline.md](references/pipeline.md)
- R6 mesh hair / characters (control-point lock blueprint -> headless Blender) -> [references/characters.md](references/characters.md)

## Scripts (copied from the winning runs; each has a one-line evidence header)
| Script | Does |
|---|---|
| `make_haki_textures.py` | Haki bolts (black core / white rim / soft glow), pop life cycle, wisps, glow, Beam strips |
| `make_ssj_spiky.py` | SSJ hero 2x2: spline envelope + hooked Bezier tongues, rim-heavy alpha |
| `make_ssj_extras.py` | SSJ2 arcs 4x4 (imports `make_haki_textures` - keep same folder / PYTHONPATH) |
| `make_ssj_textures.py` | streak/spark/disc secondaries (its egg + V-fan heroes are the losing examples) |
| `make_gear5_puffs.py` | Gear 5 cel puff OneShot + lobe atlas |
| `preview_tint.py` | `tex.png R G B` -> Roblox-style tinted preview over grey |
| `validate.py` (+ `template.py`) | spec gate: flipbooks, textures, mesh JSON, clothing templates |
| `HakiAura.luau`, `SSJAura.luau` | approved aura modules (slot pool, Emit scheduler) |
| `KeyframeBuilder.luau` + `poses.json` | JSON poses -> joint-space KeyframeSequence -> preview |
| `ForgePreview.luau` | session-bake Blender JSON meshes onto an R6 rig, no upload |
| `hair/` | hair pipeline: `hair_v13.py` (+`forgelib`, `measured`, `hair_softbake`), `hair_blueprint_png.py`, `points_design.py`, `carve.py`, `sil_iou.py`, `lock_stats.py`, `example_hair_points.json` (the p1 design) |
Generators write to `./textures` (or `./numpy_puffs`) under the **current directory**: run them
from the effect's folder, not the skill folder.

## Hard-won gotchas (each cost a round)
1. **Edit-mode particles only spawn near the Studio camera.** Set `workspace.CurrentCamera` at the
   shot and wait ~2.5 s before `screen_capture`; a far teleport capture shows nothing.
2. **Judge from live frames, not frozen ones.** `TimeScale = 0` often freezes an empty instant
   (Haki v2/v3 "empty" captures). Use a `burst()` hook to force rare events for one frame.
3. **Stacked translucency:** a hero re-emitted at Rate x Lifetime overlaps ~4 copies, so author the
   fill for the stack (centre alpha <= 0.1, rim band alpha 1 -> 0.07 within 45 px). SSJ v1's 0.3
   fill stacked into a solid white wall.
4. **Additive accents vanish over a bright layer.** Blue additive arcs over the white-gold aura added
   nothing; use LightEmission ~0.3 for accents on top of a glow.
5. **Dark cores need normal blend** (LightEmission 0); at LE > 0 dark colours turn transparent.
   Texture white/greyscale, tint with `Color`.
6. **Set `LightInfluence = 0` and `FlipbookBlendFrames` explicitly** - `Instance.new` defaults differ
   from Studio's. Approved auras use `false`.
7. **Padding survives resizing only if authored big:** author **16 px cell padding at 1024** if a 512
   copy is made (512 halves it; 8 px -> 4 px is the validator floor, 2 px failed).
8. **Soft-fade the art box edge** or the glow is cut into a visible rectangle; bleed transparent
   texels (white, or nearest texel for coloured art) or Roblox's bilinear resize draws halos.
9. **Uploads:** 512 px optimized PNGs load reliably; ~1.4 MB 1024 px PNGs sometimes never load.
   `PreloadAsync`/`GetAssetFetchStatus` report Failure early for images that do render - apply the
   id and verify with a capture.
10. **`CreateAssetAsync` is unavailable over MCP** ("not available yet") for meshes and animations:
    animations need a manual Animation Editor publish (or Open Cloud with the user's key); meshes go
    through File > Import 3D.
11. **Clamp the dummy's feet to the floor** (`PivotTo` by leg-bottom / `PivotOffset (0,-3,0)`). A
    dummy sunk 1.5 studs made effects look wrong; bolts emitted from leg bottom faces clipped the floor.
12. **Camera FOV 70** for captures (gameplay default). A leftover FOV 30 made 10-stud shots look like 4.
13. **Slot pools need `life < minGap x slots`**, or a slot moves while its particle lives (Haki v3
    double-emit bug). Reparenting/moving an attachment right before `Emit` spawns at the new spot.
14. **Procedural `Motor6D.Transform` does nothing in Edit** (no physics step) and the trial profile
    leaned backwards on standard R6 C0s; the Animator path works in Edit via `StepAnimations`.
15. **`HttpService:GetAsync` caches:** pass `nocache = true` plus a `?t=` query when reloading modules.
16. Nothing saved to the place during tests: remind the user to **Ctrl+S** if they want to keep it.

## Characters & hair
User stopped on Gojo hair **p1** (preferred over the later p3; not confirmed as a benchmark match).
Recipe in [characters.md](references/characters.md): carve the silhouette, write each lock as
`[az, el, off]` control points, draw the numbered blueprint, build headless with a flat 3-vertex
leaf strand, judge same-camera, reviewer returns lock-numbered point edits, max 3 rounds. Biggest
lessons: separate smooth locks not a sculpted mass; control the whole lock, not root + tip;
matching stats is not matching the look; keep every variant (newer was worse twice).

## Not proven yet (say so; do not claim)
- Play-mode runner test (16 / 60 / 110 studs/s), graphics level 1, and **40-wearer cost** for any aura.
- `FlipbookBlendFrames` true vs false A/B in Play (research says it is not settled).
- `LockedToPart` / `VelocityInheritance` on CFrame-moved clones and treadmills.
- Lightning-Beams (MIT) Haki variant: Lua/GPU cost at 40 wearers; no glow layer.
- Gear 5 puff inside a full aura, and Silver Instinct, Fox Chakra, Infinity Void: not built/approved.
- Animation publishing route; Open Cloud upload of a code-built `.rbxm` untested.
- No blind multi-judge panel was ever run (single judge + user verdict).
- `validate.py` halo score may false-alarm at 512 px where white meets an ink rim; `.fbx` files are
  not checked (only their JSON twins).
- Characters: hair p1 is a stopping point, not a benchmark match; faces and clothing never approved.

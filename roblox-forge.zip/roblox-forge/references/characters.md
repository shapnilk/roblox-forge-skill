# Characters & hair (R6 mesh hair, own art)

Evidence: Gojo hair, 2026-10-03/04, ~30 builds (v1-v14, thickness variants A-H, d1-d5, p0-p3) judged
same-camera against the Toolbox Gojo. **Final = p1** (user: "P1 looks better than p3, okay thats it
for the hair"). It is the user's pick to stop on, **not** a confirmed match to the benchmark - say
that when quoting it. Full log: `forge/README.md` hair sections, board "Gojo Hair Review".

## What the benchmark actually is (measure yours the same way)
- **R6**, not R15: classic Head SpecialMesh scale 1.25, hair = ONE accessory mesh at scale 1, face = second accessory.
  (User asked "maybe it's R15?" - checked in Studio, it is R6. Check the rig before assuming.)
- Hair ~3.9k tris, ~50-75 **separate smooth leaf locks** layered like feathers from a crown whorl;
  smooth normals, hard edges only at lock rims, crest dihedral ~48 deg, lock half-width 0.09-0.15 studs.
- Layers (tip elevation from head centre / stand-off above head): star cap at the crown; flare ring
  ~27 locks (tip el ~+18, off ~0.5); hanging layer 12-15 (len ~0.8, el ~-10, hugging); fringe ~11
  (len ~0.6, el ~+5, tips between brow and eyes); lower back (el ~-18, off ~0.4).
- Texture: lit-looking mid tones (lilac #B397B1-#D2CED3, never pure white), lilac AO, no baked direct light.
- Creator method (YouTube V8_Z7JEpjSc): Bezier path + flattened 3-vertex bevel, tips scaled to 0,
  convert, join, shade smooth; duplicate/rotate strands round the crown pivot, mirror, add thinner
  raised layers, pull outer strands out, add bangs.

## Recipe (what produced p1)
1. **Carve the target silhouette** from 11 same-camera Studio captures of the reference
   (`scripts/hair/carve.py`, IoU 0.95-0.98) -> `hull.obj`. Study only; never ship benchmark geometry.
2. **Write a control-point design JSON** (`scripts/hair/example_hair_points.json`, schema below).
   Each lock is 4-6 points `[az, el, off]`: az 0 = front, + = character right; el 0 = head centre
   (eyes ~-5, brow ~+5, top 90); off = studs above the classic head surface (superellipse r 0.6,
   vpow 5, centre (0,1.5,0)). Catmull-Rom passes **exactly** through the points, so the build matches
   the drawing. Seed one from any build with `points_design.py <locks_resolved.json>`.
3. **Draw the numbered blueprint** (front/side/back/top, lock numbers, point circles):
   `python scripts/hair/hair_blueprint_png.py <out>/locks_resolved.json <out>/clumps.json <outline_meshes.json> bp.png`.
4. **Build headless** (Blender 5.x, ~20 s, 2.8-3.8k tris):
   ```
   FORGE_DESIGN=<design.json> FORGE_LAYOUT=points FORGE_WIDTH=0.85 FORGE_FLAT=0.6 FORGE_PROFILE_N=3 \
   FORGE_BELLY=0.42 FORGE_TAPER=2.2 FORGE_SEG=7 FORGE_CREASE=60 \
   blender -b --factory-startup --python scripts/hair/hair_v13.py -- hull.obj out/p1
   ```
   Writes `hair_meshes.json`, `hair.fbx`, `hair_tex.png` (+512 copy), `locks_resolved.json`.
   Strand = flat triangle profile (crest up, flat side to the head), leaf width (widest at BELLY,
   taper exponent TAPER), smooth shading with CREASE keeping rims hard. Palette override:
   `FORGE_LOW` / `FORGE_SHADOW` hex.
5. **Preview without upload:** `ForgePreview.luau` `FP.dress(rig, url, {Hair = ...})` (pipeline.md §3);
   texture via `upload_image` at 512 px.
6. **Judge** same camera next to the benchmark (front close, 3/4, side, back, top) plus
   `sil_iou.py` (silhouette IoU per view). Independent reviewer returns **lock-numbered point edits**
   ("lock 42: pts -> [...]"); apply exactly; max 3 rounds; user picks.

## Lessons (each cost rounds)
1. **Locks, not a sculpted mass.** Hull-sculpted hair (v7-v12) always read lumpy; separate swept locks (v13) fixed smoothness in one step.
2. **Strand shape = thick natural leaf-spear,** not thin sharp blades, not round tubes, not rectangles. Flat 3-vertex profile with a wide belly (0.42) and slow taper (2.2) won; 5-point "chunk" and round profiles lost.
3. **The blueprint must control the whole lock, not root + tip.** Root/tip designs (d1-d5) let the builder invent the curve and every one looked off; control points (p-series) fixed it (d3t reproduced at IoU 0.997).
4. **Matching statistics is not matching the look.** d4/d5 hit lock counts/lengths/elevations per layer and regressed. Design by eye against the blueprint, use stats only as sanity checks.
5. **One change per variant** from the last accepted build; v14 changed five things and lost everything v13 had.
6. **Reviewer fixes can overshoot.** p2's tuft became a spike clump, p3 (after shrinking) was judged worse than p1. Keep every variant and let the user compare old vs new; newer is not better by default.
7. **Texture:** no baked direct light, lilac shadows never grey, weak AO (0.04-0.06; strong AO from overlapping locks blotches), Plastic, 512 px upload.
8. **Hair budget:** accessory <= 4k tris; FORGE_SEG 5-7 keeps 60+ locks under it.

## Not proven
- No hair has been confirmed as matching the benchmark; p1 is the stopping point.
- Faces (`forge/chars/gojo5_face.py` ink painter) and clothing (`gojo5_cloth.py` layer stack): user said they were "perfect" (2026-10-04); scripts not bundled here yet.
- Hull-free design (no reference to carve) is untested: you'd write points from front/side sketches.
- Import 3D of the final mesh and its texture on a live character in Play: not done.

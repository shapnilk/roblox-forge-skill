# Code-built R6 animation (KeyframeSequence from JSON poses)

Evidence: bake-off T5 in `forge/research/tests/TEST_RESULTS.md`; code in
`forge/research/tests/anim/` (`KeyframeBuilder.luau`, `poses.json`, `Harness.luau`, `anim_sim.py`,
`out/metrics.json`, `captures/`). Paths relative to `C:/Users/shapn/Documents/AnimeCloneEggs/`.

## Result
Code-built KeyframeSequence `ninja_run` beat the procedural Motor6D profile: strong readable
ninja-run silhouette with anime holds, and the **same JSON works on standard R6 and identity-C0
rigs**. Measured at frame 7 in Studio: torso pitch 25 deg forward, arms 77 deg back, legs -48/+50 deg,
engine FK error 0.000 vs the offline `anim_sim.py`. The procedural profile leaned **backwards**
(-11.4 deg) on standard R6 joints because it assumed identity C0.

## Recipe
1. **Pose library JSON** (`scripts/poses.json`): per pose, keys `Torso, Head, RightArm, LeftArm,
   RightLeg, LeftLeg` (Part1 name without spaces). `rot` = degrees into `CFrame.Angles(x,y,z)`,
   relative to Part0 (Torso vs HumanoidRootPart, the rest vs Torso). Torso x < 0 leans forward; limb
   x > 0 swings the tip forward; z > 0 moves the tip toward +X. Optional `pos` (studs) moves the
   joint pivot (torso bob, detached limbs). `mirror_of` swaps L/R with rot (x,-y,-z), pos (-x,y,z).
2. **Clip** = `fps`, `loop`, `priority`, keys `{f, pose, easing}`. Anime = **few held poses,
   `Constant` easing**; use `Linear` only on keys meant to read as a smear.
   `ninja_run`: 6 poses on 5s at 60 fps (12 poses/s), 0.5 s loop, arms held still (the run is a
   limited-animation hold), torso pos.y chosen so the lowest foot touches the ground (0 penetration).
3. **Joint math** (in `KeyframeBuilder.jointCFrame`): `T = C0^-1 * (Part0^-1 * Part1_desired) * C1`,
   reading C0/C1 from the rig, so the pivot stays fixed. A KeyframeSequence is joint space: **build
   one per rig family** (C0 rotations differ).
4. **Build + preview in Edit:** `KeyframeBuilder.build(rig, lib, clip)` -> `register(kfs)`
   (`KeyframeSequenceProvider:RegisterKeyframeSequence`, falls back to `AnimationClipProvider`;
   Studio-only temporary id) -> `play(rig, kfs)` -> advance with `Animator:StepAnimations(dt)`
   (nothing moves in Edit otherwise). `Harness.luau` shows the stepping + camera + measure loop.
5. **Capture** side and 3/4 views at chosen frames (f05, f07, f12, f22), all candidates in one shot.
   Check numbers (pitch, arm angle, foot height) as well as the look.
6. **Publish manually.** `AssetService:CreateAssetAsync(kfs, Enum.AssetType.Animation, ...)` over
   MCP returns "CreateAssetAsync and CreateAssetVersionAsync are not available yet". Live games need
   an Animation Editor publish under the experience owner (or Open Cloud with the user's key - untested).

## Gotchas
- Procedural `Motor6D.Transform` does not move parts in Edit (no physics step); the Animator path does.
- Known weak spot: in 3/4 view the held-back arms read as a plank - try a small arm bob or lower angle.
- `poses.json` also contains `aura_idle` (tremble holds + inhale beat for an aura burst): built,
  **not judged**.

## Not proven
Live-game playback after a real publish; blending with the game's own run/walk tracks; other move
recipes from `forge/research/RESEARCH_ANIM.md` (flight ~70 deg pitch, Gear 5 bounce, transformation,
hit-stop) are research only.

# Own-art VFX (auras, particles, flipbooks)

Evidence: `forge/research/tests/vfx_forge/` (WORKFLOW.md run logs, captures/v1-v4, ssj_v1-v4),
`forge/research/tests/TEST_RESULTS.md` (bake-off T2/T3), `forge/research/RESEARCH_VFX.md`
(only the rules re-confirmed by tests are listed here). Paths relative to
`C:/Users/shapn/Documents/AnimeCloneEggs/`.

## 1. Layer stack (pick before drawing)
An effect is 4-7 cheap layers, never one emitter. The approved Haki stack:

| Layer | Instance | Blend | Driven by |
|---|---|---|---|
| hero drawings (bolts) | ParticleEmitter, 4x4 still variants (`FlipbookStartRandom`, `Framerate 0`, Loop) | normal, LE 0 | Emit scheduler |
| life-cycle accent (pop) | ParticleEmitter, 4x4 OneShot | normal | bursts only |
| long strokes | pooled Beams, strip texture (512x128) | normal | bursts only |
| dark secondary (wisps) | ParticleEmitter, 4x4 OneShot, ZOffset -0.8 | normal | Emit |
| glow | soft dot, LE 1, ZOffset -2 | additive | bursts |
| light / rim | PointLight (Range 7, Brightness 0.4, flash 1.5), Highlight outline flash | - | bursts |

The approved SSJ stack: glow (additive gold dot, ZOffset -1.5, 2/s, life 1.13 s so pulses never
sync) -> hero (2x2 OneShot outline, ~14/s, life 0.22-0.3 s, ZOffset -1, FacingCameraWorldUp, LE
0.65) -> streaks (Rate 16, cheap; fine if they thin on low graphics) -> sparks (unlocked: short wake
behind a runner) -> SSJ2 arcs (slot pool, LE 0.3) -> gold PointLight + Highlight rim.

Rules confirmed in these runs:
- Dark shapes on **normal blend** (LE 0) under/among additive glow; at LE > 0 dark turns transparent.
- Textures white/greyscale, tinted by `Color` (pre-coloured sheets need Color white).
- `LightInfluence = 0`, `FlipbookBlendFrames` set explicitly (`false` in the approved modules),
  `Speed 0`, `LockedToPart = true` for body-hugging layers so they ride a runner.
- Hard on/off timing via stepped Transparency sequences (Haki crackle:
  `{0,0} {0.45,0} {0.46,1} {0.6,1} {0.61,0} {1,0}` = on-off-on flicker in 0.12-0.2 s).
- Hero layers are **Emit-driven** from a scheduler (Rate-driven heroes blink on low graphics:
  research measured 0.42 live particles at level 1 for the Toolbox SSJ hero; Emit ignores the scaling).

## 2. Texture authoring recipes (code, ~10-25 s per sheet)
Sheet format, always: **1024 sheet, 16 px cell padding, soft fade at the art-box edge, render at
2-4x and box-downsample premultiplied, bleed transparent texels** (white for white art, nearest texel
for coloured art), save a **512 copy for upload**. Never 2048, never 8x8 (the rejected v6 set was
2048 px 8x8 played at 24-30 fps in Random mode).

- **Bolts / strokes** (`make_haki_textures.py`): midpoint-displacement path, thick-thin-thick width,
  1-2 forks. Draw three copies: black core at ~50% width, white rim, soft white glow at 0.42 alpha.
  Tinted, the rim turns crimson and the core stays black.
- **Life-cycle sheet:** one drawing per frame in story order (Haki: spark, grow, fork, peak,
  glow-only flicker, redrawn jag, hold, flicker, thin, dashes, afterglow). The validator forbids blank
  frames, so a glow-only frame stands in for anime's blank frame.
- **Smoke / wisps:** noise in a teardrop, 4 frames of growth, then a rising threshold breaks it into
  chunks (never a fade). Drop small islands with `scipy.ndimage.label` (v1 was confetti).
- **Hero silhouettes** (`make_ssj_spiky.py`): spline envelope (narrow at feet, widest at shoulders)
  plus Bezier tongues with hooked tips, drawn as a **polygon union** (a single self-crossing polygon
  makes even-odd holes). Boil = keep tongue positions, vary length/hook a little (consecutive IoU
  ~0.82-0.95). Rim band alpha 1 falling to 0.07 inside 45 px so the body reads through ~4 stacked copies.
- **Cel puffs** (`make_gear5_puffs.py`): unions of circles (scallops) + shade side + ink band + spline
  spiral curls; hole opens, ring breaks into curl wisps. Every edge is the ink band, so the bleed is
  exact. LE 0, Color white. Won T2 over a Blender toon puff (erosion cuts had no ink, no interior
  spirals) and the Toolbox sticker. Risk: many small curls read as "sheep wool" at 25 studs.
- **Blender noise flipbooks** (`forge/vfx/blender_flipbook.py`, headless Eevee, ~2 min): clean 3-band
  cel flame licks with a built-in life cycle. **Secondary layers only** - as an SSJ hero it read as a
  campfire. Use View Transform Raw so ramp values land unchanged.
- Check: `python scripts/preview_tint.py tex.png R G B` and look at every frame (caught 2 of 3 Haki
  defects), then `python scripts/validate.py --kind vfx <sheets>`.

## 3. Slot-pool pattern ("random points around the body")
N Attachments, each with its own emitter. Before each `Emit`, reparent the next slot round-robin to
a weighted random R6 part (Torso 3, arms/legs 2, Head 1) and move it to a random face point - **never
a bottom face** - pushed 0.15-0.5 studs out along the normal. LockedToPart stays true. Constraint:
`life < minGap x slots` (Haki: crackle life 0.12-0.2 s, gap 0.03-0.14 s, 7 slots; SSJ2 arcs gap
0.12-0.45 s, 4 slots). A double-emit per tick broke this in Haki v3 (`doubleChance = 0`).

## 4. Approved configs (start here, then tune against targets)
- **Haki** (`HakiAura.CONFIG`): core #1B0830, rim #F12A50, glow #B01438, wisp #14061C; crackle size
  2.2-3.2, bursts every 1.5-3 s (1 pop + 2-3 crackles + 1-2 arcs, arc endpoints >= 2.5 studs apart),
  glow 3.8 at 0.74 transparency, Highlight fill 0.82. Result: 1-3 bolts on screen, open space, avatar readable.
- **SSJ** (`SSJAura.CONFIG`): heroSize 7.2, heroY 0.4 (rounded point just under the feet),
  heroPerSecond 14, heroTint (255,236,140), gold (255,214,80), arcs (110,185,255) size 2.2-3.2.

## 5. What lost (don't repeat)
| Attempt | Read as | Why |
|---|---|---|
| Separate flame-tongue flipbooks (numpy or Blender) as SSJ hero | campfire | no continuous silhouette |
| Smooth spline egg with small spikes | bubble shield | spikes too small at 25 studs - need 8-11 big hooked tongues |
| Anime V-fan of streaks | rain | low-alpha box baked into the sheet |
| Thin native Beam lightning near the arms | scribble / horn blades | too thin and small; gradient glow invisible in daylight |
| Per-part Box-surface emitters (Haki v1) | bolts in the floor | emitted from leg bottom faces |
| Grey ink bands under LE 0.65 | mud | ink belongs in normal-blend layers |
| Dense Toolbox Haki particles | rejected by user as too dense | not our art anyway |
Lightning-Beams (MIT, pooled Neon parts) read best in T3 among early candidates but is provisional
(no glow, 40-wearer cost unmeasured); the approved Haki is the particle module above.

## 6. Hand-off checks still owed before shipping an effect
Play-mode runner test (16/60/110 studs/s), graphics level 1, 40-wearer cost, user verdict on a
same-camera side-by-side. Each effect gets its **own** sheet - the user rejected one aura recoloured
across several trails.

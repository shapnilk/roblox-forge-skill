# Pipeline: Studio MCP preview, upload, validation, capture-and-judge

Evidence: `forge/README.md` (preview pipeline, upload quirks), `forge/research/tests/TEST_RESULTS.md`
(T4 preview path, T6 validator), `forge/research/tests/vfx_forge/WORKFLOW.md` (capture loop),
memory `forge-benchmark-match.md` (RAM). Paths relative to `C:/Users/shapn/Documents/AnimeCloneEggs/`.

## 1. Serve local files to Studio
- `python -m http.server <port>` in the folder (used: 8769 forge `out/`, 8770 forge root).
- **Load a Luau module for testing:** in one `execute_luau` call turn `HttpService.HttpEnabled` on,
  `GetAsync(url .. "?t=" .. os.clock(), true)` into a ModuleScript `Source`, turn HttpEnabled back
  off, then `require(module:Clone())` (the clone dodges the require cache on reload).
- `GetAsync` caches: always `nocache = true` plus a `?t=` query.

## 2. Textures
| Route | Use | Facts |
|---|---|---|
| MCP `upload_image` (rbxassetid) | anything others must see | upload **512 px** optimized PNGs; ~1.4 MB 1024 px PNGs sometimes never load. 6/8 visible at first capture (~1.5 s); `GetAssetFetchStatus` said Failure at 0.3 s, Success at 2.7 s |
| Copy into `%LOCALAPPDATA%\Roblox\Versions\<version>\content\textures\forge_preview` -> `rbxasset://textures/forge_preview/x.png` | local preview only | 8/8 visible on first capture, no moderation; only this PC, wiped by every Roblox update, can never ship |
Never trust `PreloadAsync` / fetch status: apply the id and verify with a capture.

## 3. Meshes (characters, hair, mesh VFX)
- Blender writes `<name>_meshes.json`; `scripts/ForgePreview.luau` session-bakes them in Edit
  (EditableMesh -> `CreateDataModelContentAsync` -> `CreateMeshPartAsync`) and welds to an R6 rig:
  `require(game.ServerStorage.ForgePreview:Clone()).rig(name, pos, url, textures, attach, skin)`.
- Caps per EditableMesh: **60k vertices / 20k triangles** (weld shared corners on export, split
  bigger meshes). Accessories must be <= 4k tris (all `Hair*` parts count as one accessory).
- Session meshes vanish on reload; finals go through **File > Import 3D** (`CreateAssetAsync` is
  "not available yet" on this account, also for animations).
- `recalc_outside` every generated mesh: an inward head shell showed the back of the head ("no face").

## 4. Validation gate (before any upload)
```
python scripts/validate.py --kind vfx  <sheets>      # flipbooks: pow2 <= 1024, grid divides, >= 4 px pad, no empty frame, no halo
python scripts/validate.py --kind meshes <*_meshes.json>
python scripts/validate.py <dirs>                    # auto-classify (renders/previews skipped)
python scripts/validate.py                           # self-check
```
Don't pass `*_preview.png` composites with `--kind` (they have no padding by design). Known gaps:
halo score may false-alarm at 512 px on white-into-ink edges; `.fbx` not checked.

## 5. Capture and judge
- **Stage:** `Workspace.VFXForge` (or similar), R6 dummy with **feet clamped to the floor**, flat
  floor, daylight. Baseline (Toolbox clone, study only) 8 studs beside ours so one camera frames
  both - ours on the right. Store a README/AnswerKey StringValue if letters A/B/C are used.
- **Camera:** FieldOfView 70. Edit `screen_capture` needs `camera_position`, `look_at_position` and a
  `capture_id`. Edit-mode particles only spawn near the Studio camera: set `workspace.CurrentCamera`
  there and wait ~2.5 s.
- **Shots:** close 8-10 studs, gameplay 25 studs from above and to the side, back 3/4. Effects look
  tiny or absent at ~40+ studs.
- **Random effects:** 2-3 **live** captures per shot; frozen frames lie (empty instants). Force rare
  events with a `burst()` hook. Raise visible time temporarily for stills, then restore.
- **Judge:** every frame against each numbered target. Prefer an independent reviewer agent given the
  targets + captures as images (not the builder). Change 1-3 things per round; save module + captures
  as `captures/vN/`; max 3 correction rounds; final call is the user's, on a same-camera side-by-side.
- For an approved asset, change **one thing per variant** and show it next to the benchmark (hair v14
  was rejected for changing five things at once).

## 6. RAM-friendly habits (16 GB PC, often ~1.5 GB free)
- Blender **headless**: `blender.exe -b --factory-startup --python <script> -- <args>`
  (portable 5.2.2 at `C:/Users/shapn/Documents/RobloxAgentLab/tools/blender/portable/blender-5.2.2-windows-x64/blender.exe`).
- Close helper apps you started (Blender GUI, http servers when done); no parallel heavy jobs.
- Prefer numpy/PIL generators (~10-25 s) over Blender renders (~2 min) when both work.

## 7. Housekeeping
- Studio work from MCP is unsaved: remind the user to **Ctrl+S**.
- Restore anything toggled for tests (`HttpEnabled`, camera FOV, emitter visible times).
- MCP FPS is meaningless (Studio throttles when unfocused) - cost checks need Play on a device.

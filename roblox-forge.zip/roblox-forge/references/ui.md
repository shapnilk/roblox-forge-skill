# UI art and juice (only lessons with evidence)

Evidence: Anime Clone Eggs UI review 2026-10-01 and v5 work 2026-10-02 (memory
`anime-clone-eggs.md`, `roblox-building-playbook.md` sections 3, 4, 6). For general UI art direction
(briefs, spacing, type roles) use `roblox-visual-production/references/ui.md`. No UI art in this game
was built through the VFX forge loop yet.

## What broke and the fix
| Problem (user feedback or bug) | Fix |
|---|---|
| "Corners stick out" | `ClipsDescendants` ignores `UICorner`: give headers their own UICorner plus a filler frame; put the shine as a gradient on a rounded overlay |
| "Too much text" | World labels only on your own plot; HUD slot text only on events |
| "Must scale to all devices" | `Device.lua` breakpoints (phone/tablet/desktop/console), ScreenGui `CoreUISafeInsets`, panels scroll on phones |
| Top tabs overlapped the top bar | Pin into the top-bar strip with `GuiService.TopbarInset.Height`, re-pin on change (it is 0 at start) |
| Icon flights landed off target | The Fx layer has no inset: add `GetGuiInset()` when flying icons to HUD targets |
| Ground text unreadable | A Top-face SurfaceGui runs across the short axis: use a board tipped back 90 deg with Front face up, check from eye height |
| Portal vortex never animated | Recursive `FindFirstChild("Fill", true)` hit a GUI frame: use direct paths |
| Emoji icons rejected | Glossy outlined stickers rendered from game-icons.net / Phosphor SVG masks with PIL (`art/ui/make_colored.py`: ink outline, drop shadow, gradient, gloss); credit game-icons CC BY 3.0 |

## Style that the user accepted
Stud-style panels: coloured header, red X, translucent dark body + BlurEffect while open, FredokaOne
with thick black UIStroke, FredokaOne italic (`Font.new(<FredokaOne family>, weight, Enum.FontStyle.Italic)`, `UI.Italic`) for numbers.
Unknown items as silhouettes; portraits as ViewportFrames.

## Juice kit that made it feel alive
Number roll-ups; icon flies into counters with a punch; sunburst reward reveal (dim, spinning rays,
slam title, roll-up, fly to counter); CLAIMED stamps + rising chime on back-to-back claims + Claim
All; screen shake, 2-frame black/white impact frames, letterboxing. "The game felt flat until there
were any SFX at all" - add sounds early (Roblox library APM/ProSoundEffects, no copyrighted music).

## Testing UI over MCP
- Phone check: `PlayerGui.Main.Debug:Invoke("emulate", 812, 375)`; open panels with `Invoke("open", "Shop")`.
- `user_mouse_input` takes GUI coordinates of the real viewport (1365x768) while captures are scaled
  (1113x626): convert, find centres via `AbsolutePosition`; `GetGuiObjectsAtPosition` shows what eats a click.
- Chat can't be typed via MCP (CoreGui focus): test commands through a hook.
- Not proven: real-phone check (still pending at last status).
